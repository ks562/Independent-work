// File: sorting.cpp
// Driver program for Heap Sort
// Assumes that type T has defined operator<

#include <cstdlib>   // exit
#include <fstream>
#include <iostream>
#include <iomanip>
#include <vector>

template <typename T>
void print_container (const T & container) {
   using namespace std;
   for (auto e: container)
      cout << " " << e;
   cout << endl;
}  // end print_container

bool debug1 = false;  // global debug flags
bool debug2 = true;

// Sorting function - includes here so print_container and debug
// flags are visible to sorting function.
#include "heapsort.h"

int main (int argc, char *argv[])
{
   using namespace std;

   // Example vector from lecture
   vector<int> v = {55, 50, 10, 40, 85, 90, 60, 95, 70, 80, 20};

   cout << "Vector before sorting" << endl;
   print_container(v);
   
   heap_sort(v);
   cout << "Vector after Heap Sort" << endl;
   print_container(v);
   return 0;
}
