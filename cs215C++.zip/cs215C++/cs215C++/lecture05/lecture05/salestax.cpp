// Class: CS 215
// Assignment: In-class Exercise for 08/27/2018
// Programmer: Karim Soufan

#include <iostream>

/* PROBLEM STATEMENT
   Write a program to ask user for price of an item and the sales
   tax rate, then compute the sales tax and the total amount due
   using a function called compute_sales_tax_and_total.
*/

// FUNCTION PROTOTYPE GOES HERE
/* Function: compute_sales_tax_and_total
   Analysis
   Objects                Type             Movement           Name
   ------------------------------------------------------------------
   price of item          double           received           price
   sales tax amount       double           passed back        tax
   sales tax rate         double           received           rate
   total amount due       double           passed back        total
*/

void compute_sales_tax_and_total(double price, double rate,
                                 double &tax, double &total);

int main ()
{
   using namespace std;

   // DECLARE VARIABLES HERE
   double item_price, tax_rate, sales_tax, total_due;

   // 1. Ask the user to input data
   cout << "Enter the price of the item: ";
   cin >> item_price;
   cout << "Enter the sales tax rate (in decimal form): ";
   cin >> tax_rate;

   // 2. Compute sales tax and total due - FUNCTION CALL GOES HERE
   compute_sales_tax_and_total(item_price, tax_rate, sales_tax, total_due);

   // 3. Display results
   cout.setf(ios::showpoint|ios::fixed);  // always show decimal point
                                          // always use fixed notation (vs. scientific)
                                          
   cout.precision(2);   // sets the # of decimal places after '.'
   cout << "The amount sales tax is: " << sales_tax << endl;
   cout << "The total amount due is: " << total_due << endl;

   return 0;
}  // end main

// FUNCTION DEFINITION GOES HERE

void compute_sales_tax_and_total(double price, double rate,
                                 double &tax, double &total)
{
   tax = price * rate;
   total = price + tax;
}
