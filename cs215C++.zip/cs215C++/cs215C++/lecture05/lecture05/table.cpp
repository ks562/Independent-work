// File: table.cpp
// Example of table formatting

#include <iostream>  // cout, endl
#include <cmath>     // pow()
#include <iomanip>   // I/O manipulator, setw(), left, right

int main ()
{
   using namespace std;

   cout << setw(4) << "n" << setw(10) << "2^n" << endl;
   cout << "----" << "    " << "------" << endl;
   for (int i = 0; i < 16; i=i+4)
   // setw - set width of the field to print the next item
      cout << setw(4) << i << setw(10) << pow(2,i) << endl;

   return 0;
}
