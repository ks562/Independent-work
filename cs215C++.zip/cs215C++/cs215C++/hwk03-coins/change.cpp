// Karim Soufan, hwk03-coins
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>

using namespace std;

void compute_change(int num_of_cents, int& dollars,
     int& quarters, int& dimes, int& pennies);

int main(int argc, char** argv)
{
    ifstream input_file(argv[1]);
    ofstream output_file(argv[2]);

    if (!input_file) 
    {
        cerr << "Unable to open " << argv[1] << endl;
        exit(1);
    }

    if (!output_file) 
    {
        cerr << "Unable to open " << argv[2] << endl;
        exit(1);
    }

    output_file << setw(10) << "Amount" << setw(10) << "Dollars"
    << setw(10) <<  "Quarters" << setw(10)<< "Dimes" << setw(10) <<
    "Pennies" << endl << endl;

    int num_of_cents = 0, dollars = 0, quarters = 0,
        dimes = 0, pennies = 0;

    while(input_file >> num_of_cents) 
    {
        compute_change(num_of_cents, dollars, quarters, dimes, pennies);
        output_file << setw(10) << num_of_cents << setw(10) << dollars
         << setw(10) << quarters << setw(10) << dimes
         << setw(10) << pennies << endl;
    }

    input_file.close();
    output_file.close();

    return 0;
}

void compute_change(int num_of_cents, int& dollars,
 int& quarters, int& dimes, int& pennies)
{

    dollars = num_of_cents/100;
    quarters = num_of_cents%100/25;
	dimes = num_of_cents%100%25/10;
	pennies = num_of_cents%100%25%10;
}