// File: node-examples.cpp
// Examples using Node structs

#include <iostream>
#include <string>

// Syntax: typedef <type> <new name>
typedef std::string T;   // set parameter T for Node struct
#include "node.h"        // Node struct

void print_list(Node* first) // REC'D: pointer to the first node of list
{
   // Initialize a loop-control-variable (lcv)
   //    to point to the first node in the list
   Node* scanPtr = first;

   // while not at the end of the list
   while(scanPtr != nullptr)
   {
      // Print out the data in this node
      std::cout << scanPtr->data;
      
      // Print out an arrow if not at the last node
      // if the last link is pointning to the nullptr
      // then we are at the last node
      if(scanPtr->link != nullptr)
         std::cout << " ==> ";

      // Move scanPtr to the next node
      scanPtr = scanPtr->link;
   }
   // Print a newline
   std::cout << std::endl;
}

void insert_at_end(Node * &first, // REC'D and P'BACK: pointer to first node
                                  //   both because list is empty, will need
                                  //   to change the argument
                   const T & item) // REC'D: item to insert
{
   // Create a node with item in it.
   Node* new_node = new Node(item);
   if(first == nullptr)
      // this is the first node, so hook it up to first
      first = new_node;
   else
   {
      // find the last node
      Node* scanptr = first;

      // while not at the last node
      while(scanptr->link != nullptr)
         // Move scanptr to the next node
         scanptr = scanptr->link;

      // Hook up the new node to the last list node
      scanptr->link = new_node;
   }
}

int main ()
{
   using namespace std;

   // Version 1: explicitly use pointer variables for each node
   // Create some nodes
   Node* tom = new Node ("tom");
   Node* rick = new Node ("rick");
   Node* sam = new Node ("sam");
   Node* mary = new Node ("mary");

   // Hook them up into a list
   tom->link = rick;
   rick->link = sam; // Or: tom->link->link = sam
   sam->link = mary;

   // Print the list
   print_list(tom);

   Node *head = nullptr; // pointer to the first node of a list
                         // initially the list is empty
   // Version 2: Build list explicitly adding to the end of the list
   insert_at_end(head, "tom");
   head->link = new Node("rick");
   head->link->link = new Node("sam");
   insert_at_end(head, "mary");
   print_list(head);

   // insert into front of the list
   Node* new_head = new Node("larry");
   new_head->link = head;
   head = new_head;
   print_list(head);

   return 0;
}
