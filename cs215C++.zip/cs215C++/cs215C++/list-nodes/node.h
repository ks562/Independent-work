// File: node.h
// Singly linked-list node

#ifndef NODE_H_
#define NODE_H_

// This struct is intended to be used as an inner class where T has
// been defined as a type parameter.  T can also be defined before
// the header file is included.

struct Node                    
{                              
   T data;        // the data
   Node* link;    // pointer to next node

   // Constructor - default is node with T() data item and null link pointer
   Node (const T & item = T()):
      data(item), link(nullptr) {}
};

#endif  // NODE_H_
