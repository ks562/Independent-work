// File: vectest.cpp
// Driver program for vector<T> and Vector<T>
// From Wittenberg, C++ Data Structures, A Primer 

#include "vector.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <stdexcept>

using namespace std;

template <typename V>
void print_vector(const V& v)
{
   cout << "[";
   for (auto i = 0; i < v.size(); i++) {
      if (i != 0)
	 cout << " "; 
      cout << v[i];
   }
   cout << "]";
}

int main()
{
   // boolalpha is a manipulator that makes bool variables print as true/false
   cout << boolalpha << endl;
   {  // {}'s introduce new scope, so all tests can use v and V variables
      cout << "Tests on default constructed vectors of int" << endl;
      vector<int> v;
      Vector<int> V;
      cout << "empty = " << v.empty() << endl;
      cout << "empty = " << V.empty() << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back(3);
      V.push_back(33);
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back(4);
      V.push_back(44);
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back(5);
      V.push_back(55);
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back(6);
      V.push_back(66);
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back(7);
      V.push_back(77);
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      while (not v.empty()) {
	 v.pop_back();
	 print_vector(v); cout << endl;
      }
      while (not V.empty()) {
	 V.pop_back();
	 print_vector(V); cout << endl;
      }
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
   }
      
   cout << "---" << endl;
   {
      cout << "Tests on default constructed vectors of string" << endl;
      vector<string> v;
      Vector<string> V;
      cout << "empty = " << v.empty() << endl;
      cout << "empty = " << V.empty() << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back("aa");
      V.push_back("AA");
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back("bb");
      V.push_back("BB");
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back("cc");
      V.push_back("CC");
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back("dd");
      V.push_back("DD");
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.push_back("ee");
      V.push_back("EE");
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      while (not v.empty()) {
	 v.pop_back();
	 print_vector(v); cout << endl;
      }
      while (not V.empty()) {
	 V.pop_back();
	 print_vector(V); cout << endl;
      }
      cout << "empty = " << v.empty() << ":  "; print_vector(v); cout << endl;
      cout << "empty = " << V.empty() << ":  "; print_vector(V); cout << endl;
      cout << "size = " << v.size() << endl;
      cout << "size = " << V.size() << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
   }
   cout << "---" << endl;
   {
      cout << "Tests on explicit-value constructed vectors of string" << endl;
      vector<string> v(5, "xx");
      Vector<string> V(5, "XX");
      cout << "size = " << v.size() << ":  "; print_vector(v); cout << endl;
      cout << "size = " << V.size() << ":  "; print_vector(V); cout << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.resize(2); V.resize(2);
      cout << "size = " << v.size() << ":  "; print_vector(v); cout << endl;
      cout << "size = " << V.size() << ":  "; print_vector(V); cout << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      v.resize(9, "yy"); V.resize(9, "YY");
      cout << "size = " << v.size() << ":  "; print_vector(v); cout << endl;
      cout << "size = " << V.size() << ":  "; print_vector(V); cout << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
   }
   cout << "---" << endl;
   {
      cout << "Tests on initializer list constructed vectors of int" << endl;
      vector<int> v = {5, 10, 15, 20, 25, 30};
      Vector<int> V = {9, 14, 19, 24, 29, 34};
      cout << "size = " << v.size() << ":  "; print_vector(v); cout << endl;
      cout << "size = " << V.size() << ":  "; print_vector(V); cout << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      for (auto i = 0; i < v.size(); i++) { v[i]++; }
      for (auto i = 0; i < V.size(); i++) { V[i]++; }
      cout << "size = " << v.size() << ":  "; print_vector(v); cout << endl;
      cout << "size = " << V.size() << ":  "; print_vector(V); cout << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
   }
   cout << "---" << endl;
   {
      cout << "Element access tests on initializer list constructed vectors of string"
	   << endl;
      vector<string> v = { "aa", "bb", "cc" };
      Vector<string> V = { "AA", "BB", "CC" };
      cout << "size = " << v.size() << ":  "; print_vector(v); cout << endl;
      cout << "size = " << V.size() << ":  "; print_vector(V); cout << endl;
      cout << "capacity = " << v.capacity() << endl;
      cout << "capacity = " << V.capacity() << endl;
      cout << "front/back = " << v.front() << "/" << v.back() << endl;
      cout << "front/back = " << V.front() << "/" << V.back() << endl;
      v.push_back("dd"); V.push_back("DD");
      cout << "size = " << v.size() << ":  "; print_vector(v); cout << endl;
      cout << "size = " << V.size() << ":  "; print_vector(V); cout << endl;
      cout << "front/back = " << v.front() << "/" << v.back() << endl;
      cout << "front/back = " << V.front() << "/" << V.back() << endl;
      cout << "[" << v[0] << " " << v[1] << " " << v[2]
	   << " " << v[3] << "]" << endl;
      cout << "[" << V[0] << " " << V[1] << " " << V[2]
	   << " " << V[3] << "]" << endl;
      cout << "[" << v.at(0) << " " << v.at(1) << " " << v.at(2)
	   << " " << v.at(3) << "]" << endl;
      cout << "[" << V.at(0) << " " << V.at(1) << " " << V.at(2)
	   << " " << V.at(3) << "]" << endl;
      try {
	      cout << v.at(4) << endl;
      } catch (out_of_range& e) {
	         cout << "Exception caught:  " << e.what() << endl;
      } 
      try {
	      cout << V.at(4) << endl;
      } catch (out_of_range& e) {
	         cout << "Exception caught:  " << e.what() << endl;
      } 
      try {
	      cout << v.at(-1) << endl;
      } catch (out_of_range& e) {
	         cout << "Exception caught:  " << e.what() << endl;
      } 
      try {
	      cout << V.at(-1) << endl;
      } catch (out_of_range& e) {
	         cout << "Exception caught:  " << e.what() << endl;
      } 
   }

   cout << "---" << endl;
   {
      cout << "Const vector element access tests" << endl;
      const vector<string> v = { "aa", "bb", "cc" };
      const Vector<string> V = { "AA", "BB", "CC" };
      cout << "size = " << v.size() << ":  "; print_vector(v); cout << endl;
      cout << "size = " << V.size() << ":  "; print_vector(V); cout << endl;
      cout << "front/back = " << v.front() << "/" << v.back() << endl;
      cout << "front/back = " << V.front() << "/" << V.back() << endl;
      cout << "[" << v[0] << " " << v[1] << " " << v[2] << "]" << endl;
      cout << "[" << V[0] << " " << V[1] << " " << V[2] << "]" << endl;
      cout << "[" << v.at(0) << " " << v.at(1) << " " << v.at(2)
	   << "]" << endl;
      cout << "[" << V.at(0) << " " << V.at(1) << " " << V.at(2)
	   << "]" << endl;
      try {
	 cout << v.at(3) << endl;
      } catch (out_of_range& e) {
	 cout << "Exception caught:  " << e.what() << endl;
      } 
      try {
	 cout << V.at(3) << endl;
      } catch (out_of_range& e) {
	 cout << "Exception caught:  " << e.what() << endl;
      } 
      try {
	 cout << v.at(-1) << endl;
      } catch (out_of_range& e) {
	 cout << "Exception caught:  " << e.what() << endl;
      } 
      try {
	 cout << V.at(-1) << endl;
      } catch (out_of_range& e) {
	 cout << "Exception caught:  " << e.what() << endl;
      } 
   }
}

