// File: vector.h
// Vector<T> template class
// From Wittenberg, C++ Data Structures, A Primer 

#ifndef VECTOR_H
#define VECTOR_H

#include <algorithm>         // max, fill, copy, swap
#include <initializer_list>  // constructor parameter
#include <stdexcept>         // out_of_range
#include <iostream>

// Since templates must be visible in their entirety, and most vector
// functions are short, in-line the function definitions directly in
// the class definition.  Otherwise, each function definition outside
// the class is template function with Vector<T>:: as the scope
// operator.

template <typename T>
class Vector { // use uppercase V to distinguish from STL vector
  public:
   
   Vector(int num_elements = 0,  // REC'D: number of elements to create
	  const T& init = T())   // REC'D: initial value of each element
   {
      // initialize used and allocate
      // std::max() guards against negative num_elements
      used = allocated = std::max(num_elements, 0);

      // allocate the storage array
      data = new T[allocated]; // or used

      // initialize the elements
      std::fill(data, data + allocated, init);
   }

   Vector(const std::initializer_list<T> & init)  // REC'D: initial elements
   {
      // initialize used and allocate
      used = allocated = init.size();

      // allocate the storage array
      data = new T[allocated]; // or used
      
      // copy elements from init list to storage array
      std::copy(init.begin(), init.end(), data); // 3rd arg is place to copy
   }

   // "Big-3" - necessary when object attributes are directly dynamically allocated.
   // Destructor - deallocate the dynamic data
   // Syntax: its name is ~<class name>
   // Automatically called; never called explicitly
   ~Vector()
   {
      // Debuggin: std::cout << "Destructor" << std::endl;
      delete [] data; // deallocate the array pointed to by data 
   }

   // Copy constructor - constructor that makes a new object that looks
   //                    like the parameter
   Vector (const Vector & source) // must be a const reference parameter
   {
      // copy the primitaive data values
      allocated = source.allocated;
      used = source.used;

      // allocate new data array & copy the source's value
      data = new T[allocated];
      std::copy(source.data, source.data + source.used, data);
   }

   // Assignment operator - make this object look like the source object
   //    "this" is a keyword that is a pointer to this object
   Vector<T>& operator=(const Vector &source)
   {
      // make a copy of the source
      Vector<T> cpy(source); // call the copy constructor

      // swap the contents of this object and the copy
      //    use the swap function in <algorithm> library
      std::swap(allocated, cpy.allocated);
      std::swap(used, cpy.used);
      std::swap(data, cpy.data);

      // when the copy goes out of scope on the return, the destructor
      // is called on it, so the old data gets deallocated.
      return *this; // return a reference to this object,
                    // "this" is a pointer, so need to dereference it first

   }
      
   void resize(int new_size,         // REC'D: number of elements
	       const T& init = T())  // REC'D: initial value of new elements
   {
      // Only resize if asking for more space than currently have
      if(new_size > allocated)
      {
         // Save pointer to the original data
         T *old_data = data;

         // Allocate 2x current allocation or new_size whichever is larger
         //    2x amortizez the cost of reallocation across multiple
         //    push backs.
         allocated = std::max(new_size, 2 * allocated);
         data = new T[allocated];

         // Copy the data to the new array
         std::copy(old_data, old_data + used, data);

         // Deallocate the old data array
         delete [] old_data;
      }

      // If made larger, initialize new elements
      if(new_size > used)
      {
         std::fill(data + used, data + new_size, init);
      }

      // Set used to new size
      used = new_size;
   }
      
   void push_back(const T& value)  // REC'D: element to add to back
   {
      // Use resize to check/ask for enough space
      resize(used + 1);
	 
      // Store value, note resize changes used to requested size
      data[used - 1] = value;

   }
      
   void pop_back()
   {
      if(used > 0) // don't want negative size
         used--;
   }
      
   // T& is the returned type so that the result can be used
   //    on the left side of an assignment. E.G., v[i] = x;
   T& operator[](int index)  // REC'D: index of element to access
   {
      return data[index]; // no bounds checking
   }

   // First const says that the returned reference cannot be used
   //    to change the internal data
   // Second const is the same as other accessors: operation itself
   //    will not change this object
   const T& operator[](int index) const  // REC'D: index of element to access
   {
      return data[index]; // no bounds checking
   }
      
      
   T& at(int index)  // REC'D: index of element to access
   {
      if(index < 0 || index >= used) // do bounds checking
         throw std::out_of_range("Vector index out of range");
      return data[index];
   }

   const T& at(int index) const // REC'D: index of element to access
   {
      if(index < 0 || index >= used) // do bounds checking
         throw std::out_of_range("Vector index out of range");
      return data[index];
   }
      
   T& front()
   {  
      return data[0];
   }
      
   T& back()
   {  
      return data[used - 1];
   }

   const T& front() const
   {  
      return data[0];
   }
      
   const T& back() const
   {  
      return data[used - 1];
   }
      
   void clear() // makevthe vector empty
   {  
      used = 0;
   }
      
   int size() const
   { return used; }
      
   int capacity() const
   { return allocated; }
      
   bool empty() const
   { return size() == 0; }
      
  private:

   int allocated,  // number of elements in the data array
      used;       // number of elements being used
      
   // pointer to dynamically allocated array of T's
   T *data;
      
};

#endif
