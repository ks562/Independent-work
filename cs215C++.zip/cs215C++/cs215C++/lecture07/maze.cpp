// File: maze.cpp
// Based on Ch. 7 Case Study: Escaping from a Maze
// Dale, et al., C++ Plus Data Structures, 6/e, p. 481-494
// Needs to be compiled with -std=c++11

#include <fstream>   // ifstream type
#include <iostream>  // cin, cout, endl
#include <string>    // string type
#include <cstdlib>   // exit()
#include <unistd.h>  // Unix standard library: system, usleep

const int MAZE_SIZE = 10;

// Function to create a maze grid
void CreateMaze (std::ifstream& inFile,           // REC'D/P'BACK: input file
		 char maze[MAZE_SIZE][MAZE_SIZE], // P'BACK: filled maze grid
                 int &maxRows, int &maxCols);     // P'BACK: # rows/cols filled

// Function to print a maze grid
void PrintMaze(const char maze[MAZE_SIZE][MAZE_SIZE], // REC'D: grid to print
	       int maxRows, int maxCols);             // REC'D: # rows/cols

// Function to try to find path to exit staring at [row][col]
bool TryToEscape (char maze[MAZE_SIZE][MAZE_SIZE], // REC'D/P'BACK: maze grid
		  int row, int col,                          // REC'D: start location
        int maxRows, int maxCols);         

void Try(char maze[MAZE_SIZE][MAZE_SIZE], int row, int col,
         int maxRows, int maxCols, bool &free);      

int main(int argc, char *argv[])
{
   using namespace std;

   if (argc != 2)
   {
      cout << "Usage: " << argv[0] << " mazefile" << endl;
      exit(1);
   }
   
   ifstream inFile (argv[1]);
   if (!inFile)
   {
      cout << "Error: unable to open mazefile" << endl;
      exit(1);
   }
   
   char maze[MAZE_SIZE][MAZE_SIZE];  // maze grid
   int maxRows;		             // number of rows filled
   int maxCols;		             // number of columns filled
   CreateMaze (inFile, maze, maxRows, maxCols);
   PrintMaze (maze, maxRows, maxCols);
   
   int row, col;       // starting position indexes
   bool free = false;  // true if escaped the maze, false otherwise

   // Ask user for starting location
   cout << "\nEnter row (1-" << maxRows << ") and col (1-" << maxCols
	<< ") of starting position: ";
   cin >> row >> col;
   
   // Try to find a path to exit from [row][col]
   // Note: don't need to pass maxRows and maxCols, since the grid
   // border prevents going off the grid, assume row, col are valid indexes
   if (TryToEscape(maze, row, col, maxRows, maxCols))
      cout << "\nFree" << endl;
   else
      cout << "\nTrapped" << endl;

   maze[row][col] = 'S';  // mark the starting location for printing
   PrintMaze(maze, maxRows, maxCols);

   Try(maze, row, col, maxRows, maxCols, free);

   return 0;
}

void CreateMaze (std::ifstream& inFile, char maze[MAZE_SIZE][MAZE_SIZE],
                 int &maxRows, int &maxCols)
{
   int rowIndex, colIndex;
   inFile >> maxRows >> maxCols;

   std::string row;
   // Read each row from the file
   for (rowIndex = 1; rowIndex <= maxRows; rowIndex++)
   {
      inFile >> row;
      // Set left border character
      maze[rowIndex][0] = '+';
      // Copy row to maze grid
      for (colIndex = 1; colIndex <= maxCols; colIndex++)
	 maze[rowIndex][colIndex] = row[colIndex-1];
      // Set right border character
      maze[rowIndex][maxCols+1] = '+';
   }

   // Set top and bottom border characters
   for (colIndex = 0; colIndex <= maxCols+1; colIndex++)
   {
      maze[0][colIndex] = '+';
      maze[maxRows+1][colIndex] = '+';
   }
}

void PrintMaze(const char maze[MAZE_SIZE][MAZE_SIZE], int maxRows, int maxCols)
{
   using namespace std;
   int rowIndex, colIndex;
  
   system ("clear");  // only works in Unix
   cout << "\nMaze" << endl;
   // For each row
   for (rowIndex = 1; rowIndex <= maxRows; rowIndex++)
   {
      // Print each character in a row
      for (colIndex = 1; colIndex <= maxCols; colIndex++)
	 cout << " " << maze[rowIndex][colIndex];
      cout << endl;
   }
   usleep (1000000); // .1 sec, only works in Unix
}

bool TryToEscape (char maze[MAZE_SIZE][MAZE_SIZE], int row, int col,
                  int maxRows, int maxCols)
{
   bool free = false;  // initialize for first call

   // CALL TO RECURSIVE HELPER FUNCTION GOES HERE

   return free;
}

void Try(char maze[MAZE_SIZE][MAZE_SIZE], int row, int col,
         int maxRows, int maxCols, bool &free)
{
   // Base cases:
   //    - found the exit, so we're free
   //    - found a wall (+), so we need to back
   if(maze[row][col] == 'E')
   {
      free = true;
      return;
   }

   //    - found a wall (+) or have visited before (*),
   //      so we need to back, do nothing
   if(maze[row][col] == '+' || maze[row][col] == '*')
      return;

      // Smaller version: set the cell to * (visited)
      maze[row][col] = '*';
      PrintMaze(maze, maxRows, maxCols); // print out grid to see the path
                                         // being found

      //Recursive step - how to use the smaller version to solve the original
      //    pick a direction and try again
      // Go down
      Try(maze, row + 1, col, maxRows, maxCols, free);
      if(!free) // try left
         Try(maze, row, col - 1, maxRows, maxCols, free);
      if(!free) // try up
         Try(maze, row - 1, col, maxRows, maxCols, free);
      if(!free) // try right
         Try(maze, row, col + 1, maxRows, maxCols, free);

      // if haven't the solution, erase the mark
      if(!free)
         maze[row][col] = 'O';
}
