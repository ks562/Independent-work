// File: binary-search.cpp
// Inclass exercise for 9/6/2019

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib> // exit()

// Function prototypes go here
void read_datafile (std::ifstream &infile, // REC'D/P'BACK: input filestream
		    int array[],           // P'BACK: array to be filled
		    int &num_elements);    // P'BACK: # elements filled
void print_array (const int array[],       // REC'D: array to print
		  int num_elements);       // REC'D: # elements filled

int binary_search(const int array[], // REC'D: array to be searched
                  int lower, // REC'D: lower index of the range to search
                  int upper, // REC'D: upper index of the range to search
                  int target); // REC'D: target value

const int ARRAY_SIZE = 100;  // C++ constant; don't use #define

int main(int argc, char *argv[])
{
   using namespace std;

   if (argc != 2)
   {
      cerr << "Usage: " << argv[0] << " datafile" << endl;
      exit(1);
   }

   ifstream infile (argv[1]);
   if (!infile)
   {
      cerr << "Unable to open file: " << argv[1] << endl;
      exit(1);
   }

   int n, target, position;
   int an_array[ARRAY_SIZE];

   read_datafile(infile, an_array, n);
   print_array(an_array, n);

   cout << "\nEnter an integer to search for: ";
   cin >> target;

   // FUNCTION CALL GOES HERE

   if (position != -1)
      cout << "The target is at index: " << position << endl;
   else
      cout << "The target is not in the file" << endl;

   return 0;
}

// Function definition goes here
// Function: binary_search (using recursion)
//    Return the index of the target value, if found
//             -1, otherwise
int binary_search(const int array[], // REC'D: array to be searched
                  int lower, // REC'D: lower index of the range to search
                  int upper, // REC'D: upper index of the range to search
                  int target) // REC'D: target value
{
   // Base cases:
   //    target is found at the middle value in the range
   //    target is not found when range is empty ==> lower > upper

   // check if not found
   if(lower > upper)
      return -1;

   // check if found
   int mid_index = (lower + upper) / 2;
   if(array[mid_index] == target)
      return mid_index;

   // What is the smaller version? The range on the side that might contain
   //    the target value ==> compare mid value with target
   // How is the solution to the smaller version related to the original version
   //    The result of the smaller version IS the result of the original version
   if(target < array[mid_index]) // search the left half
      return binary_search(array, lower, mid_index - 1, target);

   // search the right half
   return binary_search(array, mid_index + 1, upper, target);
   

}





// Function definitions goes here
void read_datafile (std::ifstream &infile, int array[], int &num_elements)
{
   int value;
   num_elements = 0;
   while (infile >> value)  // read until end of file
   {
      // put the value into the array
      array[num_elements] = value;
      // count the value
      num_elements++;
   }
} // end read_datafile

void print_array (const int array[], int num_elements)
{
   using namespace std;

   for (int i = 0; i < num_elements; i++)
   {
      // output a newline before every 10 elements
      if (i % 10 == 0)
	 cout << endl;
      cout << setw(4) << array[i];
   }
   // Output should end with a newline
   cout << endl;
} // end print_array
