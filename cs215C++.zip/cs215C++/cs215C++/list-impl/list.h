// File: list.h
// List<T> template class
// From Wittenberg, Data Structures and Algorithms in C++ Pocket Primer
// Ch. 3

#ifndef LIST_H
#define LIST_H

#include <initializer_list>
#include <algorithm>

template <typename T>
class List {  // uppercase L to distinguish from STL list
   private: // private type declarations
      #include "dnode.h"  // doubly-linked Node struct
   
      // Don't worry about this inner class
      template <typename U>  // iterator template class
      class Iter {
	 private:
	    Node *curr;
	    friend class List<T>;  // allows List<T> access to curr
	 public:
	    Iter(Node *p) : curr(p) {}
	    U& operator *  () const { return curr->data; }
	    U* operator -> () const { return &(curr->data); }
	    bool operator == (const Iter<U>& other) const
	    { return curr == other.curr; }
	    bool operator != (const Iter<U>& other) const
	    { return curr != other.curr; }
	    Iter<U>& operator ++ ()         // prefix ++
	    { curr = curr->rlink; return *this; }
	    Iter<U> operator ++ (int)       // postfix ++
	    { Iter<U> result = Iter<U>(curr); curr = curr->rlink;
	      return result; }
      };  // end Iter private inner class
      
   public:
      // Iterator types and operations
      // Don't worry about these operations
      typedef Iter<T> iterator;
      typedef Iter<const T> const_iterator;
      iterator begin()       {return iterator(first);}
      const_iterator begin() const {return const_iterator(first);}
      iterator end()       {return iterator(nullptr);}
      const_iterator end() const {return const_iterator(nullptr);}

      // Default constructor, empty list
      List() : count(0), first(nullptr), last(nullptr) {}

      // C++11 initializer list constructor
      // C++11 constructor forwarding initializes attributes
      List(std::initializer_list<T> init) : List()
      {
         // Iterate through the init list and oush them on one at a time
         for(auto p = init.begin(); p != init.end(); p++)
            push_back(*p);
      }
   
      // Copy constructor
      List(const List<T>& source) : List()
      {
         // Note this uses the iterator type of List<T>
         for(auto p = source.begin(); p != source.end(); p++)
            push_back(*p);
      }
   
      // Destructor
      ~List()
      {
         // Delete all nodes
         clear();
      }
      
      // Assignment
      List<T>& operator = (const List<T>& other)
      {
         // DIFFERENT THAN IN THE TEXTBOOK!!
         // make a copy of other
         List<T> copy(other);
         // swap the contents of this and the copy
         std::swap(count, copy.count);
         std::swap(first, copy.first);
         std::swap(last, copy.last);
         // on return, destructor will be called on copy variable
         // which will delete the old data
         return *this;
      }

      // Accessors
      int size() const { return count; }
      bool empty() const { return size() == 0; }
      // Need const and non-const version for front/back
      // STL does not check for empty
      T& front()       { return first->data; }
      const T& front() const { return first->data; }
      T& back()       { return last->data; }
      const T& back() const { return last->data; }

      // Insert in front of node at pos, returns iterator to new node
      iterator insert(iterator pos, const T& value)
      {
         // Create a new node
         Node* ptr = new Node (value);
         // "Hook up" (up to) 4 pointers
         // 1. Always hook up the new Node's rlink to pos's pointer
         ptr->rlink = pos.curr;
         // 2. Hook up new Node's llink
         if(pos.curr == nullptr)
            // Connect new Node's llink to tail
            ptr->llink = last;
         else
            // Connect new Node's llink to pos's pointer's llink
            ptr->llink = pos.curr->llink; 
         // 3. Hook up previous node to new node, if it exists
         if(ptr->llink != nullptr)
            ptr->llink->rlink = ptr;
         // 4. Hook up next node to new node, if exists
         if(ptr->rlink != nullptr)
            ptr->rlink->llink = ptr;
         // Was inserted in front?
         if(pos == begin())
            first = ptr;
         // Was inserted in back?
         if(pos == end())
            last - ptr;
         // Count new node
         count++;
         // Return an iterator to the new node
         return iterator(ptr);
      }

      // Delete node at pos, returns iterator to next item
      iterator erase(iterator pos)
      {
         // Create result object - iterator to next node
         iterator result (pos.curr->rlink);

         // Update (up to) 2 pointers
         if(pos.curr == first) // no precious node
            first = first->rlink;
         else
            // Connect the rlink of previous node to the next node
            pos.curr->llink->rlink = pos.curr->rlink;
         if(pos.curr == last) // no next node
            last = last->llink;
         else
            // Connect the llink of next node to the previous node
            pos.curr->rlink->llink = pos.curr->llink;
         // "Uncount" the erased node
         count--;
         // Deallocate the erased node
         delete pos.curr;
      }

      // Other modifiers
      // Implemented using insert and erase
      void push_front(const T& value) { insert(begin(), value); }
      void push_back(const T& value)  { insert(end(), value); }
      void pop_front() { erase(begin()); }
      void pop_back()  { erase(iterator(last)); }

      // Delete all nodes, reinitialize attributes
      void clear()
      {
         while (first != nullptr) // use first as a scan pointer
         {
            Node* curr = first;  // save pointer to the node
            first = first->rlink; // go to the next node
            delete curr;         // dealloc node
         }
         // first will be nullptr here
         last = nullptr;
         count = 0;
      }

   private:
      int count;  // number of nodes in list
      Node* first; // pointer to first node
      Node* last;  // pointer to last node
};  // end List class

#endif
