#include "list.h"
#include <iostream>
#include <iomanip>
#include <list>
#include <string>
#include <stdexcept>

using namespace std;

template <typename L>
void print_list(const L& l)
{
   cout << "[";
   for (auto p = l.begin(); p != l.end(); p++) {
      if (p != l.begin()) { cout << " "; }
      cout << *p;
   }
   cout << "]";
}

int main()
{
   cout << boolalpha << endl;
   {
      cout << "push_back/pop_back tests with ints" << endl;
      list<int> l;
      List<int> L;
      cout << "empty = " << l.empty() << endl;
      cout << "empty = " << L.empty() << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back(3);
      L.push_back(33);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back(4);
      L.push_back(44);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back(5);
      L.push_back(55);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back(6);
      L.push_back(66);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back(7);
      L.push_back(77);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      while (not l.empty()) {
	 l.pop_back();
	 print_list(l); cout << endl;
      }
      while (not L.empty()) {
	 L.pop_back();
	 print_list(L); cout << endl;
      }
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
   }
   cout << "---" << endl;
   {
      cout << "push_front/pop_front tests with ints" << endl;
      list<int> l;
      List<int> L;
      cout << "empty = " << l.empty() << endl;
      cout << "empty = " << L.empty() << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front(3);
      L.push_front(33);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front(4);
      L.push_front(44);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front(5);
      L.push_front(55);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front(6);
      L.push_front(66);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front(7);
      L.push_front(77);
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      while (not l.empty()) {
	 l.pop_front();
	 print_list(l); cout << endl;
      }
      while (not L.empty()) {
	 L.pop_front();
	 print_list(L); cout << endl;
      }
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
   }
   cout << "---" << endl;
   {
      cout << "push_back/pop_back tests with string" << endl;
      list<string> l;
      List<string> L;
      cout << "empty = " << l.empty() << endl;
      cout << "empty = " << L.empty() << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back("aa");
      L.push_back("AA");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back("bb");
      L.push_back("BB");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back("cc");
      L.push_back("CC");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back("dd");
      L.push_back("DD");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_back("ee");
      L.push_back("EE");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      while (not l.empty()) {
	 l.pop_back();
	 print_list(l); cout << endl;
      }
      while (not L.empty()) {
	 L.pop_back();
	 print_list(L); cout << endl;
      }
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
   }
   cout << "---" << endl;
   {
      cout << "push_front/pop_front tests with string" << endl;
      list<string> l;
      List<string> L;
      cout << "empty = " << l.empty() << endl;
      cout << "empty = " << L.empty() << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front("aa");
      L.push_front("AA");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front("bb");
      L.push_front("BB");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front("cc");
      L.push_front("CC");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front("dd");
      L.push_front("DD");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      l.push_front("ee");
      L.push_front("EE");
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
      while (not l.empty()) {
	 l.pop_front();
	 print_list(l); cout << endl;
      }
      while (not L.empty()) {
	 L.pop_front();
	 print_list(L); cout << endl;
      }
      cout << "empty = " << l.empty() << ":  "; print_list(l); cout << endl;
      cout << "empty = " << L.empty() << ":  "; print_list(L); cout << endl;
      cout << "size = " << l.size() << endl;
      cout << "size = " << L.size() << endl;
   }
   cout << "---" << endl;
   {
      cout << "Initializer and copy construction tests with int" << endl;
      list<int> l = {5, 10, 15, 20, 25, 30};
      List<int> L = {9, 14, 19, 24, 29, 34};
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      for (auto p = l.begin(); p != l.end(); p++) { (*p)++; }
      for (auto p = L.begin(); p != L.end(); p++) { (*p)++; }
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      list<int> w(l);
      List<int> W(L);
      cout << "size = " << w.size() << ":  "; print_list(w); cout << endl;
      cout << "size = " << W.size() << ":  "; print_list(W); cout << endl;
      l.clear(); L.clear();
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      cout << "size = " << w.size() << ":  "; print_list(w); cout << endl;
      cout << "size = " << W.size() << ":  "; print_list(W); cout << endl;
   }
   cout << "---" << endl;
   {
      cout << "Initializer and assignment tests with string" << endl;
      list<string> l = { "aa", "bb", "cc" };
      List<string> L = { "AA", "BB", "CC" };
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      list<string> w; List<string> W;
      w = l; W = L;
      cout << "size = " << w.size() << ":  "; print_list(w); cout << endl;
      cout << "size = " << W.size() << ":  "; print_list(W); cout << endl;
      for (auto p = l.begin(); p != l.end(); p++) { *p = *p + '1'; }
      for (auto p = L.begin(); p != L.end(); p++) { *p = *p + '1'; }
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      cout << "size = " << w.size() << ":  "; print_list(w); cout << endl;
      cout << "size = " << W.size() << ":  "; print_list(W); cout << endl;
   }
   cout << "---" << endl;
   {
      cout << "Iterator and insert/erase tests with string" << endl;
      list<string> l = { "aa", "bb", "cc" };
      List<string> L = { "AA", "BB", "CC" };
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      cout << "front/back = " << l.front() << "/" << l.back() << endl;
      cout << "front/back = " << L.front() << "/" << L.back() << endl;
      l.push_back("dd"); L.push_back("DD");
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      cout << "front/back = " << l.front() << "/" << l.back() << endl;
      cout << "front/back = " << L.front() << "/" << L.back() << endl;
      l.push_front("zz"); L.push_front("ZZ");
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      cout << "front/back = " << l.front() << "/" << l.back() << endl;
      cout << "front/back = " << L.front() << "/" << L.back() << endl;
      auto p = l.begin(); ++(++(++p)); cout << *p << endl;
      p = l.insert(p, "xx"); cout << *p << endl;
      auto P = L.begin(); ++(++(++P)); cout << *P << endl;
      P = L.insert(P, "XX"); cout << *P << endl;
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      cout << "front/back = " << l.front() << "/" << l.back() << endl;
      cout << "front/back = " << L.front() << "/" << L.back() << endl;
      p = l.begin(); ++p; p = l.erase(p); cout << *p << endl;
      P = L.begin(); ++P; P = L.erase(P); cout << *P << endl;
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      cout << "front/back = " << l.front() << "/" << l.back() << endl;
      cout << "front/back = " << L.front() << "/" << L.back() << endl;
   }
   cout << "---" << endl;
   {
      cout << "Const list accessor tests" << endl;
      const list<string> l = { "aa", "bb", "cc", "dd", "ee" };
      const List<string> L = { "AA", "BB", "CC", "DD", "EE" };
      cout << "size = " << l.size() << ":  "; print_list(l); cout << endl;
      cout << "size = " << L.size() << ":  "; print_list(L); cout << endl;
      cout << "front/back = " << l.front() << "/" << l.back() << endl;
      cout << "front/back = " << L.front() << "/" << L.back() << endl;
      auto p = l.begin(); ++(++(++p)); cout << *p << endl;
      auto P = L.begin(); ++(++(++P)); cout << *P << endl;
   }
   cout << "---" << endl;
   {
      cout << "Range-based loop test" << endl;
      list<string> l = { "aa", "bb", "cc", "dd"};
      List<string> L = { "AA", "BB", "CC", "DD" };
      for (auto x: l) { cout << x << " "; }; cout << endl;
      for (auto x: L) { cout << x << " "; }; cout << endl;
   }
   cout << "---" << endl;
   {
      cout << "Const range-based loop test" << endl;
      const list<string> l = { "aa", "bb", "cc", "dd"};
      const List<string> L = { "AA", "BB", "CC", "DD" };
      for (auto x: l) { cout << x << " "; }; cout << endl;
      for (auto x: L) { cout << x << " "; }; cout << endl;
   }
   cout << "---" << endl;
   {
      cout << "Templated type parameter test" << endl;
      // pair<T1, T2> is an STL struct template with field first and second
      // prior to C++11, needed space after templated type parameter
      // because compiler could not distinguish from operator>>
      //    e.g. list <pair<int,string> > l
      list <pair<int,string>> l = { {1, "aa"}, {2, "bb"}, {3, "cc"} };
      List <pair<int,string>> L = { {1, "AA"}, {2, "BB"}, {3, "CC"} };
      for (auto p = l.begin(); p != l.end(); p++) {
	 cout << "<" << p->first << "," << p->second << "> ";
      } cout << endl;
      for (auto p = L.begin(); p != L.end(); p++) {
	 cout << "<" << p->first << "," << p->second << "> ";
      } cout << endl;
   }
}
