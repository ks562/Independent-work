// File: concordance.cpp
// This program produces text concordance
//
// ------------------------------------------------------------------
// Class: CS 215                      Instructor: Dr. Deborah Hwang
// Assignment: Project 7a             Date assigned: Fri, Nov 22
// Programmer: Karim Soufan           Date completed: Wed, Dec 4

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <string>

using namespace std;

void insert_word_in_list(list<string> &l, // REC'D/P'BACK
                         string word); // REC'D

void print_vector(const vector<list<string>> & v, // REC'D
                        ostream &out); // REC'D/PBACK
void print_list(const list<string> & l, // REC'D
                        ostream &out); // REC'D/P'BACK

int main(int argc, char* argv[])
{
    // error checking for the number of arguments
    if (argc != 3)
    {
        cerr << "Usage: " << argv[0] <<
         " input_file output_file" << endl;
        exit(1);
    }

    // define and initiate the I/O files
    ifstream input_file(argv[1]);
    ofstream output_file(argv[2]);

    // error checking for input file
    if (!input_file)
    {
        cerr << "Cannot open input file "
         << argv[1] << endl;
        exit(1);
    }

    // error checking for output file
    if (!output_file)
    {
        cerr << "Cannot open output file "
         << argv[2] << endl;
        exit(1);
    }

    vector<list<string>> v(26);
    string word;
    int index;

    while (input_file >> word)
    {
        index = word[0] - 'a';
        insert_word_in_list(v[index], word);
    }
    print_vector(v, output_file);

    input_file.close();
    output_file.close();

    return 0;
}

void insert_word_in_list(list<string> &l, string word)
{
    if(!l.empty())
    {
        list<string>::iterator it;
        for(it = l.begin(); it != l.end(); ++it)
        {
            if(word < *it)
                l.insert(it, word);

            else if(*it < word)
            {
                if(it == --l.end())
                    l.push_back(word);
            }
            else
                break;
            
            

        }
    }

    else
        l.push_back(word);
}

void print_list(const list<string> & l, ostream &out)
{
    for(auto i = l.begin(); i != l.end(); ++i)
    {
        out << *i << " ";
    }
}

void print_vector(const vector<list<string>> & v, ostream &out)
{
    
    for(int i = 0; i < v.size(); i++)
    {
        if(!v[i].empty())
        {
            print_list(v[i], out);
            out << endl;
        }
    }
}
