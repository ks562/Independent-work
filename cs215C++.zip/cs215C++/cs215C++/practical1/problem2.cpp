// File: problem2.cpp
// A program to test the Point class
// ----------------------------------------------------------------------
// Class: CS 215                      
// Assignment: Programming Practical Exam 1, Problem 2
// Programmer: Karim Soufan
// Date: October 1 & 2, 2019

#include <iostream>      // cin, cout, endl;
#include "point.h"       // Point class
using namespace std;

int main ()  // no command line arguments
{

   Point p1;             //  Default constructed: (0,0)
   Point p2(1.5);
   Point p3(2.0, 4.0);
   Point point1, point2;

   cout << "Explicit constructed point\n";
   cout << "   x-coordinate of p2 = " << p2.x_coord() << endl;
   cout << "   y-coordinate of p2 = " << p2.y_coord() << endl << endl;

   cout << "   Magnitude of p2 = " << p2.magnitude() << endl;

   cout << "   x-coordinate of p3 = " << p3.x_coord() << endl;
   cout << "   y-coordinate of p3 = " << p3.y_coord() << endl;
   cout << "   Magnitude of p3 = " << p3.magnitude() << endl << endl;

   cout << "Please enter a point (x,y): ";
   cin >> point1;
   cout << "The point tyou entered is: " << point1 << endl;

   cout << "Please enter another point (x,y): ";
   cin >> point2;
   cout << "The other point you entered is: " << point2 << endl << endl;

   if(point1 == point2)
      cout << "The two points are equal!" << endl;
   else
      cout << "The two points are NOT equal!" << endl;

   cout << "The sum of point1 and point2 is = " << point1 + point2 << endl;

   cout << "Default constructed point\n";
   cout << "   x-coordinate: " << p1.x_coord() << endl;
   cout << "   y-coordinate: " << p1.y_coord() << endl;

   return 0;
}  // end main
