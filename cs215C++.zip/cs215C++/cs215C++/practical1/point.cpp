// File: point.cpp
// Implementation of the Point class operations
// ----------------------------------------------------------------------
// Class: CS 215                      
// Assignment: Programming Practical Exam 1, Problem 2
// Programmer: Karim Soufan
// Date: October 1 & 2, 2019

#include "point.h"
#include <iostream>
#include <cmath>

// Constructors
Point::Point(double initial_x, double initial_y) : x(0.0), y(0.0)
{
   x = initial_x;
   y = initial_y;
}

// Accessors
double Point::x_coord () const
{
   return x;
}  // end get_x

double Point::y_coord () const
{
   return y;
}  // end get_y

double Point::magnitude()
{
   return sqrt(pow(x, 2) + pow(y, 2));
}

bool operator==(const Point & lhs, const Point & rhs)
{
   return (lhs.x == rhs.x && lhs.y == rhs.y);
}

Point operator+(const Point & lhs, const Point & rhs)
{
   Point sum(lhs.x + rhs.x, lhs.y + rhs.y);
   return sum;
}

std::ostream& operator<<(std::ostream &out, const Point & p)
{
   return out << "(" << p.x << "," << p.y << ")";
}

std::istream& operator>>(std::istream &in, Point &p)
{
   char ch;
   return in >> ch >> p.x >> ch >> p.y >> ch;
}




