// File: point.h
// Definition of the Point class
// ----------------------------------------------------------------------
// Class: CS 215                      
// Assignment: Programming Practical Exam 1, Problem 2
// Programmer: Karim Soufan
// Date: October 1 & 2, 2019

#ifndef POINT_H_
#define POINT_H_

#include <iostream>

class Point
{
   public:  // Operations

      // Constructors
      Point (double initial_x = 0.0, double initial_y = 0.0);

      // Accessors
      double x_coord () const;
      double y_coord () const;

      double magnitude();

      // Operators
      friend bool operator==(const Point & lhs, const Point & rhs);
      friend Point operator+(const Point & lhs, const Point & rhs);
      friend std::ostream& operator<<(std::ostream& out, const Point & p);
      friend std::istream& operator>>(std::istream& in, Point &p);

   private:  // Attributes

      double x, y;  // Coordinates for point (x,y)

};  // end Point class

#endif // POINT_H_
