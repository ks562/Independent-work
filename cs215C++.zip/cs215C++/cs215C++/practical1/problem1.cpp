// Karim Soufan
#include <iostream>
#include <fstream>

using namespace std;

int solve_recursively(int n, int k);

int main(int argc, char* argv[])
{

    if(argc != 3)
    {
        cerr << "Usage: " << argv[0] << "input file outputfile" << endl;
        exit(1);
    }

    ifstream input_file(argv[1]);
    ofstream output_file(argv[2]);

    if(!input_file)
    {
        cerr << "Cannot open input file " << argv[1] << endl;
        exit(1);
    }

    if(!output_file)
    {
        cerr << "Cannot open output file " << argv[2] << endl;
        exit(1);
    }

    int n = 0, k = 0;

    while(input_file >> n)
    {
        input_file >> k;
        output_file << "Number of combinations for "<< n << " choose "
                    << k << " is " << solve_recursively(n, k) << endl;
    }
}

int solve_recursively(int n, int k)
{
    if(k == 1)
        return n;

    if(k == n)
        return 1;

    return solve_recursively(n - 1, k - 1) + solve_recursively(n - 1, k);
}