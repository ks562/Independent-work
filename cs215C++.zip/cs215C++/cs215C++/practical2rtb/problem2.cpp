// File: problem2rt.cpp
// Program to test DynamicStack class
//
// ----------------------------------------------------------------------
// Class: CS 215
// Date: December 5, 2019
// Assignment: Programming Practical Exam 2 Retake, Problem 2
// Programmer: Karim Soufan

#include <iostream>
#include "dynstack.h"

int main()
{
   using namespace std;

   DynamicStack dstack;
   int value;
   char command;

   cout << "\nDo you want to get top value (t), push (s), pop (p),"
        << " or quit (q): ";
   cin >> command;
   command = tolower(command);

   // Apply commands on dstack
   while (command != 'q')
   {
      if (command == 's')
      {
         cout << "Pushing a value" << endl;
         cout << "Enter an integer: ";
         cin >> value;
         dstack.push(value);
      }
      else if (command == 'p')
      {
         try
         {
            cout << "Popping off top value" << endl;
            dstack.pop();
         }
         catch(const underflow_error& e)
         {
            cerr << e.what() << endl;
            cerr << "No elements to pop" << endl;
         }
         
      }
      else if(command == 't')
      {
         try
         {
            cout << "displaying the top element" << endl;
            cout << dstack.top() << endl;
         }
         catch(const underflow_error& e)
         {
            cerr << e.what() << endl;
            cerr << "Top cannot be found" << endl;
         }
         
      }
      else
      {
         cout << "Unknown command.  Try again." << endl;
      }

      cout << "\nDo you want to get top value (t), push (s), pop (p),"
           << " or quit (q): ";
      cin >> command;
      command = tolower(command);
   }

   return 0;
} // end main
