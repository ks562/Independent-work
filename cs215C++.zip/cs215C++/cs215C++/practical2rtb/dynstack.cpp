// File: dynstack.cpp
// Implementation of the DynamicStack operations
//
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Date: December 5, 2019
// Assignment: Practical Exam 2 Retake, Problem 2
// Programmer: Karim Soufan

#include "dynstack.h"
#include <algorithm>
#include <stdexcept>
using namespace std;

DynamicStack::DynamicStack()
{
   data = nullptr;
   top_index = -1;
   capacity = 0;
}

void DynamicStack::push(int entry)
{
   if (capacity == 0)
   {
      data = new int[2];
      capacity = 2;
   }
   else
   {
      data = new int[2 * capacity];
      capacity = 2 * capacity;
   }
   top_index++;
   data[top_index] = entry;
}

void DynamicStack::pop()
{
   if (empty())
      throw underflow_error("The stack is empty! (pop)");

   top_index--;
}

bool DynamicStack::empty() const
{
   return (top_index == -1);
}

int DynamicStack::top() const
{
   if (empty())
      throw underflow_error("The stack is empty! (top)");

   return data[top_index];
}

DynamicStack::~DynamicStack()
{
   delete[] data;
}

DynamicStack::DynamicStack(const DynamicStack &source)
{
   this->capacity = source.capacity;
   this->top_index = source.top_index;
   data = new int[capacity];
   for (int i = 0; i < capacity; i++)
      data[i] = source.data[i];
}

DynamicStack &DynamicStack::operator=(const DynamicStack &source)
{
   DynamicStack cpy(source);

   swap(this->capacity, cpy.capacity);
   swap(this->top_index, cpy.top_index);
   swap(this->data, cpy.data);

   return *this;
}
