// File: dynstack.h
// Class definition for a stack of integers implemented using a dynamic array
//
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Date: April 30, 2014
// Assignment: Practical Exam 2 Retake, Problem 2
// Programmer: Karim Soufan

#ifndef DYNSTACK_H_
#define DYNSTACK_H_

class DynamicStack
{
   public:
      // Constructors
      DynamicStack( );

      // Accessors
      bool empty( ) const;
      int top() const;

      // Mutators
      void push(int entry);
      void pop();

      ~DynamicStack();
      DynamicStack(const DynamicStack &source);
      DynamicStack& operator=(const DynamicStack &source);
	 

   private:
      int* data;
      int top_index;       // Index of the top element
      int capacity;        // Number of elements array can hold

};  // end class DynamicStack

#endif
