#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void translate_sentence(string english_sentence, string &piglatin_sentence);
void translate_word(string english_word, string &piglatin_word);

int main(int argc, char* argv[])
{
    if(argc != 3)
    {
        cerr << "Usage: " << argv[0] << " input file outputfile" << endl;
        exit(1);
    }

    ifstream input_file(argv[1]);
    ofstream output_file(argv[2]);

    if(!input_file)
    {
        cerr << "Cannot open input file " << argv[1] << endl;
        exit(1);
    }

    if(!output_file)
    {
        cerr << "Cannot open output file " << argv[2] << endl;
        exit(1);
    }

    string line, piglatin_sentence;
   
    while(getline(input_file, line))
    {
        translate_sentence(line, piglatin_sentence);
        output_file << piglatin_sentence;
        if(!input_file.eof())
            output_file << endl;
    }

    input_file.close();
    output_file.close();

    return 0;
}

void translate_sentence(string english_sentence, string &piglatin_sentence)
{
    string word, piglatin_word;
    size_t index_of_space = 0, index_of_next_space = 0; 

    index_of_space = english_sentence.find(' ');
    word = english_sentence.substr(0, index_of_space);
    translate_word(word, piglatin_word);
    piglatin_sentence = piglatin_word;
    
    if (index_of_space != string::npos)
    {
        do
        {
            index_of_next_space = english_sentence.find(' ', index_of_space + 1);
            if (index_of_next_space != string::npos)
            {
                word = english_sentence.substr(index_of_space + 1, index_of_next_space - index_of_space - 1);
                translate_word(word, piglatin_word);
            }
            else
            {
                word = english_sentence.substr(index_of_space + 1);
                translate_word(word, piglatin_word);
            }
            piglatin_sentence += " ";
            piglatin_sentence += piglatin_word;
            index_of_space = index_of_next_space;

        } while(index_of_next_space != string::npos);
    }

    else
        cout << "No spaces in this string" << endl;

}

void translate_word(string english_word, string &piglatin_word)
{
    if(english_word[0] == 'a' || english_word[0] == 'o' ||
       english_word[0] == 'i' || english_word[0] == 'u' ||
       english_word[0] == 'e')
        piglatin_word = english_word.append("ay");

    else
    {
       english_word.push_back(english_word[0]);
       piglatin_word = english_word.erase(0, 1);
       piglatin_word = piglatin_word.append("ay");
    }
}