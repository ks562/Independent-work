// File: datedriver.cpp
// This file is a tester for the date class functions ­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 2             Date assigned: 9/16/2019
// Programmer: Karim Soufan          Date completed: 9/27/2019
#include <iostream>
#include "date.h"

using namespace std;

int main()
{
    Date my_birthday;
    // testing operator<< and default value constructor
    cout << my_birthday << endl;
    cout << "Please enter your birthday (mm/dd/year): ";

    // testing operator>> 
    cin >> my_birthday;
    cout << my_birthday << endl;

    // testing string_name() function
    cout << "The date as a string is: "
         << my_birthday.string_name() << endl;

    // testing to_string() function
    cout << "The date in numbers is: "
        << my_birthday.to_string() << endl;

    // testing day_of_week() function
    cout << "The day of the week is: "
         << my_birthday.day_of_week() << endl;

    Date date1;
    cout << "Enter a date (mm/dd/year): ";
    cin >> date1;
    cout << date1 << endl;
    // Testing all the operations
    if(my_birthday == date1)
        cout << "The two dates match!" << endl;

    if(my_birthday != date1)
        cout << "The two dates don't match!" << endl;

    if(my_birthday > date1)
        cout << "The first date: "<< my_birthday 
        << " is bigger than the second date: "
        << date1 << endl; 

    if(my_birthday < date1)
        cout << "The first date: " << my_birthday 
        << " is smaller than the second date: "
        << date1 << endl;

    if(my_birthday >= date1)
        cout << "First date: " << my_birthday 
        << " is bigger or EQUAL to the second date: "
        << date1 << endl;

    if(my_birthday <= date1)
        cout << "First date: " << my_birthday 
        << " is smaller or EQUAL to the second date: "
        << date1 << endl;

    // testing explicit value constructor
    Date date2(3, 14, 2017);
    cout << date2 << endl;

    return 0;
}