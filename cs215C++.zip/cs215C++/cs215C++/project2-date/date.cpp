// File: date.cpp
// This file defines the Date­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­ class functions
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 2             Date assigned: 9/16/2019
// Programmer: Karim Soufan          Date completed: 9/27/2019

#include <iostream>
#include <string>
#include <sstream> // ostringstream
#include "date.h"

using namespace std;

// Function: is_leap_year
// returns true/false boolean
bool is_leap_year(int year); // REC'D: year

// Function: get_month_name
// returns a string
std::string get_month_name(int mm); // REC'D: month

// Function: check_date
// returns true/false boolean
bool check_date(int month, // REC'D: month
                int day, // REC'D: day
                int year); // REC'D: year

// Default/Explicit value constructor
Date::Date(int initial_month, // REC'D
           int initial_day, // REC'D
           int initial_year) // REC'D
{
    // check if the date is correct
    if(check_date(initial_month, initial_day, initial_year))
    {
        // initialize the private attributes
        mm = initial_month;
        dd = initial_day;
        yyyy = initial_year;
    }

    // if the date is incorrect
    else
    {
        // initialize the attributes to 1/1/2019
        mm = 1;
        dd = 1;
        yyyy = 2019;
        cout << "The month or day or year are not valid!" << endl;
    }
}
// end of constructor

int Date::month() const
{
    return mm;
}

int Date::day() const
{
    return dd;
}

int Date::year() const
{
    return yyyy;
}

void Date::set_month(int month)
{
    mm = month;
}

void Date::set_day(int day)
{
    dd = day;
}

void Date::set_year(int year)
{
    yyyy = year;
}

bool is_leap_year(int year)
{
    return ((year % 4 == 0 || year % 400 == 0)
             && year % 100 != 0);
}
// end of is_leap_year function

string Date::string_name() const
{
    string name_of_month;
    ostringstream name;

    // gets the name of the month
    name_of_month = get_month_name(mm);
    // displays the date in (month_name dd, yyyy) format
    name << name_of_month << ' ' << dd << ", " << yyyy;
    return name.str();    
}
// end of string_name function

string Date::to_string() const
{
    ostringstream name;
    // displays the date in mm/dd/yyyy format
    name << mm << '/' << dd << '/' << yyyy;
    return name.str();
}
// end of to_string function

string Date::day_of_week() const
{
    int a, b, c, d, year;

    year = yyyy;
    // if the month is less than 3
    if(mm < 3)
    {
        year--;
        a = (mm + 10);
    }
    else
        a = mm - 2;

    b = dd;
    c = year % 100;
    d = year / 100;

    int w, x, y, z, r;

    w = (13 * a - 1) / 5;
    x = c / 4;
    y = d / 4;
    z = w + x + y + b + c - 2 * d;
    r = z % 7;
    if(r < 0)
        r += + 7;

    if(r == 0)
        return "Sunday";

    else if(r == 1)
        return "Monday";

    else if(r == 2)
        return "Tuesday";

    else if(r == 3)
        return "Wednesday";

    else if(r == 4)
        return "Thursday";

    else if(r == 5)
        return "Friday";

    else if(r == 6)
        return "Saturday";

    else
    {
        cout << "This day doesn't exist!\n";
        return "Sunday";
    }   
}
// end of day_of_week function

bool operator==(const Date & lhs, const Date & rhs)
{
    return (lhs.dd == rhs.dd &&
            lhs.mm == rhs.mm && lhs.yyyy == rhs.yyyy);
}
// end of operator== function

bool operator<(const Date & lhs, const Date & rhs)
{
    return ((lhs.yyyy < rhs.yyyy) ||
            (lhs.yyyy == rhs.yyyy && lhs.mm < rhs.mm) ||
            (lhs.yyyy == rhs.yyyy &&
             lhs.mm == rhs.mm && lhs.dd < rhs.dd));
    
}
// end of operator< function

bool operator>(const Date & lhs, const Date & rhs)
{
    return (!(lhs < rhs) && !(lhs == rhs));
}
// end of operator> function

bool operator>=(const Date & lhs, const Date & rhs)
{
    return (!(lhs < rhs));
}
// end of operator>= function

bool operator<=(const Date & lhs, const Date & rhs)
{
    return (!(lhs > rhs));
}
// end of operator<= function

bool operator!=(const Date & lhs, const Date & rhs)
{
    return (!(lhs == rhs));
}
// end of operator!= function

istream& operator>>(istream &in, Date &a_date)
{
    int month, day, year;
    char slash1, slash2;
    // take the date in mm/dd/yyyy format
    in >> month >> slash1 >> day >> slash2 >> year;
    // if the instream fails to read
    if (in.fail())
        return in;

    // if the date is invalid or if slahs not entered
    if (!check_date(month, day, year) || slash1 != '/'
        || slash2 != '/')
    {
        in.setstate (ios_base::failbit);
        return in;
    }
    a_date.mm = month;
    a_date.dd = day;
    a_date.yyyy = year;
    return in;
}
// end of operator>> funciton

ostream& operator<<(ostream &out, const Date & a_date)
{
    // display the date in mm/dd/yyyy format
    out << a_date.mm << "/" << a_date.dd 
        << "/" << a_date.yyyy;
    return out;
}
// end of operator<< function

string get_month_name(int mm)
{
    string name_of_month;
    // checking the name and number of month
    if (mm == 1)
        name_of_month = "January";

    else if (mm == 2)
        name_of_month = "February";

    else if (mm == 3)
        name_of_month = "March";

    else if (mm == 4)
        name_of_month = "April";

    else if (mm == 5)
        name_of_month = "May";

    else if (mm == 6)
        name_of_month = "June";

    else if (mm == 7)
        name_of_month = "July";

    else if (mm == 8)
        name_of_month = "August";

    else if (mm == 9)
        name_of_month = "September";

    else if (mm == 10)
        name_of_month = "October";

    else if (mm == 11)
        name_of_month = "November";

    else if (mm == 12)
        name_of_month = "December";

    // if month not found
    else
    {
        cout << "Month is invalid!\n";
        name_of_month = "January";
    }

    return name_of_month;
}
// end of get_month_name function

bool check_date(int month, int day, int year)
{
    // if the year is negative or 0
    if (year <= 0)
        return false;

    // if the month is not between 1 and 12
    if (month < 1 || month > 12)
        return false;

    // cheking for leap years
    if (month != 2 && month != 4 &&
        month != 6 && month != 9 &&
        month != 11 && month >= 1 &&
        day <= 31)
        return true;

    else if ((month == 4 || month == 6 ||
              month == 9 || month == 11) &&
             day <= 30)
        return true;

    else if (month == 2 && day <= 29 && is_leap_year(year))
        return true;

    else if (month == 2 && day <= 28 && !is_leap_year(year))
        return true;

    else
        return false;
}
// end of check_date function