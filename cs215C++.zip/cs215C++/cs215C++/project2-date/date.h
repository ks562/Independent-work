// File: date.h
// header file for the Date­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­ class function
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 2             Date assigned: 9/16/2019
// Programmer: Karim Soufan          Date completed: 9/27/2019

#ifndef DATE_H_
#define DATE_H_

#include <iostream> // streams

// Class: Date
class Date
{
    public:
        // Default/Explicit value constructor with
        // overloaded parameters
        Date(int initial_month = 1, 
             int initial_day = 1,
             int initial_year = 2019);
        
        // Friend overloaded operators

        // returns true if left hand side is equal
        // to the right hand side
        friend bool operator==(const Date & lhs, // REC'D
                               const Date & rhs); // REC'D

        // returns true if left hand side is bigger
        // than the right hand side
        friend bool operator<(const Date & lhs, const Date & rhs);

        // returns true if left hand side is smaller
        // than the right hand side
        friend bool operator>(const Date & lhs, const Date & rhs);

        // returns true if left hand side is smaller or equal to
        // the right hand side
        friend bool operator<=(const Date & lhs, const Date & rhs);

        // returns true if left hand side is bigger or equal to
        // the right hand side
        friend bool operator>=(const Date & lhs, const Date & rhs);

        // returns true if left hand side is not equal to
        // the right hand side
        friend bool operator!=(const Date & lhs, const Date & rhs);


        // Operator>>: returns the instream
        friend std::istream& operator>>(std::istream &in,
                                      // REC'D/P'BACK
                                        Date &a_date);
                                      // P'BACK

        // Operator<<: returns outstream
        friend std::ostream& operator<<(std::ostream &out,
                                        // REC'D/P'BACK
                                        const Date & a_date);
                                        // REC'D

        // Mutators

        // Function: day_of_week()
        // returns a string
        std::string day_of_week() const;

        // Function: to_string()
        // returns a string
        std::string to_string() const;

        // Function: string_name()
        // returns a string
        std::string string_name() const;

        // Accessors
        int month() const; // returns
                          // the month

        int day() const; // returns
                        // the day

        int year() const; // returns
                         // the year

        // Getter functions

        // sets the month
        void set_month(int month);

        // sets the day
        void set_day(int day);

        // sets the year
        void set_year(int year);

    private: // Decleration of the attributes
        int mm, // the month
            dd, // the day
            yyyy; // the year
};
// End of Date

#endif // DATE_H_