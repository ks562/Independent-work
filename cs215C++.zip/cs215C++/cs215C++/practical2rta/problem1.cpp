// File: problem1.cpp
// A program that tests vector_average and split_vector
//
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Date: December 5, 2019
// Assignment: Practical Exam 2 Retake, Problem 1
// Programmer: Karim Soufan

#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>

using namespace std;

void read_vector (std::vector<int> & v, std::istream & in);
void write_vector(const vector<int>& v, ostream &out);
double vector_average(const vector<int>& v);
void split_vector(const vector<int> &v, double target,
                  vector<int>& lt, vector<int>& ge);

int main (int argc, char* argv[])
{
   // *** WRITE THE DECLARATIONS FOR v, lt, and ge HERE ***
   vector<int> v, lt, ge;

   if(argc != 3)
   {
      cerr << "Usage: " << argv[0] <<
      " input_file output_file" << endl;
      exit(1);
   }

   ifstream infile(argv[1]);
   ofstream outfile(argv[2]);

   if(!infile)
   {
      cerr << "Cannot open input file "
      << argv[1] << endl;
      exit(1);
   }
   
   if(!outfile)
   {
      cerr << "Cannot open output file " 
      << argv[2] << endl;
      exit(1);
   }

   // Read in data from file
   read_vector (v, infile);

   cout << "The elements of vector v are: " << endl;
   // *** WRITE CALL TO DISPLAY v ON SCREEN HERE ***
   write_vector(v, cout);


   // *** DISPLAY THE AVERAGE OF THE VALUES OF v HERE ***
   double avg;
   avg = vector_average(v);
   cout << avg << endl;

   // *** WRITE CALL TO SPLIT v INTO lt and ge HERE ***
   split_vector(v, avg, lt, ge);


   outfile << "After splitting, the elements of vector lt are: " << endl;
   // *** WRITE CALL TO WRITE lt TO OUTPUT FILE HERE ***
   write_vector(lt, outfile);

 
   outfile << "After splitting, the elements of vector ge are: " << endl;
   // *** WRITE CALL TO WRITE ge TO OUTPUT FILE HERE ***
   write_vector(ge, outfile);

   infile.close();
   outfile.close();
   return 0;
}

void read_vector (std::vector<int> & v, std::istream & in)
{
   int value;
   v.clear();
   while (in >> value)
      v.push_back(value);
}

void write_vector(const vector<int>& v, ostream &out)
{
   for(int i = 0; i < v.size(); i++)
      out << v[i] << endl;
}

double vector_average(const vector<int>& v)
{
   double avg = 0;
   int sum_of_elements = 0;
   for(int i = 0; i < v.size(); i++)
   {
      sum_of_elements += v[i];
      avg = (double) sum_of_elements/(double) v.size();
   }
   return avg;
}

void split_vector(const vector<int> &v, double target,
                  vector<int>& lt, vector<int>& ge)
{
   for(int i = 0; i < v.size(); i++)
   {
      if((double) v[i] < target)
         lt.push_back(v[i]); 
      
      else if((double) v[i] >= target)
         ge.push_back(v[i]);
      
   }
}