// File: sorting3.cpp
// Various sorting algorithms for vectors.
// Assumes that type T has defined operator<

#include <cstdlib>   // exit
#include <fstream>
#include <iostream>
#include <iomanip>
#include <vector>
#include <algorithm> // sort algorithm

// Debugging flags
bool debug1 = false;  // heap sort build phase
bool debug2 = false;  // heap sort sort phase
bool debug3 = false;  // selection sort
bool debug4 = false;  // bubble sort
bool debug5 = false;  // insertion sort
bool debug6 = false;  // quick sort

// Global Counters
int selection_sort_comparisons = 0,
   selection_sort_exchanges = 0;
int insertion_sort_comparisons = 0,
   insertion_sort_exchanges = 0;
int bubble_sort_comparisons = 0,
   bubble_sort_exchanges = 0;
int heap_sort_comparisons = 0,
   heap_sort_exchanges = 0;

template <typename T>
void print_container (const T & container) {
   using namespace std;
   for (auto e: container)
      cout << " " << e;
   cout << endl;
}  // end print_container

// Sorting functions - includes put here so global vars and print_container
// are visible to sorting functions.
#include "selectionsort.h"
#include "insertionsort.h"
#include "bubblesort.h"
#include "heapsort.h"

template <typename T>
void fill_vector_from_file (std::vector<T> & v, std::istream &in)
{
   T value;

   // make vector empty
   v.clear();

   // read in values
   while (in >> value)
      v.push_back(value);
}  // end fill_vector_from_file


int main (int argc, char *argv[])
{
   using namespace std;

   if (argc != 2)
   {
      cout << "Usage: " << argv[0] << " input_file" << endl;
      exit(1);
   }

   ifstream in (argv[1]);
   if (!in)
   {
      cout << "Unable to open input file: " << argv[1] << endl;
      exit(1);
   }

   vector<int> v;
   fill_vector_from_file(v, in);
   vector<int> copy_to_sort (v);

/*
   cout << "Original vector" << endl;
   print_container (v);
   cout << "Selection Sort" << endl;
   selection_sort(copy_to_sort);
   cout << "Sorted vector" << endl;
   print_container (copy_to_sort);

   copy_to_sort = v;
   cout << "\nOriginal vector" << endl;
   print_container (v);
   cout << "Bubble Sort" << endl;
   bubble_sort(copy_to_sort);
   cout << "Sorted vector" << endl;
   print_container (copy_to_sort);

   copy_to_sort = v;
   cout << "\nOriginal vector" << endl;
   print_container (v);
   cout << "Insertion Sort" << endl;
   insertion_sort(copy_to_sort);
   cout << "Sorted vector" << endl;
   print_container (copy_to_sort);
*/
   
   copy_to_sort = v;
   cout << "\nOriginal vector" << endl;
   print_container (v);
   cout << "Heap Sort" << endl;
   heap_sort(copy_to_sort);
   cout << "Sorted vector" << endl;
   print_container (copy_to_sort);

   copy_to_sort = v;
   cout << "\nOriginal vector" << endl;
   print_container (v);
   cout << "Quick Sort" << endl;
   quick_sort(copy_to_sort);
   cout << "Sorted vector" << endl;
   print_container (copy_to_sort);

   cout << "\nOriginal vector" << endl;
   print_container (v);
   cout << "Sort algorithm" << endl; // does not work on lists, becuase it
                                     // needs random access
   sort(copy_to_sort.begin(), copy_to_sort.end());
   cout << "Sorted vector" << endl;
   print_container (copy_to_sort);

   cout << "\n\nSorting vector of " << v.size() << " elements" << endl << endl;

   copy_to_sort = v;

   cout << "Sorting algorithm       Comparisons        Exchanges/Copies"
	<< endl;
   cout << "-----------------       -----------        ----------------"
	<< endl;
   cout << left << setw(20) << "Selection sort" 
	<< right << setw(15) << selection_sort_comparisons 
	<< setw(17) << selection_sort_exchanges << endl;
   cout << left << setw(20) << "Bubble sort" 
	<< right << setw(15) << bubble_sort_comparisons 
	<< setw(17) << bubble_sort_exchanges << endl;
   cout << left << setw(20) << "Insertion sort" 
	<< right << setw(15) << insertion_sort_comparisons 
	<< setw(17) << insertion_sort_exchanges << endl;
   cout << left << setw(20) << "Heap sort" 
	<< right << setw(15) << heap_sort_comparisons 
	<< setw(17) << heap_sort_exchanges << endl;

   return 0;
}
