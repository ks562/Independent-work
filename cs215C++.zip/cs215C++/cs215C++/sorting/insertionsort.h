// File: insertionsort.h
// Template function for sorting vectors using Insertion Sort algorithm
// Based on Wittenberg, Data Structures and Algorithms in C++ Pocket Primer
// Assumes T has operator<

#ifndef INSERTIONSORT_H_
#define INSERTIONSORT_H_

#include <vector>     // std::vector<T>
#include <algorithm>  // std::swap

template<typename T>
void insertion_sort(std::vector<T>& values)
// Post: The elements in the array values are sorted by operator<
{
   int numValues = values.size();

   // for each value in range [1..numValues)
   for (int i = 1; i < numValues; i++)
   {
      T value = values[i];  // save the value being inserted
      // look at the values to the left of index i
      int j = i - 1;
      while (j >= 0     // there are still values to consider
	     && value < values[j])  // the value is smaller than the one
	                            // in this place
      {
         insertion_sort_comparisons++;
         insertion_sort_exchanges++;
	      values[j+1] = values[j];  // push value at j over to the right
	      j--;                      // go to the spot to the left
      }

      // saved value goes in index j+1
      insertion_sort_exchanges++;
      values[j+1] = value;
      if (debug5)
	 print_container(values);
   }
}

#endif
