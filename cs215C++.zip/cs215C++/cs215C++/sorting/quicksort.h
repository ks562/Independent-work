// File: quicksort.h
// Template function for sorting vectors using Quick Sort algorithm
// Based on Wittenberg, Data Structures and Algorithms in C++ Pocket Primer
// Assumes T has operator<

#ifndef QUICKSORT_H_
#define QUICKSORT_H_

#include <vector>     // std::vector<T>
#include <algorithm>  // std::swap

template<typename T>
int partition(std::vector<T>& elements, int start, int stop)
// Post: The elements in range [start, stop] are arranged so that
//       elements in [start, pivot-1] < elements[pivot]
//                                    < elements in [pivot+1, stop]
{
   // choose a pivot value, easiest is the start value
   T pivot_value = elements[start];
   // assume start is where the pivot value should go
   int pivot_index = start;

   // for rest of elements in the range
   for (int i = start+1; i <= stop; i++)
   {
      // check if elements[i] should be to the left of pivot_value
      if (elements[i] < pivot_value)
      {
	 // move pivot index over one
	 pivot_index++;
	 // swap elements[i] to the left side, if needed
	 if (pivot_index != i)
	    std::swap(elements[pivot_index], elements[i]);
      }
   }

   // swap pivot value into its correct place
   // elements[pivot_index] is guarenteed to be a value < pivot_value
   if (pivot_index != start)
      std::swap(elements[start], elements[pivot_index]);
   

   if (debug6)
   {
      std::cout << '[' << start << '/' << pivot_index << '/' << stop << "]:";
      print_container(elements);
   }
   
   return pivot_index;
}

template<typename T>
void qsort(std::vector<T>& elements, int start, int stop)
// Post: The elements in range [start, stop] are sorted by operator <
{
   if (start < stop)
   {
      int pivot = partition(elements, start, stop);
      // recursively sort the left and right partitions
      // Fixed error from Lecture 40.  Second argument in first
      // recursive call should be "start", not "0".
      qsort (elements, start, pivot-1);
      qsort (elements, pivot+1, stop);
   }
}

template<typename T>
void quick_sort(std::vector<T>& values)
// Post: The elements in the array values are sorted by operator<
{
   int numValues = values.size();
   // Start off the recursion
   qsort(values, 0, numValues -1);
}

#endif // QUICKSORT_H_
