// File: bubblesort.h
// Template function for sorting vectors using Revised Bubble Sort algorithm
// Based on Wittenberg, Data Structures and Algorithms in C++ Pocket Primer
// Assumes T has operator<

#ifndef BUBBLESORT_H_
#define BUBBLESORT_H_

#include <vector>     // std::vector<T>
#include <algorithm>  // std::swap

template<typename T>
void bubble_sort(std::vector<T>& values)
// Post: The elements in the array values are sorted by operator<
//       The process stops as soon as values is sorted
{
   int numValues = values.size();
   bool done = false;
   
   // For each pass [0, n-1], compare adjacent elements and
   // swap if not in order
   for (int i = 0; i < numValues-1 && !done; i++)
   {
      done = true;  // assume everything is in order
      
      // Compare adjacent element in [0, n-1-i)
      for (int j = 0; j < numValues-1-i; j++)
      {
	 // Compare adjacent values
	 if (values[j+1] < values[j])
	 {
	    std::swap(values[j], values[j+1]);  // out of order
	    done = false;
	 }
      }

      if (debug4)
	 print_container(values);
   }

}

#endif
