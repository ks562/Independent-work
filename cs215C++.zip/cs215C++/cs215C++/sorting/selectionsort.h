// File: selectionsort.h
// Template function for sorting vectors using Selection Sort algorithm
// Based on Wittenberg, Data Structures and Algorithms in C++ Pocket Primer
// Assumes T has operator<

#ifndef SELECTIONSORT_H_
#define SELECTIONSORT_H_

#include <vector>     // std::vector<T>
#include <algorithm>  // std::swap

template<typename T>
void selection_sort(std::vector<T>& values)
// Post: The elements in the vector are sorted by operator<
{
   int numValues = values.size();

   // for each pass i [0, n-1], find the smallest element in [i, n), and swap
   for (int i = 0; i < numValues-1; i++)
   {
      // Find the smallest element in [i, n)
      int min_index = i;
      for (int j = i+1; j < numValues; j++)
      {
	 // Compare elements at indexes min_index and j
    selection_sort_comparisons++;
	 if (values[j] < values[min_index])
	    min_index = j;  // new smallest value
      }

      // swap the smallest element to index i
      selection_sort_exchanges++;
      std::swap(values[i], values[min_index]);
      if (debug3)
	 print_container(values);
   }
} 

#endif
