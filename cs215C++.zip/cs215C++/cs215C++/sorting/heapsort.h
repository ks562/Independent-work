// File: heapsort.h
// Template functions for sorting vectors using Heap Sort algorithm
// Based on Wittenberg, Data Structures and Algorithms in C++ Pocket Primer
// Assumes type T has operator<

#ifndef HEAPSORT_H_
#define HEAPSORT_H_

#include <vector>     // std::vector<T>
#include <algorithm>  // std::swap

// Returns the index of the larger child
template<typename T>
int max_child(const std::vector<T>& elements, // REC'D: heap vector
	      int p,                          // REC'D: parent index
	      int n)                          // REC'D: size of heap
{
   int result = 2 * p + 1;                           // index of first child
   if (result + 1 < n                                // there is second child
       && (elements[result] < elements[result + 1])) // and it is larger
       {
          
         heap_sort_comparisons++;
         result++;
       }
   return result;
}  // end max_child

// Pre: Only root element is not in heap order
// Post: Heap property is restored.
template<typename T>
void percolate_down (std::vector<T>& elements,
                                     // REC'D & P'BACK: vector to adjust
		     int i)          // REC'D: size of heap
{
   int parent = 0;
   int child = max_child(elements, parent, i);
   while (child < i &&                             // haven't reached bottom
	  elements[parent] < elements[child]) {    // parent is larger
      std::swap(elements[child], elements[parent]);
      parent = child;                              // move down heap tree
      child = max_child(elements, parent, i);
   }
   if (debug2)
      print_container(elements);
}  // end percolate_down

// Pre: Only last element may not be in heap order
// Post: Heap property is restored
template<typename T>
void percolate_up(std::vector<T>& elements,
                                  // REC'D & P'BACK: vector to adjust
		  int n)          // REC'D: size of heap
{
   int i = n - 1;       // index of "added" node in heap
   int p = (i - 1) / 2; // index of parent of last node in heap
   while (i > 0 && elements[p] < elements[i]) {
      std::swap(elements[p], elements[i]);
      i = p;            // move up heap tree
      p = (i - 1) / 2;
   }
   if (debug1)
      print_container(elements);
}  // end percolate_up

template<typename T>
void heap_sort(std::vector<T>& values) // REC'D & P'BACK: vector to be sorted
// Post: The elements in the vector are sorted.
{
   int n = values.size();

   // Convert the vector of values into a heap.
   if (debug1)
      std::cout << "Build phase" << std::endl;
   for (int i = 2; i <= n; i++)
      percolate_up(values, i);
   std::cout << "Vector after Heap Sort build phase" << std::endl;
   print_container(values);

   // Sort the array.
   if (debug2)
      std::cout << "Sort phase" << std::endl;
   for (int i = n-1; i >=1; i--)
   {
      heap_sort_exchanges++;
      std::swap(values[0], values[i]);
      percolate_down(values, i);
   }
}  // end heap_sort

#endif
