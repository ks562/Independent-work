// File: match.cpp
// This program tests if delimiters match each other
//
// ------------------------------------------------------------------
// Class: CS 215                      Instructor: Dr. Deborah Hwang
// Assignment: Project 7a             Date assigned: Fri, Nov 22
// Programmer: Karim Soufan           Date completed: Wed, Dec 4

#include <iostream>
#include <fstream>
#include <stack>

using namespace std;

bool is_match(char d1, // REC'D
              char d2); // REC'D

bool is_valid_char(char ch); // REC'D

bool is_opposite(char d1, // REC'D
                 char d2);  // REC'D

int main(int argc, char* argv[])
{
    // error checking for the number of arguments
    if (argc != 2)
    {
        cerr << "Usage: " << argv[0] <<
         " input_file" << endl;
        exit(1);
    }

    ifstream input_file(argv[1]);

    // error checking for input file
    if (!input_file)
    {
        cerr << "Cannot open input file "
         << argv[1] << endl;
        exit(1);
    }

    stack<char> s;
    char ch;

    while(input_file >> ch)
    {
        if(is_valid_char(ch))
        {

            if(s.empty())
                s.push(ch);

            else
            {
                
                if(is_match(s.top(), ch))
                    s.pop();

                else
                {
                    if(is_opposite(s.top(), ch))
                        s.push(ch);
                    else
                        break;
                }
            }
        }
        else
            break;
    }

    if(s.empty())
        cout << "All delimiters match." << endl;

    else if(s.size() == 1)
        cout << "Extra delimiter " << s.top() << " found." << endl;

    else
        cout << "Mismatched delimiter " << s.top()
         << " found. Expecting delimiter " << ch
         << "." << endl;


    input_file.close();
    return 0;
}

bool is_match(char d1, char d2)
{
    if(d1 == '(' && d2 == ')')
        return true;

    else if(d1 == '{' && d2 == '}')
        return true;

    else if(d1 == '[' && d2 == ']')
        return true;

    else
        return false;
}

bool is_valid_char(char ch)
{
    return (ch == '(' || ch == ')' ||
            ch == '{' || ch == '}' ||
            ch == '[' || ch == ']');
}

bool is_opposite(char d1, char d2)
{
       if(d1 == '(' && (d2 == '}' || d2 == ']'))
        return false;
         if(d1 == '{' && (d2 == ')' || d2 == ']'))
        return false;
            if(d1 == '[' && (d2 == ')' || d2 == '}'))
        return false;
        
        return true;
}