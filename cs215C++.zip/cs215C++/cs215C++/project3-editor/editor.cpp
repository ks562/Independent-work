// File: editor.cpp
// This file tests the Document class functions
// 
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 3             Date assigned: Wed, Oct 2
// Programmer: Karim Soufan          Date completed: Fri, Oct 18

#include <iostream>
#include <vector>
#include <fstream>
#include <cctype> // tolower()
#include "document.h"

using namespace std;

int main(int argc, char* argv[])
{
    // error checking for number of command-line arguments
    if(argc != 2)
    {
        cerr << "Usage: " << argv[0] << " input file outputfile" << endl;
        exit(1);
    }

    // opening the input file
    ifstream in(argv[1]);

    // error checking for correct file opening
    if(!in)
    {
        cerr << "Cannot open input file " << argv[1] << endl;
        exit(1);
    }

    // declaring the document
    Document doc(in);
    // variables for the user
    string line;
    int n = 0;
    char command;
    do
    {
        // printing the symbol for input waiting
        cout << "> ";
        cin >> command;
        // converting user input into small letter
        command = tolower(command);
        // if the command entered is h, display the help menu
        if(command == 'h')
        {
            cout << "This line editor can do the following commands: \n\n";
            cout << "  I line   - insert line in front of current line\n";
            cout << "  A line   - append line to end of document\n";
            cout << "  R line   - replace current line\n";
            cout << "  D        - delete the current line\n";
            cout << "  F target - makes line containing target current line\n";
            cout << "  S n      - set current line to nth line\n";
            cout << "  M n      - move current line n places\n";
            cout << "  C        - display current line to screen\n";
            cout << "  P        - display entire document to screen\n";
            cout << "  W file   - write document to file\n";
            cout << "  L file   - load file into this editor\n";
            cout << "  H        - display this list of commands\n";
            cout << "  Q        - quit the editor (does not save changes)\n\n";
        }
        // if the user wants to insert
        else if(command == 'i')
        {
            // ignore the whitespace
            cin.ignore();
            // read the string
            getline(cin, line);
            // insert it
            doc.insert(line);
        }
        // if the user wants to append
        else if(command == 'a')
        {
            cin.ignore();
            getline(cin, line);
            doc.append(line);
        }
        // if the user wants to replace the contents of the document
        else if(command == 'r')
        {
            cin.ignore();
            getline(cin, line);
            // try and catch if error occurs
            try
            {
                doc.replace(line);
            }
            catch(const std::out_of_range& e)
            {
                cerr << e.what() << endl;
                cerr << "Cannot replace" << endl;
            } 
        }
        // if the user wants to find a word/string
        else if(command == 'f')
        {
            cin.ignore();
            getline(cin, line);
            doc.find(line);
        }
        // if the user wants to delete a line
        else if(command == 'd')
        {
            try
            {
                doc.erase();
            }
            catch(const std::out_of_range& e)
            {
                cerr << e.what() << endl;
                cerr << "Line will not erase" << endl;
            } 
        }
        // if the user wants to set the index of the current line
        else if(command == 's')
        {
            // enters the number of the line
            cin >> n;
            try
            {
                doc.set_current(n);
            }
            catch(const std::out_of_range& e)
            {
                cerr << e.what() << endl;
                cerr << "Index cannot be set" << endl;
            }
        }
        // if the user wants to move the index of the current line
        else if(command == 'm')
        {
            cin >> n;
            try
            {
                doc.move_current(n);
            }
            catch(const std::out_of_range& e)
            {
                cerr << e.what() << endl;
                cerr << "Index cannot be moved" << endl;
            }
        }
        // if the user wants to display the current line
        else if(command == 'c')
        {
            // error checking for empty document
            if(doc.empty())
                cerr << "The document is empty! (command C)" << endl;
            // if not empty, then print the line
            else
                doc.write_line(cout);
        }
        // if the user wants to display the entire document
        else if(command == 'p')
        {
            // error checking for empty document
            if(doc.empty())
                cerr << "The document is empty! (command P)" << endl;
            // if not empty, print the contents of the document
            else
                doc.write_all(cout);
        }
        // if the user wants to write the document to a file
        else if(command == 'w')
        {
            cin.ignore();
            getline(cin, line);
            ofstream out(line);
            if(!out)
                cerr << "output file didn't open!" << endl;
            
            doc.write_all(out);
            out.close();
        }
        // if the user wants to load the document to a file
        else if(command == 'l')
        {
            cin.ignore();
            getline(cin, line);
            ifstream input(line);
            if(!input)
                cerr << "input file didn't open!" << endl;
            
            doc.load(input);
            input.close();
        }
        // if the user's input is invalid
        else if(command != 'q')
            cout << "This is not a valid command!" << endl;

    } while (command != 'q'); // if the user quits, the do-while loop exits


    // closing the file
    in.close();

    return 0;
}