// File: document.cpp
// This file defines the Document class functions
// 
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 3             Date assigned: Wed, Oct 2
// Programmer: Karim Soufan          Date completed: Fri, Oct 18

#include <iostream>
#include <vector>
#include <fstream>
#include <stdexcept> // out_of_range throwing
#include "document.h"

using namespace std;

// constructor
Document::Document()
{
    // setting the index of the current line to zero
    curr = 0;
}
// end of constructor

// explicit constructor
Document::Document(istream& in) // REC'D/P'BACK
{
    // creating the document from the input stream
    string line;
    curr = 0;
    while(getline(in, line))
        lines.push_back(line);
}
// end of explicit constructor

// Function: load
void Document::load(istream& in) // REC'D/P'BACK
{
    string line;
    curr = 0;
    lines.clear();
    while (getline(in, line))
        lines.push_back(line);
}
// end of load

// Function: empty
bool Document::empty() const
{
    // returning true if the vector is empty
    return lines.empty();
}
// end of empty

// Function: insert
void Document::insert(const std::string &new_line) // REC'D
{
    // creating a temporary vector of strings
    vector<string> temp;
    int doc_size = lines.size();

    for(int i = doc_size - 1; i >= curr; i--)
    {
        // filling the temp vector
        temp.push_back(lines[i]);
        // deleting the last line
        lines.pop_back();
    }

    // entering the string to the original vector
    lines.push_back(new_line);

    // filling the original vector
    for(int i = temp.size() - 1; i >= 0; i--)
        lines.push_back(temp[i]);
}
// end of insert

// Function: append
void Document::append(const std::string &new_line)
{
    // adding the string to the end of the document
    lines.push_back(new_line);
    // setting the current index to the last line
    curr = lines.size() - 1;
}
// end of append

// Function: replace
void Document::replace(const std::string &new_line)
{
    // error checking for empty document
    if(lines.empty())
        throw out_of_range("The document is empty,"
        " no content to (replace)");
    
    // replacing a line of the document with the string
    lines[curr] = new_line;
}
// end of replace

// Function: erase
void Document::erase()
{
    // error checking for empty document
    if(lines.empty())
        throw out_of_range("The document is empty (erase)");

    // checking if the current index is equal to the last line
    if(curr == lines.size() - 1)
        curr--;

    // if not, then replace each line with the one after it
    else
        for(int i = curr; i < lines.size() - 1; i++)
            lines[i] = lines[i + 1];

    // then delete the last (empty) line
    lines.pop_back();
}
// end of erase

// Function: find
bool Document::find(const std::string &target)
{
    size_t found;
    for(int i = 0; i < lines.size(); i++)
    {
        // searching for the target string in each line
        found = lines[i].find(target);
        // if it was found
        if(found != string::npos)
        {
            // set the index to where it was found
            curr = i;
            return true;
        }
    }
    // if it wasn't found, return false
    return false;
}
// end of find

// Function: set_current
void Document::set_current(int n)
{
    // error checking for empty document
    if(lines.empty())
        throw out_of_range("The document is empty! (set_current)");

    // if the index entered is negative, or if it is bigger than
    // the number of lines in the document
    if(n < 0 || lines.size() < n + 1)
        // throw an error
        throw out_of_range("The index is out of range"
        " (set_current)");
    
    // set the index to the number entered by the user
    curr = n;
}
// end of set_current

// Function: move_current
void Document::move_current(int n)
{
    // error checking for mepty document
    if(lines.empty())
        throw out_of_range("The document is empty! (move_current)");

    // if the amount the index is moved is bigger than the number of
    // indexes left in either direction, then throw an error.
    if(curr + n < 0 || curr + n > lines.size() - 1)
        throw out_of_range("The number of lines moved is bigger"
        " than the number of lines (move_current)");

    // moving the current index to the new position
    curr += n;
}
// end of move_current

// Function: write_lane
void Document::write_line(std::ostream& out) const
{
    // checking if the document is not empty
    if(!lines.empty())
        // display the line
        out << lines[curr] << endl;
        
}
// end of write_line

// Function: write_all
void Document::write_all(std::ostream& out) const
{
    // printing the content of the document
    for(int i = 0; i < lines.size(); i++)
        out << lines[i] << endl;
}
// end of write_all
