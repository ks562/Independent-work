// File: image.cpp
// This file defines the PGMImage class functions
// 
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 4             Date assigned: Wed, Oct 16
// Programmer: Karim Soufan          Date completed: Fri, oct 25

#include <iostream> // streams
#include <fstream>
#include <string>
#include <stdexcept> // runtime_error
#include <iomanip> // setw()
#include <algorithm> // swap, copy
#include "image.h"

using namespace std;

// Default constructor
PGMImage::PGMImage()
{
    wd = 0;
    ht = 0;
    max = 0;
    image = nullptr;
}
// end of Default constructor

// Function: load
void PGMImage::load(const string &filename)
{
    // opening the file
    ifstream input_file(filename);
    string p2;

    // error checking
    if(!input_file)
        throw runtime_error("Failed to open input file (load)");

    getline(input_file, p2);
    if(p2 != "P2")
        throw runtime_error("The magic string P2"
                            " is not found (load)");

    // reading from the file
    input_file >> wd;
    input_file >> ht;
    input_file >> max;
    delete [] image;
    image = new int [wd * ht];
    for(int i = 0; i < wd * ht; i++)
        input_file >> image[i];

    input_file.close();
}
// end of load

// Function: empty
bool PGMImage::empty() const
{
    if(image == nullptr)
        return true;
    
    return false;
}
// end of empty


// Function: width
int PGMImage::width() const
{
    return wd;
}
// end of width

// Function: height
int PGMImage::height() const
{
    return ht;
}
// end of height

// Function: max_value
int PGMImage::max_value() const
{
    return max;
}
// end of max_value

// Function: at
int& PGMImage::at(int row, int col)
{
    // bound checking
    if (row < 0 || row >= ht || col < 0 || col >= wd)
        throw out_of_range("Location out of range. (at)" );

    int i = row * wd + col;
    return image[i];
}
// end of at

// Function: at (const version)
const int& PGMImage::at(int row, int col) const
{
    // bound checking
    if (row < 0 || row >= ht || col < 0 || col >= wd)
        throw out_of_range("Location out of range. (at) (const)");

    int i = row * wd + col;
    return image[i];
}
// end of at (const)

// Function: rotate_left
PGMImage PGMImage::rotate_left() const
{
    // creating the new_image
    PGMImage new_image;
    // the wd and ht are swaped when rotated
    new_image.wd = ht;
    new_image.ht = wd;
    new_image.max = max;
    new_image.image = new int [wd * ht];

    // accessing each element of the new image and assigning it
    // to the correct element of the old image
    for(int row = 0; row < wd; row++)
        for(int col = 0; col < ht; col++)
           new_image.at(row, col) = at(col, wd - 1 - row);

    // returning the new_image
    return new_image;
}
// end of rotate_left

// Function: rotate_right
PGMImage PGMImage::rotate_right() const
{
    PGMImage new_image;
    new_image.wd = ht;
    new_image.ht = wd;
    new_image.max = max;
    new_image.image = new int [wd * ht];

    for(int row = 0; row < wd; row++)
        for(int col = 0; col < ht; col++)
            new_image.at(row, col) = at(ht - 1 - col, row);

    return new_image;
}
// end of roate_right

// Function: flip_horizontal
PGMImage PGMImage::flip_horizontal() const
{
    PGMImage new_image;
    new_image.wd = wd;
    new_image.ht = ht;
    new_image.max = max;
    new_image.image = new int [wd * ht];

    for(int row = 0; row < ht; row++)
        for(int col = 0; col < wd; col++)
            new_image.at(row, col) = at(ht - 1 - row, col);
    
    return new_image;
}
// end of flip_horizontal

// Function: flip_vertical
PGMImage PGMImage::flip_vertical() const
{
    PGMImage new_image;
    new_image.wd = wd;
    new_image.ht = ht;
    new_image.max = max;
    new_image.image = new int [wd * ht];

    for(int row = 0; row < ht; row++)
        for(int col = 0; col < wd; col++)
            new_image.at(row, col) = at(row, wd - 1 - col);

    return new_image;
}
// end of flip_vertical

// Function: invert
PGMImage PGMImage::invert() const
{
    PGMImage new_image;
    new_image.wd = wd;
    new_image.ht = ht;
    new_image.max = max;
    new_image.image = new int [wd * ht];

    for(int row = 0; row < ht; row++)
        for(int col = 0; col < wd; col++)
            new_image.at(row, col) = max - at(row, col);
    
    return new_image;
}
// end of invert

// Function: write
void PGMImage::write(const string &filename)
{
    ofstream output_file(filename);
    // error checking
    if(!output_file)
        throw runtime_error("Failed to open output file (write)");

    // print out the contents if the file is not empty
    if(!empty())
    {
        output_file << "P2" << endl;
        output_file << wd << " " << ht << endl;
        output_file << max << endl;
        for(int row = 0; row < ht; row++)
        {
            for(int col = 0; col < wd; col++)
                output_file << setw(4) << at(row, col);
            
            output_file << endl;
        }
    }
    output_file.close();
}
// end of write

// Copy constructor
PGMImage::PGMImage(const PGMImage &source)
{
    this->wd = source.wd;
    this->ht = source.ht;
    this->max = source.max;

    image = new int[wd * ht];
    for(int i = 0; i < wd * ht; i++)
        image[i] = source.image[i];
}
// end of copy constructor

// Destructor
PGMImage::~PGMImage()
{
    if(!empty())
        delete [] image;
}
// end of destructor

// Function: operator=
PGMImage& PGMImage::operator=(const PGMImage &source)
{
    PGMImage cpy(source);

    swap(this->wd, cpy.wd);
    swap(this->ht, cpy.ht);
    swap(this->max, cpy.max);
    swap(this->image, cpy.image);

    return *this;
}
// end of operator=



