// File: image.h
// This file defines the PGMImage class and declares its functions
// and data attributes
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 4             Date assigned: Wed, Oct 16
// Programmer: Karim Soufan          Date completed: 

#ifndef IMAGE_H_
#define IMAGE_H_

#include <iostream>
#include <string>

// Class: PGMImage
class PGMImage
{
    public:
        // Default Constructor
        PGMImage();

        // Function: load
        // reads an image from a file, replacing any image
        // that already exists.
        void load(const std::string &filename); // REC'D: name
                                                // of the file
        
        // Function: empty
        // returns true if there is no image in the object
        bool empty() const;

        // Accessors

        // Function: width
        // returns the width of the image
        int width() const;

        // Function: height
        // returns the height of the image
        int height() const;

        // Function: max_value
        // returns the maximum pixel value of the image
        int max_value() const;

        // Function: at
        // returns a reference to the pixel value at
        // the given row and column indexes
        int& at(int row, // REC'D: row index
                int col); // REC'D: column index

        // const version of function: at
        const int& at(int row, int col) const;

        // Function: rotate_left
        // returns a new PGMImage that is
        // this image rotated to the left 90 degrees
        PGMImage rotate_left() const;

        // Function: rotate_right
        // returns a new PGMImage that is
        // this image rotated to the right 90 degrees 
        PGMImage rotate_right() const;

        // Function: flip_horizontal
        // returns a new PGMImage that is
        // this image flipped about the horizontal axis
        PGMImage flip_horizontal() const;

        // Function: flip_vertical
        // returns a new PGMImage that is
        // this image flipped about the vertical axis
        PGMImage flip_vertical() const;

        // Function: invert
        // returns a new PGMImage that is
        // this image inverted
        PGMImage invert() const;

        // Function: write
        // writes the image to a file
        void write(const std::string &filename); // REC'D: name
                                                 // of the file

        // Copy connstructor
        // creates a new PGMImage that is identical to
        // the original one
        PGMImage(const PGMImage &source); // REC'D: original
                                          // object

        // Destructor
        // deallocates the image if it's not empty
        ~PGMImage();

        // Function: operator=
        // makes an existing PGMImage object identical to
        // the source PGMImage object
        // returns a reference to itself
        PGMImage& operator=(const PGMImage &source); // REC'D:
                                                     // original
                                                     // object

    private:
        // defining the data attributes
        int wd, ht, max, *image;
    
};
// end of PGMImage

#endif // IMAGE_H_