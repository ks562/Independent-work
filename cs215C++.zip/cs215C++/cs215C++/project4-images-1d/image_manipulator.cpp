// File: image_manipulator.cpp
// This file tests the PGMImage class functions
// 
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 4             Date assigned: Wed, Oct 16
// Programmer: Karim Soufan          Date completed: Fri, Oct 25

#include <iostream>
#include <string>
#include <cctype> // tolower()
#include "image.h"

using namespace std;

int main()
{
    // declaring variables
    PGMImage img, img1;
    char command;
    string filename;

    // do-while loop to go through the commands
    do
    {
        // taking the user's command
        cout << "\nEnter your command: ";
        cin >> command;
        command = tolower(command);

        // displaying the help screen
        if(command == 'h')
        {
            cout << endl;
            cout << "Choose from the following commands:" << endl;
            cout << "   L - Load current image from file" << endl;
            cout << "   A - Create new image rotated 90" 
            " degrees left" << endl;
            cout << "   B - Create new image rotated 90"
            " degrees right" << endl;
            cout << "   C - Create new image flipped"
            " along horizontal axis" << endl;
            cout << "   D - Create new image flipped"
            " along vertical axis" << endl;
            cout << "   E - Create new inverted image" << endl;
            cout << "   W - Write new image to file" << endl;
            cout << "   Q - Quit the program" << endl;
        }
        // loading the image
        else if(command == 'l')
        {
            cout << "Enter name of an image file to"
            " load into the current image: ";
            cin >> filename;

            // catching any errors
            try
            {
                img.load(filename);
            }
            catch(const runtime_error& e)
            {
                cerr << e.what() << endl;
                cerr << "Unable to load" << endl;
            }
        }
        // rotating the image to the left
        else if(command == 'a')
        {
            cout << "Creating rotated image" << endl;
            img1 = img.rotate_left();
        }
        // rotating the image to the right
        else if(command == 'b')
        {
            cout << "Creating rotated image" << endl;
            img1 = img.rotate_right();
        }
        // flipping the image horizontally
        else if(command == 'c')
        {
            cout << "Creating flipped image" << endl;
            img1 = img.flip_horizontal();
        }
        // flipping the image vertically
        else if(command == 'd')
        {
            cout << "Creating flipped image" << endl;
            img1 = img.flip_vertical();
        }
        // inverting the image
        else if(command == 'e')
        {
            cout << "Creating inverted image" << endl;
            img1 = img.invert();
        }
        // writing the image to a file
        else if(command == 'w')
        {
            cout << "Enter name of file to write new image: ";
            cin >> filename;
            img1.write(filename);
        }
        // quitting
        else if(command == 'q')
            cout << "Bye!!" << endl;
        
        // if the command is not valid
        else
            cout << "This is not a valid command!" << endl;

    } while (command != 'q'); // if the user quits, break the loop
    
    return 0;
}