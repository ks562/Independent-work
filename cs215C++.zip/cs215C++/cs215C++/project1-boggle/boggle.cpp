//  File: boggle.cpp
//  Find a the words in the example.dat in the grid
// Class: CS 215   Instructor: Dr. Deborah Hwang
// Assignment: Project 1     Date assigned: Sep 9, 2019
// Programmer: Karim Soufan  Date completed: Sep 20, 2019

#include <iostream>
#include <fstream> // ifstream, ofstream
#include <string> // length()

using namespace std;

// the size of the grid with the border
const int SIZE = 7;
// the size of the grid
const int ACTUAL_SIZE = 5;

// struct: Tile
// definition for the grid
struct Tile
{
    char letter;
    bool visited;
};

// Function: create_boggle
// fills the grid with the letters
void create_boggle(ifstream& input_file, // P'BACK
                    Tile grid[][SIZE]); // REC'D: grid

// Function: print_grid
// prints the grid to the console
void print_grid(Tile grid[][SIZE]); // REC'D: grid

// Function: initialize_border
// creates the border around the grid
void initialize_border(Tile grid[][SIZE]); // REC'D: grid

// Function: search_for_word
// returns: bool
bool search_for_word(Tile grid[][SIZE], // REC'D: grid
                int row,    // REC'D: row
                int col,    // REC'D: column
                int index_of_letter, // REC'D: Index of
                                    // the letter of
                                    // the word
                string word); // REC'D: the word from
                            // the input file

int main(int argc, char *argv[])
{
    // error checking for the number of arguments
    if (argc != 3)
    {
        cerr << "Usage: " << argv[0] <<
         " input_file output_file" << endl;
        exit(1);
    }

    // define and initiate the I/O files
    ifstream input_file(argv[1]);
    ofstream output_file(argv[2]);

    // error checking for input file
    if (!input_file)
    {
        cerr << "Cannot open input file "
         << argv[1] << endl;
        exit(1);
    }

    // error checking for output file
    if (!output_file)
    {
        cerr << "Cannot open output file "
         << argv[2] << endl;
        exit(1);
    }

    Tile grid[SIZE][SIZE];

    create_boggle(input_file, grid);
    print_grid(grid);
    initialize_border(grid);

    string word;
    bool found;
    int index_of_letter = 0;

    // while loop for going through
    // all the words in the input file
    while(input_file >> word)
    {
        found = false;
        // double loop to go through the grid
        for(int row = 1; row <= ACTUAL_SIZE && !found; row++)
            for(int col = 1; col <= ACTUAL_SIZE && !found; col++)
            // searching for the word in the grid
                found = search_for_word(grid, row,
                 col, index_of_letter, word);
        
        // checking to see wether the word was found or not
        if(found)
            output_file << word << " found" << endl;
        else
            output_file << word << " not found" << endl;

        // unvisit all the grid cells to start over with the next word
        for(int row = 1; row <= ACTUAL_SIZE; row++)
            for(int col = 1; col <= ACTUAL_SIZE; col++)
                grid[row][col].visited = false;
    }

    // close the files
    input_file.close();
    output_file.close();

    return 0;
}

void create_boggle(ifstream& input_file,
                     Tile grid[][SIZE])
{
    // double loop to read each row and column
    int row, col;
    for(row = 1; row <= ACTUAL_SIZE; row++)
        for(col = 1; col <= ACTUAL_SIZE; col++)
            input_file >> grid[row][col].letter;
}
// End of create_boggle function

void print_grid(Tile grid[][SIZE])
{
    // double loop to print each row and column
    int row, col;
    for(row = 1; row <= ACTUAL_SIZE; row++)
    {
        for(col = 1; col <= ACTUAL_SIZE; col++)
            cout << grid[row][col].letter;

        cout << endl;
    }
}
// End of print_grid function

void initialize_border(Tile grid[][SIZE])
{
    // loop to go through the border
    for(int i = 0; i < SIZE; i++)
    {
        // setting the letter of the borders
        grid[i][0].letter = '+';
        grid[0][i].letter = '+';
        grid[ACTUAL_SIZE + 1][i].letter = '+';
        grid[i][ACTUAL_SIZE + 1].letter = '+';

        // marking the border as visited
        grid[i][0].visited = true;
        grid[0][i].visited = true;
        grid[ACTUAL_SIZE + 1][i].visited = true;
        grid[i][ACTUAL_SIZE + 1].visited = true;
    }
}
// End of initialize_border function

bool search_for_word(Tile grid[][SIZE], int row, int col,
                     int index_of_letter, string word)
{
    //string letter_of_word = grid[row][col].letter;
    // if the letter is not equal to the
    // corresponding letter in the word
    if(grid[row][col].letter != word[index_of_letter])
    {
        return false;
    }

    // if it hits a wall or if it was visited
    if(grid[row][col].letter == '+' ||
       grid[row][col].visited)
        return false;

    // if the word is found
    if(index_of_letter == word.length() - 1)
        return true;

    // set all the cells in the grid to visited
    grid[row][col].visited = true;
    
    
    // try down
    if(search_for_word(grid, row + 1, col,
       index_of_letter + 1, word))
        return true;
        
    // try left
    if(search_for_word(grid, row, col - 1,
        index_of_letter + 1, word))
        return true;

    // try up
    if(search_for_word(grid, row - 1, col,
        index_of_letter + 1, word))
        return true;

    // try right
    if(search_for_word(grid, row, col + 1,
        index_of_letter + 1, word))
        return true;

    // try bottom-right corner
    if(search_for_word(grid, row + 1, col + 1,
        index_of_letter + 1, word))
        return true;

    //  try top-left corner
    if(search_for_word(grid, row - 1, col - 1,
        index_of_letter + 1, word))
        return true;

    // try bottom-left corner
    if(search_for_word(grid, row + 1, col - 1,
        index_of_letter + 1, word))
        return true;

    // try top-right corner
    if(search_for_word(grid, row - 1, col + 1,
        index_of_letter + 1, word))
        return true;

    grid[row][col].visited = false;
    return false;
}
// End of search_for_word function