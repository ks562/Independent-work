// File: mycopy.cpp
// A program to copy a textfile one character at a time
// Usage: ./mycp inputfile outfile

#include <iostream> 
#include <fstream> // Library for filestreams, ifstream/ofstream 
#include <cstdlib> // C library names start with 'c. and have no '.h'
                   // exit()

int main (int argc, char * argv[]) 
{
   using namespace std;
   
   // 1. Check for correct number of arguments
   if(argc != 3)
   {
      cerr << "Usage: " << argv[0] << " input file outputfile" << endl;
      exit(1);
   }


   // 2. Open files
   ifstream infile (argv[1]); //ifstream is the type of an input filestream
                              // C++ allows "constructors" to be called when
                              // when declaring a variable

   ofstream outfile (argv[2]); // ofstream is the type of an output filestream

   // 3. Check for successful opens
   if(!infile) // true if infile has failed
   {
      cerr << "Cannot open input file " << argv[1] << endl;
      exit(1);
   }

   if(!outfile) // true if infile has failed
   {
      cerr << "Cannot open output file " << argv[2] << endl;
      exit(1);
   }
   // 4. Copy one character at a time by
   //    Reading a char until stream fails (usually EOF)

   char ch;
   while (infile.get(ch)) // use get() when need to read all of the characters
                          // >> skips whitespace
         // ((infile >> ch))  // all input streams use >> to read data
                           // >> returns the left side stream object
                           // in a boolean context, stream object converts to
                           //    true, if it is valid
                           //    false, if it has failed
   {
      //    4.1 Write char to output file
         outfile << ch;

   }

   // 5. Close files
   infile.close();
   outfile.close();

   return 0; 
} // end main
