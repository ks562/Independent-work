// File: morse.h
// This file defines the MorseTree class and declares its functions
// and data attributes
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 6             Date assigned: Wed, Nov 13
// Programmer: Karim Soufan          Date completed: Wed, Nov 27

#ifndef MORSE_H_
#define MORSE_H_

#include <iostream> // streams
#include <list>

// class: MorseTree
class MorseTree
{
    private:
        // Node struct definition
        struct Node                    
        {                              
            char data;
            Node* lchild;
            Node* rchild; 

            // Explicit Constructor
            Node (char initial_letter = '*', // REC'D
                  Node* initial_lchild = nullptr, // REC'D
                  Node* initial_rchild = nullptr): // REC'D
                  data(initial_letter), lchild(initial_lchild),
                  rchild(initial_rchild) {}
        };
    public:
        // Operation prototypes

        // Explicit constructor
        MorseTree(std::istream & code_file); // REC'D/P'BACK

        // Function: write
        // prints out the tree sideways
        void write(std::ostream &out); // REC'D/P'BACK

        // Function: decode
        // decodes a message from an input stream,
        // writes it to an output stream
        void decode(std::istream &message_file, // REC'D/P'BACK
                    std::ostream &out); // REC'D/P'BACK

        // Function: encode
        // encodes a message from an input stream,
        // writes it to an output stream
        void encode(std::istream &message_file, // REC'D/P'BACK
                    std::ostream &out); // REC'D/P'BACK

        // Copy Constructor
        // creates a copy of the original MorseTree
        MorseTree(const MorseTree &source); // REC'D

        // Function: perator=
        // returns a reference to this object
        MorseTree& operator=(const MorseTree &source); // REC'D

        // Destructor
        ~MorseTree();
    private:
        // Attribute declaration
        Node* root;
        // private functions

        // helper function: write_tree
        void write_tree(std::ostream &out, // REC'D/P'BACK
                        Node* local_root, // REC'D
                        int depth); // REC'D

        // helper function: delete_tree
        void delete_tree(Node* source_root); // REC'D

        // helper function: char_to_code
        // returns a string
        std::string char_to_code(char ch, // REC'D
                        Node* tree_node, // REC'D
                        const std::string &path_so_far); // REC'D

        // helper function: copy_tree
        // copies a binary tree and returns the root of the copy
        Node* copy_tree(Node* local_root); // REC'D
};
// end of MorseTree

#endif // MORSE_H_