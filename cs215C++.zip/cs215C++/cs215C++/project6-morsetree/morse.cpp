// File: document2.cpp
// This file tests the MorseTree class functions
//
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 6             Date assigned: Wed, Nov 13
// Programmer: Karim Soufan          Date completed: Wed, Nov 27

#include <iostream>
#include <string>
#include <list>
#include <cctype> // isalpha
#include <algorithm>
#include "morse.h"

using namespace std;

// explicit-value constructor
MorseTree::MorseTree(istream & code_file)
{
    int n = 0;
    code_file >> n;

    char letter;
    string code;
    // creating a the root node
    root = new Node;
    Node* scanptr; 
    for(int i = 0; i < n; i++)
    {
        scanptr = root;

        code_file >> letter;
        code_file >> code;
        // looping through the string characters
        for(int j = 0; j < code.length(); j++)
        {
            // if a dot is found, go left
            if(code[j] == '.')
            {
                // if the node does not exits, create it.
                if(scanptr->lchild == nullptr)
                    scanptr->lchild = new Node;
                
                // go on to it
                scanptr = scanptr->lchild;
            }
            // if a dash is found, go right
            else if(code[j] == '-')
            {
                // if the node is not found, create it
                if(scanptr->rchild == nullptr)
                    scanptr->rchild = new Node;
                
                // go onto it
                scanptr = scanptr->rchild;
            }
        }
        // fill in the data
        scanptr->data = letter;
    }
}
// end of explicit-value constructor

// Function: write_tree
void MorseTree::write_tree(ostream &out,
                        Node* local_root,
                        int depth)
{
    // if the node doesn't exist
    if(local_root == nullptr)
        return;

    // RNL traversal
    write_tree(out, local_root->rchild, depth + 1); // R
    for(int i = 0; i < 8 * depth; i++) // number of spaces
        out << " ";
    out << local_root->data << endl; // N
    write_tree(out, local_root->lchild, depth + 1); // L
}
// end of write_tree

// Function: write
void MorseTree::write(ostream &out)
{
    int depth = 0;
    write_tree(out, root, depth);
}
// end of write

// Function: decode
void MorseTree::decode(istream &message_file, ostream &out)
{
    string code;
    Node* scanptr;
    // reading in the string
    while (message_file >> code)
    {
        scanptr = root;

        // if vertical bar found, print space
        if(code == "|")
            out << " ";
        
        // if two vertical bar found, print newline
        else if(code == "||")
            out << endl;
        
        // if it's a dot or a dash
        else
        {
            // looping through the string
            for(int i = 0; i < code.length(); i++)
            {
                // error checking for invalid character
                if(code[i] != '.' && code[i] != '-' &&
                   code[i] != '|')
                    cerr << "The character is not valid!" << endl;

                // if dot, move left
                else if(code[i] == '.')
                    scanptr = scanptr->lchild;
                
                // if dash, move right
                else if(code[i] == '-')
                    scanptr = scanptr->rchild;
            }
            // print the data
            out << scanptr->data;
        }
    }
}
// end of decode

// Function: char_to_code
string MorseTree::char_to_code(char ch, Node* tree_node,
                    const string &path_so_far)
{
    if(tree_node == nullptr) // empty tree
        return "";

    if(tree_node->data == ch) // character is found
        return path_so_far;

    string p1, p2;
    p1 = char_to_code(ch, tree_node->lchild, path_so_far + '.');
    p2 = char_to_code(ch, tree_node->rchild, path_so_far + '-');
    return p1 + p2;
}
// end of chat_to_code

// Function: encode
void MorseTree::encode(istream &message_file, ostream &out)
{
    char ch;
    string code;
    // getting the character
    while (message_file.get(ch))
    {
        // if it is a letter
        if(isalpha(ch))
        {
            // convert it to morse code
            code = char_to_code(ch, root, "");
            out << code << " ";
        }

        // if it's a soace, print a vertical bar
        else if(ch == ' ')
            out << "| ";

        // if it's a newline, print two vertical bars
        else if(ch == '\n')
        {
            out << "||";
            // peeking to check if the end of the file is reached
            if (message_file.peek() != EOF)
                out << " ";
        }
        else
            cerr << "This character is not valid!" << endl;

    }
    out << endl;
}
// end of encode

// Function: delete_tree
void MorseTree::delete_tree(Node* source_root)
{
    // Post-order traversal
    // Delete the children first, then the node
    if (source_root != nullptr) // if tree is not empty
    {
        delete_tree(source_root->lchild); // L
        delete_tree(source_root->rchild); // R
        delete source_root;               // N
    }
}
// end of delete_tree

// Function: copy_tree
MorseTree::Node* MorseTree::copy_tree(Node* source_root)
{
    // Pre-order traversal
    // Copy the root node, then copy the children
    Node* copy_root = nullptr;
    if (source_root != nullptr)
    {
        copy_root = new Node(source_root->data);
        // copy the children and hook it up to the new root
        copy_root->lchild = copy_tree(source_root->lchild);
        copy_root->rchild = copy_tree(source_root->rchild);
    }
    return copy_root;
}
// end of copy_tree

// Copy constructor
MorseTree::MorseTree(const MorseTree &source)
{
    root = copy_tree(source.root);
    Node* first;
    first = root;
    if(first != nullptr)
    {
        while (first->lchild != nullptr)
            first = first->lchild;
    }
}
// end of copy constructor

// Function: operator=
MorseTree& MorseTree::operator=(const MorseTree &source)
{
    MorseTree copy(source);
    swap(root, copy.root);
    return *this;
}
// end of operator=

// Destructor
MorseTree::~MorseTree()
{
    delete_tree(root);
}
