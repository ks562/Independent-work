// File: editor2.cpp
// This file tests the MoreTree class functions
//
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 6             Date assigned: Wed, Nov 13
// Programmer: Karim Soufan          Date completed: Wed, Nov 27

#include <iostream>
#include <fstream>
#include <cctype> // tolower
#include "morse.h"

using namespace std;

int main(int argc, char* argv[])
{
    // command lines error checking
    if(argc != 2)
    {
        cerr << "Usage: " << argv[0] <<
         " input_file output_file" << endl;

        exit(1);
    }

    ifstream input_file(argv[1]);
    if (!input_file)
    {
        cerr << "Cannot open input file " << argv[1] << endl;
        exit(1);
    }

    // creating and printing the tree
    MorseTree tree(input_file);
    tree.write(cout);
    cout << endl;

    string file_name;
    char command;

    do
    {
        // asking the user for input
        cout << "Please choose one of:\n\n";
        cout << "   E - Encode a message" << endl;
        cout << "   D - Decode a message" << endl;
        cout << "   Q - Quit the program\n" << endl;
        cout << "Enter your choice: ";
        cin >> command;
        command = tolower(command);

        // if encode is chosen
        if(command == 'e')
        {
            cout << "Enter the name of a plaintext message file: ";
            cin >> file_name;

            // creating the input file and error checking
            ifstream in(file_name);
            if (!in)
            {
                cerr << "Cannot open input file " 
                << file_name << endl;
                exit(1);
            }

            cout << "Enter name of output file: ";
            cin >> file_name;

            // creating the output file and error checking
            ofstream out(file_name);
            if (!out)
            {
                cerr << "Cannot open output file " 
                << file_name << endl;
                exit(1);
            }

            // encoding
            tree.encode(in, out);
            // closing the files
            in.close();
            out.close();
        }
        // if decode is chosen
        else if(command == 'd')
        {
            cout << "Enter the name of an encoded message file: ";
            cin >> file_name;

            ifstream in(file_name);
            if (!in)
            {
                cerr << "Cannot open input file " 
                << file_name << endl;
                exit(1);
            }

            cout << "Enter name of output file: ";
            cin >> file_name;

            ofstream out(file_name);
            if (!out)
            {
                cerr << "Cannot open output file " 
                << file_name << endl;
                exit(1);
            }

            tree.decode(in, out);
            in.close();
            out.close();
        }
    } while (command != 'q'); // do while the user 
                              //doesn't quit the program

    // closing the file
    input_file.close();
    return 0;
}