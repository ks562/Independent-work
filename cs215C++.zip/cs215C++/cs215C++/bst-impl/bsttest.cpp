#include "bst.h"

#include <iostream>
#include <iomanip>
#include <functional>

using namespace std;

template <typename T>
using BST_L = Binary_Search_Tree<T,less<int> >;
template <typename T>
using BST_G = Binary_Search_Tree<T,greater<int> >;

template <typename T, typename C>
void show_tree(const Binary_Search_Tree<T,C>&t)
{
   t.write_tree();
   t.check_tree();
}

template <typename T, typename C>
void print_tree(const Binary_Search_Tree<T, C>& t)
{
   cout << "---> [" << t.size() << "/" << t.empty() << "]";
   for (auto p = t.begin(); p != t.end(); p++) {
      cout << " " << *p;
   }
   cout << " <---" << endl;
}

template <typename T, typename C>
void check_value(const Binary_Search_Tree<T, C>& t, const T& item)
{
   typename Binary_Search_Tree<T,C>::const_iterator p = t.find(item);
   if (p == t.end()) { cout << item << " is not in tree"; }
   else { cout << *p << " is in tree"; }
   cout << endl;
}

int main()
{
   {
      BST_L<int> t;
      cout << boolalpha;
      cout << "---> [" << t.size() << "/" << t.empty() << "]";
      for (auto p = t.begin(); p != t.end(); p++) {
	 cout << " " << *p;
      }
      cout << " <---" << endl;
      cout << *t.insert(50) << endl;  // * dereferences the returned iterator
      print_tree(t);
      t.insert(25);
      print_tree(t);
      t.insert(75);
      print_tree(t);
      t.insert(40);
      print_tree(t);
      t.insert(45);
      print_tree(t);
      t.insert(90);
      print_tree(t);
      t.insert(80);
      print_tree(t);
      t.insert(70);
      print_tree(t);
      t.insert(30);
      print_tree(t);

      // duplicate insertions
      cout << *t.insert(50) << endl;
      print_tree(t);
      t.insert(25);
      print_tree(t);
      t.insert(75);
      print_tree(t);
      t.insert(40);
      print_tree(t);
      t.insert(45);
      print_tree(t);
      t.insert(90);
      print_tree(t);
      t.insert(80);
      print_tree(t);
      t.insert(70);
      print_tree(t);
      t.insert(30);
      print_tree(t);

      show_tree(t);
    
      check_value(t, 50);
      check_value(t, 25);
      check_value(t, 75);
      check_value(t, 40);
      check_value(t, 30);
      check_value(t, 45);
      check_value(t, 70);
      check_value(t, 90);
      check_value(t, 80);
    
      check_value(t, 49);
      check_value(t, 51);
      check_value(t, 24);
      check_value(t, 26);
      check_value(t, 74);
      check_value(t, 76);
      check_value(t, 39);
      check_value(t, 41);
      check_value(t, 44);
      check_value(t, 46);
      check_value(t, 69);
      check_value(t, 71);
      check_value(t, 89);
      check_value(t, 91);
      check_value(t, 79);
      check_value(t, 81);
    
      cout << *t.find(80) << endl;
      cout << t.count(80) << endl;
      cout << t.count(81) << endl;
      t.clear();
      print_tree(t);
      t.insert(18);
      print_tree(t);
      t.insert(14);
      print_tree(t);
      t.insert(2);
      print_tree(t);
      t.insert(17);
      print_tree(t);
      t.insert(15);
      print_tree(t);
      t.insert(25);
      print_tree(t);
      t.insert(20);
      print_tree(t);
      t.insert(31);
      print_tree(t);
      t.insert(29);
      print_tree(t);
      t.insert(35);
      print_tree(t);
      show_tree(t);
   }

   {
      BST_L<int> t = {
	 18, 14, 2, 17, 15, 25, 20, 31, 29, 35, 19
      };
      print_tree(t);
      show_tree(t);

      BST_L<int> tt(t);
      print_tree(tt);
      show_tree(tt);
   }

   {
      const BST_G<int> t = {
	 18, 14, 2, 17, 15, 25, 20, 31, 29, 35, 19
      };
      print_tree(t);
      show_tree(t);
   }

   {
      for (auto x: {2,14,15,17,18,19,20,25,29,31,35,99}) {
	 BST_L<int> t = {
	    18, 14, 2, 17, 15, 25, 20, 31, 29, 35, 19
	 };
	 print_tree(t);
	 show_tree(t);

	 cout << "Removing " << x << ":" << endl;
	 t.erase(x);
	 print_tree(t);
	 show_tree(t);
	 cout << "-----------" << endl;
      }
   }

   {
      BST_L<int> t = {
	 18, 14, 2, 17, 15, 25, 20, 31, 29, 35, 19
      };
      print_tree(t);
      show_tree(t);
      for (auto x: {2,14,15,17,18,19,20,25,29,31,35,99}) {
	 cout << "Removing " << x << ":" << endl;
	 t.erase(x);
	 print_tree(t);
	 show_tree(t);
      }
   }

   {
      BST_L<int> t = {
	 18, 14, 2, 17, 15, 25, 20, 31, 29, 35, 19
      };
      print_tree(t);
      show_tree(t);
      for (auto x: {99,35,31,29,25,20,19,18,17,15,14,2}) {
	 cout << "Removing " << x << ":" << endl;
	 t.erase(x);
	 print_tree(t);
	 show_tree(t);
      }
   }
}
