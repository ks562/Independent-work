// File: bst.h
// Based on Binary_Search_Tree <T, Compare> template class
// From Wittenberg, Data Structures and Algorithms in C++ Pocket Primer
// Ch. 6

#ifndef BST_H
#define BST_H

#include <functional> // less<T>, defines operator () that returns result of <
#include <initializer_list>
#include <iostream>

template <typename T, typename Compare = std::less<T>>
class Binary_Search_Tree
{
private:
   struct Node
   {
      T data;
      Node *lchild, *rchild;
      Node *parent; // so can move up the tree, too
      Node(const T &item, Node *p = nullptr,
           Node *left = nullptr, Node *right = nullptr)
          : data(item), lchild(left), rchild(right),
            parent(p) {}
   };

   template <typename U>
   class Iter
   {
   private:
      Node *curr;
      friend class Binary_Search_Tree<T>;

   public:
      Iter(Node *p) : curr(p) {}
      Iter<U> &operator++() // prefix ++
      {
         curr = inorder_successor(curr);
         return *this;
      }
      Iter<U> operator++(int) // postfix ++
      {
         Iter<U> result = Iter<U>(curr);
         curr = inorder_successor(curr);
         return result;
      }
      U &operator*() const { return curr->data; }
      U *operator->() const { return &(curr->data); }
      bool operator==(const Iter &other) const
      {
         return curr == other.curr;
      }
      bool operator!=(const Iter &other) const
      {
         return not(curr == other.curr);
      }
   };

public:
   typedef Iter<T> iterator;
   typedef Iter<const T> const_iterator;

   Binary_Search_Tree() : root(nullptr), num_nodes(0), first(nullptr) {}
   ~Binary_Search_Tree() { delete_tree(root); }

   Binary_Search_Tree(const Binary_Search_Tree<T, Compare> &other)
   {
      root = copy_tree(other.root);
      num_nodes = other.num_nodes;

      // find first node (leftmost)
      first = root;
      if (first != nullptr)
      {
         while (first->lchild != nullptr)
         {
            first = first->lchild;
         }
      }
   }

   Binary_Search_Tree(std::initializer_list<T> init) : Binary_Search_Tree()
   {
      for (auto p = init.begin(); p != init.end(); p++)
      {
         insert(*p);
      }
   }

   Binary_Search_Tree<T, Compare> &operator=(const Binary_Search_Tree<T, Compare> &other)
   {
      // DIFFERENT THAN TEXTBOOK
      // COPY AND SWAP TECHNIQUE
      // Make a copy
      Binary_Search_Tree<T, Compare> copy(other);
      // Swap attributes
      // don't need to swap cmp, since it is a function
      std::swap(root, copy.root);
      std::swap(num_nodes, copy.numnodes);
      std::swap(first, copy.first);

      // return destructs copy with old data
      return *this;
   }

   int size() const { return num_nodes; }
   bool empty() const { return size() == 0; }

   int count(const T &item) const
   {
      if (search(root, item) == nullptr)
      {
         return 0;
      }
      else
      {
         return 1;
      }
   }

   iterator find(const T &item)
   {
      return iterator(search(root, item));
   }
   const_iterator find(const T &item) const
   {
      return const_iterator(search(root, item));
   }

   iterator insert(const T &item)
   {
      return iterator(add(root, item));
   }

   void erase(const T &item)
   {
      Node *&p = search(root, item);
      if (p != nullptr)
      {
         remove_node(p);
         --num_nodes;
      }
   }

   void clear()
   {
      delete_tree(root);
      root = first = nullptr;
      num_nodes = 0;
   }

   iterator begin() { return iterator(first); }
   const_iterator begin() const { return const_iterator(first); }

   iterator end() { return iterator(nullptr); }
   const_iterator end() const { return const_iterator(nullptr); }

   // Added member functions to print out and check tree state
   // Not part of actual operations of BST
   void write_tree() const { show_nodes(root, 0, '-'); }
   void check_tree() const { check_nodes(root); }

   // Attributes
private:
   Node *root;
   int num_nodes; // counter so size() is O(1)
   Node *first;   // location of the first node of iteration
                  // to make begin() O(1)
   Compare cmp;   // "renames" Compare()(a,b) to cmp(a,b)

   // Private helper functions that operate on root of (sub)tree.
   // This is where the real work is done

   // Const version
   Node *search(Node *root, const T &item) const
   {
      if (root == nullptr) // check for empty tree
         return root;
      if (cmp(item, root->data))            // by default: item < root->data
         return search(root->lchild, item); // search to the left
      else if (cmp(root->data, item))       // root->data < item
         return search(root->rchild, item); // search the right child
      else                                  // root's data is equal to item
                                            // return the root node
         return root;
   }

   // Non-const version, return reference
   Node *&search(Node *&root, const T &item)
   {
      if (root == nullptr) // check for empty tree
         return root;
      if (cmp(item, root->data))            // by default: item < root->data
         return search(root->lchild, item); // search to the left child
      else if (cmp(root->data, item))       // root->data < item
         return search(root->rchild, item); // search the right child
      else                                  // root's data is equal to item
                                            // return the root node
         return root;
   }

   Node *add(Node *&root, const T &item, Node *parent = nullptr)
   {
      if (root == nullptr) // not in the tree at root
      {
         // create a node with the item and hoot it up
         root = new Node(item, parent);
         // count it
         num_nodes++;
         // adjust first, if needed
         if (first == nullptr || cmp(root->data, first->data)) // item < first's data
            // new first node
            first = root;
         return root;
      }

      if (cmp(item, root->data))               // by default: item < root->data
         return add(root->lchild, item, root); // add to the left child
      else if (cmp(root->data, item))          // root->data < item
         return add(root->rchild, item, root); // add the right child
      else                                     // root's data is equal to item
                                               // ignore any duplicates, nut still want to return pointer
         return root;
   }

   void remove_node(Node *&curr)
   {
      if (curr == nullptr)
      {
         return;
      } // defensive programming
      if (curr == first)
      {
         first = inorder_successor(curr);
      }
      // Case 1: node with no children (a leaf)
      if (curr->lchild == nullptr && curr->rchild == nullptr)
      {
         // delete the node
         delete curr;
         // set curr to nullptr
         curr = nullptr;
      }
      // Case 2: node with one child
      else if (curr->lchild == nullptr || curr->rchild == nullptr)
      {
         Node *temp = curr; // pointer to node to be deleted
         // make curr variable point to the child that exists
         if (curr->lchild != nullptr)
            curr = curr->lchild;
         else
            curr = curr->rchild;
         // make curr's node parent pointer point tothe original's parent
         curr->parent = temp->parent;
         // delete the node
         delete temp;
      }
      // Case 3: two children
      else
      {
         // Find the in-order successor
         Node *successor = inorder_successor(curr);
         // copy successor value into curr node
         curr->data = successor->data;

         // use the parent's link variable to delete the successor node
         if (successor == successor->parent->lchild)
            remove_node(successor->parent->lchild);
         else
            remove_node(successor->parent->rchild);
      }
   }

   // needs to be friend since it is called from the Iter inner class, too
   friend Node *inorder_successor(Node *curr)
   {
      if (curr == nullptr) // defensive programming
      {
         return nullptr;
      }
      if (curr->rchild != nullptr)
      { // always true when erasing
         // go right
         curr = curr->rchild;
         // go left to the last node on the left
         while (curr->lchild != nullptr)
            curr = curr->lchild;
      }
      else
      { // to support iter++
         {
            Node *prev = curr;
            curr = curr->parent;
            while (curr != nullptr and prev == curr->rchild)
            {
               prev = curr;
               curr = curr->parent;
            }
         }
      }
      return curr;
   }

   void delete_tree(Node *local_root)
   {
      // Post-order traversal
      // Delete the children first, then the node
      if (local_root != nullptr) // if tree is not empty
      {
         delete_tree(local_root->lchild); // L
         delete_tree(local_root->rchild); // R
         delete local_root;               // N
      }
   }

   Node *copy_tree(Node *local_root, Node *parent = nullptr)
   {
      // Pre-order traversal
      // Copy the root node, then copy the children
      Node *new_root = nullptr;
      if (local_root != nullptr)
      {
         new_root = new Node(local_root->data, parent);
         // copy the children and hook it up to the new root
         new_root->lchild = copy_tree(local_root->lchild, new_root);
         new_root->rchild = copy_tree(local_root->rchild, new_root);
      }
      return new_root;
   }

   // Extra helper function in support of write_tree
   // Traverses tree in reverse in-order (RNL)
   void show_nodes(Node *local_root, int level, char child) const
   {
      if (local_root == nullptr)
      {
         // empty tree
         std::cout << child;
         for (auto i = 1; i <= level; i++)
         {
            std::cout << "-";
         }
         std::cout << "> -" << std::endl;
      }
      else
      {
         // print both children if one exists
         if (local_root->lchild != nullptr or local_root->rchild != nullptr)
         {
            // print right child
            show_nodes(local_root->rchild, level + 1, 'R');
         }

         // print whether left or right
         std::cout << child;
         // print -'s to show depth
         for (auto i = 1; i <= level; i++)
         {
            std::cout << "-";
         }
         // print node value
         std::cout << "> " << local_root->data << std::endl;

         // print both children if one exists
         if (local_root->lchild != nullptr or local_root->rchild != nullptr)
         {
            // print left child
            show_nodes(local_root->lchild, level + 1, 'L');
         }
      }
   }

   // Extra helper function in support of check_tree
   void check_nodes(Node *local_root, Node *par = nullptr) const
   {
      if (local_root == nullptr)
      {
         return;
      }
      if (local_root->parent != par)
      {
         std::cout << "Inconsistent parent pointer in node " << local_root->data
                   << ":  " << local_root->parent << " != " << par << std::endl;
      }
      check_nodes(local_root->lchild, local_root);
      check_nodes(local_root->rchild, local_root);
   }
};

#endif
