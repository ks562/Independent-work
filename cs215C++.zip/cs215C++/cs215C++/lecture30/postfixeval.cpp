// File: postfixeval.cpp
// Evaluates integer infix expressions by first converting to postfix
// Based on an example in Wittenberg, Data Structures and Algorithms
// in C++ Pocket Primer

#include <iostream>
#include <cctype>
#include <stdexcept>
#include <string>
#include <stack>
#include <queue>
using namespace std;

const string OPERATORS = "(+-*/)";

// Function: priority
// Assumes op is one of the operators
// Returns the precedence priority of op
int priority(const string & op);  // REC'D: Operator string

// Function: print_tokens
// Prints the elements of tokens to the screen
// Since queue<T> does not have an iterator, 
// use value a parameter to make a copy.
void print_tokens (queue<string> tokens); // REC'D: copy of tokens

// Function: tokenize
// Parses a string into a queue of integer expression tokens
// and returns the queue
queue<string> tokenize (const string & input);  // REC'D: input string

// Function: infix_to_postfix
// Converts tokenized infix expression to a tokenized postfix expression
// and returns the  tokenized postfix expression
// Assumes the expression is well-formed
// Since queue<T> does not have an iterator, 
// use value a parameter to make a copy.
queue<string> infix_to_postfix (queue<string> infix);
                               // REC'D: copy of infix expr tokens

// Function: postfix_eval
// Evaluates an integer postfix expression and returns the result
// Assumes the expression is well-formed
// Since queue<T> does not have an iterator, 
// use value a parameter to make a copy.
int postfix_eval(queue<string> postfix);  // REC'D: copy of postfix expr tokens

int main()
{
   string input;
   cout << "Enter an integer infix expression on one line (or Enter to quit):"
	<< endl;
   while (getline(cin, input)) { // loop while stream is valid
      try {
	 if (input == "") break; // result of typing just Enter is empty string

	 queue<string> tokens = tokenize(input);
	 cout << "Tokenized input: ";
	 print_tokens(tokens);

	 queue<string> postfix = infix_to_postfix(tokens);
	 cout << "Postfix expression: ";
	 print_tokens(postfix);

	 int result = postfix_eval(postfix);
	 cout << "== " << result << endl;
      } catch (const invalid_argument & ex) {
	 cout << "Syntax error: " << ex.what() << endl;
      }
      cout << "Enter another integer infix expression:" << endl;
   }
   return 0;
}

int priority(const string & op)
{
   if (op == "(")
      return 0;
   if (op == "+" || op == "-")
      return 1;
   if (op == "*" || op == "/")
      return 2;
   return -1;  // should not happen, suppresses warnings
}

void print_tokens (queue<string> tokens) // REC'D: copy of tokens
{
   while(!tokens.empty())
   {
      string token = tokens.front();
      tokens.pop();
      cout << token;
      if (!tokens.empty())
	 cout << ' ';
      else
	 cout << endl;
   }
}

queue<string> tokenize (const string & input)
{
   queue<string> tokens;
   size_t i = 0;

   // Scan input
   while (i < input.length())
   {
      // Check if at an operator
      if (OPERATORS.find(input[i]) != string::npos)
      {
	 tokens.push (input.substr(i, 1));  // char as string
	 i++;
      }
      // Check if it an operand
      else if (isdigit(input[i]))
      {
	 // Compute # of digits in the operand
	 size_t next = input.find_first_not_of("0123456789", i);
	 size_t num_length = next - i;
	 tokens.push (input.substr(i, num_length));  // # as a string
	 i = next;
      }
      // Otherwise, skip whitespace
      else
	 i++;
   }
   return tokens;
}
	 
queue<string> infix_to_postfix (queue<string> infix) // Rec'd: copy of infix expr
{
   queue<string> postfix;
   stack<string> opstack;  // operators not done yet

   // While still have infix tokens
   while (!infix.empty())
   {
      // Get next element of infix
      string token = infix.front();
      infix.pop();

      // Figure out which kind of token it is
      // If it a left parenthesis
      if(token == "(")
         // push it onto the opstack
         opstack.push(token);


      // If it is right parenthesis
      else if(token == ")")
      {
         while(opstack.top() != "(")
         {
            postfix.push(opstack.top());
            opstack.pop();
         }
         // get rid of the (
         opstack.pop();
      }

      // If it is an operator
      else if(OPERATORS.find(token[0]) != string::npos)
      {
         // push all of the operators that have higher precedence
         while (!opstack.empty() && priority(opstack.top()) > priority(token))
         {
            postfix.push(opstack.top());
            opstack.pop();
         }

         // push this one onto the opstack
         opstack.push(token);
      }

      // Else it is an operand
      else
      {
         // put it in the postfix expression
         postfix.push(token);
      }
      
      
   }  // while infix not empty

   // The rest of the operators go in last
   while(!opstack.empty())
   {
      postfix.push(opstack.top());
      opstack.pop();
   }

   return postfix;
}
      
int postfix_eval(queue<string> postfix)  // Rec'd: copy of postfix expr
{
   stack<int> operand_stack;  // stack for operands

   // Process each token
   while (!postfix.empty())
   {
      // Get the next token
      string token = postfix.front();
      postfix.pop();

      // If is an operand
      if(isdigit(token[0]))
      {
         // convert string to integer
         int num = stoi(token);
         // push onto operand stack
         operand_stack.push(num);
      }

      // Else if it is an operator
      else
      {
         int operand1, operand2;
         // Get the second operand and pop it off
         operand2 = operand_stack.top();
         operand_stack.pop();
         // Apply the operator to the operands
         int result;
         switch (token[0])
         {
            case '+':
               result = operand1 + operand2;
               break;

            case '-':
               result = operand1 - operand2;

            case '*':
               result = operand1 * operand2;

            case '/':
               result = operand1 / operand2;
            
            default:
               result = 0;
         }
         // Push result onto stack
         operand_stack.push(result);
      }
   } // end of loop

   // Get the result
   int answer = operand_stack.top();
   operand_stack.pop();
   return answer;
}
