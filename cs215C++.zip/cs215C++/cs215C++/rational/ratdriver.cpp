// File: ratdriver.cpp
// Test program for Rational class
// ----------------------------------------------------------------------
// Class: CS 215
// Lecture 10
// September 19, 2019

#include <iostream>
#include "rational.h"

int main ()  // no command-line arguments
{
   using namespace std;

   const Rational zero (0, 1);
   Rational r1;   // default value
   Rational r2 (4), r3 (0,12);  // explicit-value construction

   cout << "r1's numerator: " << r1.numerator()
	<< "; r1's denominator: " << r1.denominator() << endl;
   cout << "r2's numerator: " << r2.numerator()
	<< "; r2's denominator: " << r2.denominator() << endl;
   cout << "r3's numerator: " << r3.numerator()
	<< "; r3's denominator: " << r3.denominator() << endl;

   try
   {
      r1 = r3.reciprocal();
   }
   catch(const std::range_error & ex) // parameter is the type of thrown object
   {
      std::cerr << ex.what() << endl; // message inside the object
      cerr << "r3 will not change value" << endl;
   }
   

   cout << "r1 = " << r1 << endl;
   cout << "r2 = " << r2 << endl;
   cout << "r3 = " << r3 << endl;

   cout << "Enter a rational number (n/d): ";
   cin >> r1;
   cout << "r1 = " << r1 << endl;

   cout << "Enter another rational number: ";
   cin >> r2;

   r3 = r1 * r2;
   cout << r1 << " * " << r2 << " = " << r3 << endl;

   if(r1 == r2)
      cout << "They are equal!" << endl;
   else
      cout << "They are not equal!" << endl;
      
   return 0;
}
