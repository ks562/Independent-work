// File: rational.h
// Header file for Rational class that models a rational number
// ----------------------------------------------------------------------
// Class: CS 215
// Lecture 10
// September 13, 2019

// WARNING: DO NOT put "using namespace std;" in a header file

#ifndef RATIONAL_H_
#define RATIONAL_H_

#include <iostream> // streams

class Rational // defines a Rational type
{
   public:  // prototypes of the operations
      // Constructor
      //Rational();                      // Default value: 0/1
      //Rational(int n);                 // Explicit value constructor: n/1

      // Providing default arguments allows this function to be called with
      // fewer than 2 arguments
      Rational(int n = 0, int d = 1);          // Explicit value constructor: n/d
   
      // Accessors
      int numerator() const;           // return num
      int denominator() const;         // return denom

    // Returns the reciprocal of this object
    Rational reciprocal() const;

    // Mutators - functions that change this object
    // Change this object to its reciprocal
    void invert();  // no const since this will change the object

    // Friend functions - prototypes of the function prefixed by "friend"
    // I/O operator
    // type of cout is ostream, but the actual object needs to be returned
    //    the returned type is ostream& - the & means a reference rather than
    //    a value
    // Streams always passed by reference
    // Class objects are always by reference, but if received-only they
    //    also const
    friend std::ostream& operator<<(std::ostream &outStream,
                                    const Rational & rat); // received
    friend std::istream& operator>>(std::istream &inStream,
                                    Rational & rat); // passed back

    // Arithmetic operator
    friend Rational operator*(const Rational & lhs, // received multilicand
                              const Rational & rhs);// received multipliers

    // Relational/equality operator
    friend bool operator==(const Rational & lhs,
                           const Rational & rhs);

  private:  // Decleration of the attributes
      int num, denom;      // n/d
      void reduce();       // prototype of an operatio which only
                           // other operations can use/call
};

#endif