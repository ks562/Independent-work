// File: rational.cpp
// Implementation file for Rational class
// ----------------------------------------------------------------------
// Class: CS 215
// Lecture 10
// September 13, 2019

#include <iostream>
#include <cstdlib> // abs()
#include <sstream>
#include <cassert>
#include <stdexcept> // exception object types
#include "rational.h"

// Euclid's algorithm for greatest common divisor
int GCD (int m, int n)
{
   if (m < n)  // swap values
   {
      int t = n;
      n = m;
      m = t;
   }
   while (n > 0)
   {
      int t = n;
      n = m % n;
      m = t;
   }
   return m;
} // end GCD

// Private member function
void Rational::reduce()
{
   // make sure negative is in the numerator
   if(denom < 0) // move the negative to num
   {
      num *= -1;
      denom *= -1;
   }

   // check for a gcd > 1
   int div = GCD(abs(num), denom);
   if(div != 1)
   {
      num = num / div;
      denom = denom / div;
   }

   // check for denom = 0

}
// Default constructor: 0/1
// Every function name of a class must be prefixed with
// the scope operator, e.g., Rational::
// This tells the compiler these functions belong to the class
// and allow access to the attributes.
/*
Rational::Rational() : num(0), denom(1) // attribute initialization
{

}  // end default constructor

// Explicit value constructor: n/1
Rational::Rational(int n) : num(n), denom(1)
{

}  // end explicit value constructor
*/

// Explicit value constructor: n/d
Rational::Rational(int n, int d) : num(n), denom(d)
{
   // Class invariant - definition of what is a valid, canonical object
   //   - ratio is in reduced form, i.e., no common divisor of num and denom
   //   - if the ratio is negative, num is the negative part
   //   - if the ratio is positive, num and denom are positive
   //   - denom cannot be 0
   reduce(); // put the object into canonical form

}  // end explicit value constructor

// Function: numerator
// Returns: num of rational number
int Rational::numerator() const
{
   return num;
}  // end numerator

// Function: denominator
// Returns: denom of rational number
int Rational::denominator() const
{
   return denom;
}  // end denominator

Rational Rational::reciprocal() const
{
   // error checking
   if(num == 0)
      // throw is like return, it immediately terminates the function
      throw std::range_error("Rational::reciprocal() - numerator is 0");
   // reciprocal is d/n
   return Rational(denom, num); // constructor call
}

void Rational::invert()
{
   // error checking
   if(num == 0)
      // throw is like return, it immediately terminates the function
      throw std::range_error("Rational::invert() - numerator is 0");
   // swap num and denom
   int temp;
   temp = num;
   num = denom;
   denom = temp;
}

// Friend function definition - NO FRIEND KEYWORD! NO SCOPE OPERATOR!
std::ostream& operator<<(std::ostream &outStream,
                         const Rational & rat)
{
   // Write out n/d to outStream
   // DO NOT WRITE OUT A NEWLINE!
   outStream << rat.num << '/' << rat.denom;

   // return the stream
   return outStream;
}

std::istream& operator>>(std::istream &inStream,
                         Rational & rat)
{
   // this will need error checking later
   char slash; // to read out the punctuation
   inStream >> rat.num >> slash >> rat.denom;
   rat.reduce();

   return inStream;
}

Rational operator*(const Rational & lhs,
                   const Rational & rhs)
{
   return Rational(lhs.num * rhs.num, lhs.denom * rhs.denom);
}      

bool operator==(const Rational & lhs,
                const Rational & rhs)
{
   return lhs.num == rhs.num && lhs.denom == rhs.denom;
}