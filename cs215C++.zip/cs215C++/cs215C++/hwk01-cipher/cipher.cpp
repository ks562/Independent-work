#include <iostream>
#include <cstdlib>
#include <fstream>
#include <ctype.h>

int main(int argc, char *argv[])
{
    using namespace std;

    if(argc != 4)
    {
        cerr << "Usage: " << argv[0] << " input file outputfile" << endl;
        exit(1);
    }

    ifstream input_file(argv[1]);
    ofstream output_file(argv[2]);

    if(!input_file)
    {
        cerr << "Cannot open input file " << argv[1] << endl;
        exit(1);
    }

    if(!output_file)
    {
        cerr << "Cannot open output file " << argv[2] << endl;
        exit(1);
    }

    char ch;
    int shift;
    shift = stoi(argv[3]);
    while(input_file.get(ch))
    {
        if(isalpha(ch)) 
        {
            if(islower(ch)) 
                ch = (((ch - 'a') + shift) % 26) + 'a';

            else
                ch = (((ch - 'A') + shift) % 26) + 'A';  
        }
        output_file << ch; 
    }

    input_file.close();
    output_file.close();

    return 0;
}