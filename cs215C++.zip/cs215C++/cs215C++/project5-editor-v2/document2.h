// File: document2.h
// This file defines the Document class and declares its functions
// and data attributes
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 5             Date assigned: Wed, Oct 30
// Programmer: Karim Soufan          Date completed: Thu, Nov 14

#ifndef DOCUMENT_H_
#define DOCUMENT_H_

#include <iostream> // streams

// class: Document
class Document
{
    private:
        typedef std::string T; // set parameter T for Node struct
        #include "dnode.h"  // doubly-linked Node struct definition

    public:
        // default constructor
        Document();

        // explicit destructor
        Document(std::istream &in); // REC'D/P'BACK: input stream

        // Function: load
        // loads the contents of the document
        void load(std::istream& in); // REC'D/P'BACK

        // Function: empty
        // returns true if the document is empty
        bool empty() const;

        // function: insert
        // inserts a line in front of the current line
        void insert(const std::string &new_line); // REC'D

        // Function: append
        // appends a line at the end of the current line
        void append(const std::string &new_line); // REC'D

        // Function: replace
        // replaces the conent of the document
        void replace(const std::string &new_line); // REC'D

        // Function: erase
        // removes the current line in the document
        void erase();

        // Function: find
        // finds the first line in a document
        // containing the target string
        bool find(const std::string &target); // REC'D

        // Function: set_current
        // sets the index of the current line
        void set_current(int n); // REC'D

        // Function: move_current
        // moves the current line index
        void move_current(int n); // REC'D

        // Function: write_line
        // writes the current line to an output stream
        void write_line(std::ostream& out) const; // REC'D/P'BACK

        // Function: write_all
        // prints out the document
        void write_all(std::ostream& out) const;
                                        // REC'D/P'BACK 

        // Copy connstructor
        // creates a new Document that is identical to
        // the original one
        Document(const Document &source); // REC'D: original
                                          // object

        // destructor
        ~Document();

        // Function: operator=
        // makes an existing Document object identical to
        // the source Document object
        // returns a reference to itself
        Document& operator=(const Document &source); // REC'D:
                                                     // original
                                                     // object

    private:
        // Attributes definitions
        Node* headPtr;
        Node* currentPtr;

};
// end of Document

#endif // DOCUMENT_H_