// File: document2.cpp
// This file tests the Document class functions
//
// ------------------------------------------------------------------
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Assignment: Project 5             Date assigned: Wed, Oct 30
// Programmer: Karim Soufan          Date completed: Thu, Nov 14

#include <iostream>
#include <list>
#include <string>
#include <stdexcept>
#include <algorithm> // swap, cpy
#include <cmath>
#include "document2.h"

using namespace std;

// default constructor
Document::Document()
{
    // making the node point to itself
    headPtr = new Node;
    headPtr->llink = headPtr;
    headPtr->rlink = headPtr;
    currentPtr = headPtr;
}
// end of default constructor

// explicit constructor
Document::Document(istream &in) // REC'D:P'BACK
{
    headPtr = new Node;
    headPtr->llink = headPtr;
    headPtr->rlink = headPtr;
    currentPtr = headPtr;
    
    string line;
    Node* temp1 = headPtr;
    Node* temp2;
   
    while(getline(in, line))
    {
        temp2 = new Node;
        temp2->data = line;
        temp2->llink = temp1;
        temp1->rlink = temp2;
        temp2->rlink = headPtr; 
        temp1 = temp1->rlink;
    }
    headPtr->llink = temp2;
    currentPtr = headPtr->rlink;
}
// end of explicit constructor

// Function: load
void Document::load(std::istream& in) // REC'D:P'BACK
{
    // deleting previous data
    Node* temp = headPtr->rlink;
    while(temp != headPtr)
    {
        Node* temp1 = temp->rlink;
        delete temp;
        temp = temp1;
    }

    string line;
    Node* temp2;
    for(currentPtr = headPtr; getline(in, line);
                            currentPtr = currentPtr->rlink)
    {
        temp2 = new Node;
        temp2->data = line;
        temp2->llink = currentPtr;
        currentPtr->rlink = temp2;
        temp2->rlink = headPtr;  
    }
    headPtr->llink = temp2;
    currentPtr = headPtr->rlink;
}
// end of load

// Function: empty
bool Document::empty() const
{
    return (headPtr->rlink == headPtr);
}

// Function: insert
void Document::insert(const string &new_line)
{
    Node* inserted = new Node;

    inserted->data = new_line;

    // hooking up the links of the inserted node
    // to the current node
    inserted->llink = currentPtr->llink;
    inserted->rlink = currentPtr;

    // hooking up the links of the current node
    // to the inserted node
    currentPtr->llink->rlink = inserted;
    currentPtr->llink = inserted;
    currentPtr = inserted;
}
// end of insert

// Function: append
void Document::append(const string &new_line)
{
    Node* appended = new Node;

    appended->data = new_line;

    appended->llink = headPtr->llink;
    appended->rlink = headPtr;

    headPtr->llink->rlink = appended;
    headPtr->llink = appended;

    currentPtr = appended;
}
// end of append

// Function: replace
void Document::replace(const string &new_line)
{
    if(empty())
        throw out_of_range("This document is empty (replace)");

    currentPtr->data = new_line;
}
// end of replace

// Function: erase
void Document::erase()
{
    // error checking for empty document
    if(empty())
        throw out_of_range("This document is empty! (erase)");

    Node* temp = currentPtr;
    if(currentPtr->rlink == headPtr)
        currentPtr = currentPtr->llink;
    else
        currentPtr = currentPtr->rlink;
    
    temp->llink->rlink = temp->rlink;
    temp->rlink->llink = temp->llink;
    
    delete temp;
}
// end of erase

// Function: find
bool Document::find(const string &target)
{
    size_t found;
    Node* temp = headPtr->rlink;
    while(temp != headPtr)
    {
        // searching for the target string in each line
        found = temp->data.find(target);
        // if it was found
        if(found != string::npos)
        {
            // set the index to where it was found
            currentPtr = temp;
            return true;
        }
        temp = temp->rlink;
    }
    // if it wasn't found, return false
    return false;
}
// end of find

// Function: set_current
void Document::set_current(int n)
{
    // error checking for empty document
    if(empty())
        throw out_of_range("The document is empty! (set_current)");

    // if it is a negative number
    if(n < 0)
        throw out_of_range("The index is negative"
        " (set_current)");


    Node* temp = headPtr->rlink;
    int counter = 0;
    while (temp != headPtr)
    {
        if(counter == n)
        {
            currentPtr = temp;
            temp = nullptr;
            return;
        }
        else
        {
            counter++;
            temp = temp->rlink;
        }   
    }
    
    // if it is bigger than
    // the number of lines in the document
    throw out_of_range("The index is out of range"
    " (set_current)");
}
// end of set_current

// Function: move_current
void Document::move_current(int n)
{
    // error checking for empty document
    if(empty())
        throw out_of_range("The document is empty! (move_current)");

    Node* temp = currentPtr;
    int counter = 0;
    while(temp != headPtr)
    {
        if(n > 0)
        {
            if(counter == n)
            {
                currentPtr = temp;
                return;
            }

            else
            {
                counter++;
                temp = temp->rlink;
            }
        }
        else if(n < 0)
        {
            if(counter == n)
            {
                currentPtr = temp;
                return;
            }
            else
            {
                counter--;
                temp = temp->llink;
            }
        }
        else
            return;
    }
    throw out_of_range("The number of lines moved is bigger"
        " than the number of lines (move_current)");
}
// end of move_current

void Document::write_line(ostream& out) const
{
    if(!empty())
        out << currentPtr->data << endl;
}

// Function: write_all
void Document::write_all(ostream& out) const
{
    Node* temp = headPtr->rlink;
    // printing the content of the document
    while (temp != headPtr)
    {
        out << temp->data << endl;
        temp = temp->rlink;
    }
}
// end of write_all

// Copy constructor
Document::Document(const Document &source)
{
    this->headPtr = new Node;
    this->headPtr->llink = this->headPtr;
    this->headPtr->rlink = this->headPtr;
    this->currentPtr = this->headPtr;
    
    Node* temp1 = this->headPtr;
    Node* temp2;
    Node* temp3 = source.headPtr->rlink;
   
    while(temp3 != source.headPtr)
    {
        temp2 = new Node;
        temp2->data = temp3->data;
        temp2->llink = temp1;
        temp1->rlink = temp2;
        temp2->rlink = this->headPtr; 
        if(source.currentPtr == temp3)
            this->currentPtr = temp2;
        temp1 = temp1->rlink;
        temp3 = temp3->rlink;
    }
    headPtr->llink = temp2;
}
// end of Copy constructor

// Destructor
Document::~Document()
{
    Node* temp = headPtr->rlink;
    while(temp != headPtr)
    {
        Node* temp2 = temp->rlink;
        delete temp;
        temp = temp2;
    }
    delete headPtr;
}
// end of Destructor

// Function: operator=
Document& Document::operator=(const Document &source)
{   
    Document cpy(source);

    swap(this->headPtr, cpy.headPtr);
    swap(this->currentPtr, cpy.currentPtr);
    
    return *this;
}
// end of operator=

