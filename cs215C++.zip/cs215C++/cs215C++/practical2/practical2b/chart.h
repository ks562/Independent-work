// File: chart.h
// Skeleton class that models rectangular seating charts using 
// dynamic one-dimensional array of booleans.  
//    - logical seats[i][j] maps to seat_array[i*num_seats+j]
//    - logical seats[i][j] == false means seat is unassigned
//    - logical seats[i][j] == true means seat is assigned
//
// Row numbers are 0 ... num_rows-1
// Seat numbers are 0 ... num_seats-1
// ----------------------------------------------------------------------
// Class: CS 215
// Date: November 5 & 6, 2019
// Assignment: Programming Practical Exam 2, Problem 2
// Programmer: Karim Soufan

#ifndef _CHART_H_
#define _CHART_H_

#include <iostream>

class SeatingChart
{
  public:  // No default constructor on purpose
   SeatingChart (int init_rows, int init_seats);


   void assign (int row, int seat_num);
   void unassign (int row, int seat_num);
   void write (std::ostream & out) const;
   bool is_assigned(int row, int col);
   ~SeatingChart();
   SeatingChart(const SeatingChart &source);
   SeatingChart& operator=(const SeatingChart &source);


  private:
   int num_rows,     // number of rows
      num_seats;     // number seats in each row
   bool* seat_array;




   // helper functions that convert 2D coordinates to array index
   bool & at (int row, int col);
   const bool & at (int row, int col) const;
};

#endif
