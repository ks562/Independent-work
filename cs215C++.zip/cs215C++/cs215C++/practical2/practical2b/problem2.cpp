// File: problem2.cpp
// Program to test SeatingChart class
//
// ----------------------------------------------------------------------
// Class: CS 215
// Date: November 5 & 6, 2019
// Assignment: Programming Practical Exam 2, Problem 2
// Programmer: Karim Soufan

#include <iostream>
#include "chart.h"

int main ()
{
   using namespace std;

   SeatingChart chart1(10, 4);


   int row, seat;
   char command;

   cout << "Chart 1: (10x4)" << endl;
   chart1.write(cout);
   
   cout << "\nDo you want to check assignment (c), assign (a), unassigned (u),"
	<< " or quit (q): ";
   cin >> command;
   command = tolower(command);
   
   // Apply commands on chart1
   while (command != 'q')
   {
      cout << "Enter a row number and a seat number: ";
      cin >> row >> seat;

      if (command == 'a') {
	 cout << "Assigning this seat" << endl;

    try
    {
      chart1.assign(row, seat);
    }
    catch(const std::out_of_range& e)
    {
      cerr << e.what() << endl;
      cerr << "This seat cannot be assigned" << endl;
    }
    
	 
      } else if (command == 'u') {
	 cout << "Unassigning this seat" << endl;

    try
    {
      chart1.unassign(row, seat);
    }
    catch(const std::out_of_range& e)
    {
      cerr << e.what() << endl;
      cerr << "This seat cannot be unassigned" << endl;
    }
    
	 
      } 

      else if(command == 'c')
      {
         cout << "Checking assignment..." << endl;

         try
         {
            chart1.is_assigned(row, seat);
         }
         catch(const std::out_of_range& e)
         {
            cerr << e.what() << '\n';
            cerr << "Cannot know wether the seat is assigned or not" << endl;
         }
         
         if(chart1.is_assigned(row, seat))
            cout << "It is assigned!" << endl;
         else
            cout << "It is NOT assigned!" << endl;
         
      }
      
      else {
	 cout << "Unknown command.  Try again." << endl;
      }

      cout << "Chart 1: (10x4)" << endl;
      chart1.write(cout);
      
      cout << "\nDo you want to check assignment (c), assign (a), "
	<< "unassigned (u), or quit (q): ";
      cin >> command;
      command = tolower(command);
   }

   return 0;
}  // end main
