// File: chart.cpp
// Skeleton class that models rectangular seating charts using 
// dynamic one-dimensional array of booleans.  
//    - logical seats[i][j] maps to seat_array[i*num_seats+j]
//    - logical seats[i][j] == false means seat is unassigned
//    - logical seats[i][j] == true means seat is assigned
//
// Row numbers are 0 ... num_rows-1
// Seat numbers are 0 ... num_seats-1
// ----------------------------------------------------------------------
// Class: CS 215
// Date: November 5 & 6, 2019
// Assignment: Programming Practical Exam 2, Problem 2
// Programmer: Karim Soufan

#include <iostream>
#include <stdexcept>
#include <algorithm>
#include "chart.h"

using namespace std;

// Explict-value constructor
// Creates dynamic 2D "array" of seats
SeatingChart::SeatingChart (int init_rows, int init_seats)
{

   num_rows = init_rows;
   num_seats = init_seats;
   seat_array = new bool [init_rows * init_seats];

}  // end explicit-value constructor



// Function: assign
// assigns seat numbered seatNum in row numbered row
void SeatingChart::assign (int row, int seatNum)
{
   if(row < 0 || seatNum < 0 || row > num_rows || seatNum > num_seats)
      throw out_of_range("The row or col entered is invalid! (assign)");
      
   at (row, seatNum) = true;
}  // end assign


// Function: unassign
// unassigns seat numbered seat_num in row numbered row
void SeatingChart::unassign (int row, int seatNum)
{
   if(row < 0 || seatNum < 0 || row > num_rows || seatNum > num_seats)
      throw out_of_range("The row or col entered is invalid! (unassign)");

   at (row, seatNum) = false;
}  // end unassign

// Function: write
// Prints out X if the seat is assigned, 0 if seat is not assigned
void SeatingChart::write (std::ostream & out) const
{
   for (int i = 0; i < num_rows; i++)
   {
      for (int j = 0; j < num_seats; j++)
         if (at (i,j))  // array values are bool
            out << " X";
         else
            out << " O";
      out << std::endl;
   }  // end for each row
}  // end write

// Function: at (const and non-const versions)
// Helper function that convert 2D coordinates to array index
bool & SeatingChart::at (int row, int col)
{
   return seat_array[row*num_seats+col];
}

const bool & SeatingChart::at (int row, int col) const
{
   return seat_array[row*num_seats+col];
}

bool SeatingChart::is_assigned(int row, int col)
{
   if(row < 0 || col < 0 || row > num_rows || col > num_seats)
      throw out_of_range("The row or col entered is invalid! (is_assigned)");

   if(at(row, col))
      return true;
   else
      return false;
}

SeatingChart::~SeatingChart()
{
   delete [] seat_array;
}

SeatingChart::SeatingChart(const SeatingChart &source)
{
   this->num_rows = source.num_rows;
   this->num_seats = source.num_seats;

   seat_array = new bool [num_rows * num_seats];
   for(int i = 0; i < num_rows * num_seats; i++)
      seat_array[i] = source.seat_array[i];
   
}

SeatingChart& SeatingChart::operator=(const SeatingChart &source)
{
   SeatingChart cpy(source);
   
   swap(this->num_rows, cpy.num_rows);
   swap(this->num_seats, cpy.num_seats);
   swap(this->seat_array, cpy.seat_array);

   return *this;
}
