// File: problem1.cpp
// A program that tests exchange_sort
//
// Class: CS 215                     Instructor: Dr. Deborah Hwang
// Date: November 5 & 6, 2019
// Assignment: Practical Exam 2, Problem 1
// Programmer: Karim Soufan

#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>


void read_vector (std::vector<int> & v, std::istream & in);
void write_vector(const std::vector<int> &v, std::ostream &out);
int vector_average(const std::vector<int> & v);
std::vector<int>& exchange_sort(std::vector<int> & v);

int main (int argc, char *argv[])
{
   using namespace std;

   if(argc != 3)
   {
      cerr << "Usage: " << argv[0] << "inputfile outputfile" << endl;
      exit(1);
   }

   ifstream infile(argv[1]);
   ofstream outfile(argv[2]);

   if(!infile)
   {
      cerr << "Cannot open input file " << argv[1] << endl;
      exit(1);
   }

   if(!outfile)
   {
      cerr << "Cannot open output file " << argv[2] << endl;
      exit(1);
   }

   vector<int> the_vector;
   
   // Read in data from file
   read_vector (the_vector, infile);

   cout << "The elements of vector v are: " << endl;
// *** WRITE CALL TO DISPLAY the_vector ON SCREEN HERE ***
write_vector(the_vector, cout);


// The displaying the average of the vector
cout << "The average is: " << vector_average(the_vector) << endl;


   // Sort the data
// *** WRITE CALL TO SORT the_vector HERE ***
the_vector = exchange_sort(the_vector);


   outfile << "\nAfter sorting, the elements of vector v are: " << endl;
// *** WRITE CALL TO WRITE the_vector TO OUTPUT FILE HERE ***
write_vector(the_vector, outfile);


   infile.close();
   outfile.close();

   return 0;
}

void read_vector (std::vector<int> & v, std::istream & in)
{
   int value;
   v.clear();
   while (in >> value)
      v.push_back(value);
}

void write_vector(const std::vector<int> &v, std::ostream &out)
{
   for(int i = 0; i < v.size(); i++)
      out << v[i] << std::endl;
}

int vector_average(const std::vector<int> & v)
{
   int average = 0;
   for(int i = 0; i < v.size(); i++)
      average += v[i];

   return average/v.size();
}

std::vector<int>& exchange_sort(std::vector<int> & v)
{
   int temp = 0;

   for(int i = v.size() - 2; i >= 0; i--)
   {
      for(int j = v.size() - 1; j >= i + 1; j--)
      {
         if(v[i] > v[j])
         {
            temp = v[i];
            v[i] = v[j];
            v[j] = temp;
         }
      }
   }
   return v;
}
