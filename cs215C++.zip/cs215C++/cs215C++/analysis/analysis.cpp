// Lecture 24 - Analysis of Algorithms, Ch. 2

// Function: search
// Searches array x of n elements for target.  
// Returns index of target or -1 if not found
int search(const int x[], int n, int target)  // REC'D
{
   for (int i=0; i < n; i++)            // Line 1
   {      
      if (x[i] == target)               // Line 2
	 return i;                      // Line 3
   }
   return -1;                           // Line 4
}  // end search

// Function: are_different
// Determines whether two arrays of n and m elements, respectively,
// have no common elements
// Returns true if there are no common elements, false otherwise
bool are_different(const int x[], int n, const int y[], int m)  // REC'D
{
   for (int i=0; i < n; i++)                 // Line 1
   {
      if (search(y, m, x[i]) != -1)          // Line 2
	  return false;                      // Line 3
   }
   return true;                              // Line 4
}  // end are_different

// Function: are_unique
// Determines whether the n elements of array x are all unique
// Returns true all elements of x are unique, false otherwise
bool are_unique (const int x[], int n)  // REC'D
{
   for (int i = 0; i < n; i++)               // Line 1
   {
      for (int j = 0; j < n; j++)            // Line 2
      {
	 if (x[i] == x[j])                   // Line 3
	    return false;                    // Line 4
      }
   }
   return true;                              // Line 5
}


/*
Chart on p. 38 of textbook gives some idea of how f(n) functions
compare.  Assuming 1sec. to process 1000 elements. 
(log_2 means log base 2)

              Number of elements
   Big-0      1000   5000     10000    50000    100000   500000
   ------------------------------------------------------------
   O(1)       1sec.  1sec.    1sec.    1sec.    1sec.    1sec.
   O(log_2n)  1sec.  1.2sec.  1.3sec.  1.6sec.  1.7sec.  1.9sec.
   O(n)       1sec.  5sec.    10sec.   1min.    2min.    10min.
   O(n^2)     1sec.  .5min.   2min.    1hr.     4hr.     4days
   O(2^n)     1sec.           more than 2 x 10^1000 years
*/
