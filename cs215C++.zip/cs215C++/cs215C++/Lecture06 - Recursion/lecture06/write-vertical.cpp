// File: write-vertical.cpp
// Inclass exercise for 9/4/2019

#include <iostream>

// Function prototype goes here
void write_vertical(int n);

int main()
{
   using namespace std;

   int n;

   cout << "Enter a positive integer: ";
   cin >> n;

   write_vertical(n);

   return 0;
}

// Function definition goes here
void write_vertical(int n)
{
   using namespace std;

   // Base case - what is an obvious solution
   if(n < 10)  // single digit
      cout << n << endl;

   // Identify the smaller version - n/10
   // How is it used to solve the original problem?
   else
   {
      write_vertical(n/10);   // write all but the last digit

      cout << n % 10 << endl; // write the last digit
   }
   
}