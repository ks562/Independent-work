#include "priority-queue.h"
#include <iostream>
#include <iomanip>
#include <queue>  // priority_queue<T>, too
#include <functional>
#include <vector>
#include <utility>
#include <cstdlib>
#include <cassert>
#include <string>

// free function template to print out pairs
template <typename T, typename U>
std::ostream& operator << (std::ostream& out, const std::pair<T, U>& p)
{
    return out << "[" << p.first << "," << p.second << "]";
}

template <typename PQ>
void print_and_clear_queue(PQ& pq)
{
    std::cout << pq.size() << "/" << pq.empty() << ":  ";
    while (! pq.empty()) {
        std::cout << pq.top() << " ";
        pq.pop();
    }
    std::cout << "=> " << pq.size() << "/" << pq.empty() << std::endl;
}

int main()
{
   std::cout << std::boolalpha;
   {
      std::priority_queue<int> pq;
      Priority_Queue<int> PQ;
      pq.push(3); pq.push(5); pq.push(7);
      pq.push(2); pq.push(4); pq.push(8); pq.push(1);
      PQ.push(3); PQ.push(5); PQ.push(7);
      PQ.push(2); PQ.push(4); PQ.push(8); PQ.push(1);
      print_and_clear_queue(pq);
      print_and_clear_queue(PQ);
   }
   std::cout << "--------------------" << std::endl;
   {
      std::priority_queue<int, std::vector<int>, std::greater<int> > pq;
      Priority_Queue<int, std::greater<int> > PQ;
      pq.push(3); pq.push(5); pq.push(7);
      pq.push(2); pq.push(4); pq.push(8); pq.push(1);
      PQ.push(3); PQ.push(5); PQ.push(7);
      PQ.push(2); PQ.push(4); PQ.push(8); PQ.push(1);
      print_and_clear_queue(pq);
      print_and_clear_queue(PQ);
   }
   std::cout << "--------------------" << std::endl;
   {
      std::priority_queue<std::pair<std::string,int> > pq;
      Priority_Queue<std::pair<std::string,int> > PQ;
      pq.push(std::make_pair("one",1)); pq.push(std::make_pair("two",2));
      pq.push(std::make_pair("three",3)); pq.push(std::make_pair("four",4));
      pq.push(std::make_pair("five",5)); pq.push(std::make_pair("six",6));
      PQ.push(std::make_pair("one",1)); PQ.push(std::make_pair("two",2));
      PQ.push(std::make_pair("three",3)); PQ.push(std::make_pair("four",4));
      PQ.push(std::make_pair("five",5)); PQ.push(std::make_pair("six",6));
      print_and_clear_queue(pq);
      print_and_clear_queue(PQ);
   }
   std::cout << "--------------------" << std::endl;
   {
      std::priority_queue<std::pair<std::string,int>,
			  std::vector<std::pair<std::string,int> >,
			  std::greater<std::pair<std::string, int> > > pq;
      Priority_Queue<std::pair<std::string,int>, std::greater<std::pair<std::string, int> > > PQ;
      pq.push(std::make_pair("one",1)); pq.push(std::make_pair("two",2));
      pq.push(std::make_pair("three",3)); pq.push(std::make_pair("four",4));
      pq.push(std::make_pair("five",5)); pq.push(std::make_pair("six",6));
      PQ.push(std::make_pair("one",1)); PQ.push(std::make_pair("two",2));
      PQ.push(std::make_pair("three",3)); PQ.push(std::make_pair("four",4));
      PQ.push(std::make_pair("five",5)); PQ.push(std::make_pair("six",6));
      print_and_clear_queue(pq);
      print_and_clear_queue(PQ);
   }
   std::cout << "--------------------" << std::endl;
   {
      std::priority_queue<int> pq;
      Priority_Queue<int> PQ;
      srand(time(0));
      for (auto i = 0; i <= 1000; i++) {
	 int x = rand();
	 pq.push(x);
	 PQ.push(x);
	 assert(pq.top() == PQ.top());
      }
      while (! pq.empty()) {
	 assert(pq.top() == PQ.top());
	 pq.pop(); PQ.pop();
      }
   }
}
