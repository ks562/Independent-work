// File: priority-queue.h
// From Wittenberg, Data Structures and Algorithms in C++ Pocket Primer
// Chapter 7

#ifndef PRIORITY_QUEUE_H
#define PRIORITY_QUEUE_H
    
#include <functional>
#include <vector>
#include <utility>
template <typename T, typename Compare = std::less<T> >
class Priority_Queue {
  public:
     int size() const { return data.size(); }

     bool empty() const { return data.empty(); }

     const T& top() const { return data.front(); }

     void push(const T& item)
     {
        data.push_back(item);
	percolate_up();
     }

     void pop()
     {
        data.front() = data.back();
	data.pop_back();
	percolate_down();
     }

  private:
     std::vector<T> data;
     Compare cmp;

     void percolate_up()
     {
	// new value is at the last index
	int i = size() - 1;

	// parent of new value
	int p = (i - 1) / 2;

	// while not at root and parent is less than value
	while (i > 0 && cmp(data[p], data[i])) {

	   // swap parent and value
	   std::swap(data[p], data[i]);

	   // update where new value and parent are
	   i = p;
	   p = (i - 1) / 2;
	}
     }

     void percolate_down()
     {
	// value starts at the root
	int i = 0;

	// find the bigger child
	int child = max_child(i);

	// while not at the bottom and still out of order
	while (child < size() && cmp(data[i], data[child])) {

	   // swap with value with child
	   std::swap(data[child], data[i]);

	   // update where this value and max child are
	   i = child;
	   child = max_child(i);
	}
     }
  
     int max_child(int p)
     {
	// compute left child index
	int result = 2 * p + 1;

	// if there is a right child, see if it is bigger
	if (result + 1 < size()
	    && cmp(data[result], data[result + 1]))
	{
	   ++result;
	}

	// return max child index
	return result;
     }
};

#endif

