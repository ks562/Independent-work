﻿using System.Windows;
using System.Windows.Controls;

namespace HexLife
{
    public partial class AboutWindow : Window
    {
        private Button aboutBttn;
        public AboutWindow(Button aboutBttn)
        {
            InitializeComponent();
            this.aboutBttn = aboutBttn;
            Closing += (sender, e) =>
            {
                aboutBttn.IsEnabled = true;
            };
        }
    }
}
