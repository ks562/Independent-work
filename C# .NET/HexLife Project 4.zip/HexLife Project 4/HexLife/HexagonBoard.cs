﻿using System.Windows;
using System.Windows.Media;

namespace HexLife
{
    class HexagonBoard
    {
        const int ROW = Constants.ROW;
        const int COL = Constants.COL;
        private readonly Hexagon[,] grid = new Hexagon[ROW, COL];

        public HexagonBoard()
        {
            CreateGrid();
        }

        private void CreateGrid()
        {
            double xOffsetOdd = 1.5 * Constants.hexagonRadius, yOffsetOdd = 0;
            double xOffsetEven = 0, yOffsetEven = Constants.rSin60;
            for (int row = 0; row < ROW; row++)
            {
                for (int col = 0; col < COL; col++)
                {
                    if (col % 2 == 0)
                    {
                        grid[row, col] = new Hexagon(xOffsetEven, yOffsetEven, row, col);
                        xOffsetEven += 3 * Constants.hexagonRadius;
                    }
                    if (col % 2 == 1)
                    {
                        grid[row, col] = new Hexagon(xOffsetOdd, yOffsetOdd, row, col);
                        xOffsetOdd += 3 * Constants.hexagonRadius;
                    }
                }
                yOffsetEven += Constants.rSin60 * 2;
                yOffsetOdd += Constants.rSin60 * 2;

                xOffsetEven = 0;
                xOffsetOdd = 1.5 * Constants.hexagonRadius;
            }
        }

        public void Draw(DrawingContext dc)
        {
            for (int row = 0; row < ROW; row++)
            {
                for (int col = 0; col < COL; col++)
                {
                    grid[row, col].Draw(dc);
                }
            }
        }

        public Hexagon GetHexagonFrom(Point clickPoint)
        {
            for (int row = 0; row < ROW; row++)
            {
                for (int col = 0; col < COL; col++)
                {
                    if (grid[row, col].Contains(clickPoint))
                    {
                        return grid[row, col];
                    }
                }
            }
            return null;
        }

        public HexagonBoard GetNextGenerationL1()
        {
            for (int row = 0; row < ROW; row++)
            {
                for (int col = 0; col < COL; col++)
                {
                    grid[row, col].Sum = GetL1NeighborsSum(row, col);
                }
            }
            return GetHexBoardL1Rules();
        }

        public HexagonBoard GetNextGenerationL2()
        {
            for (int row = 0; row < ROW; row++)
            {
                for (int col = 0; col < COL; col++)
                {
                    double sumL1 = GetL1NeighborsSum(row, col), sumL2 = GetL2NeighborsSum(row, col);
                    grid[row, col].Sum = sumL1 + 0.3 * sumL2;
                }
            }
            return GetHexBoardL2Rules();
        }

        private double GetL1NeighborsSum(int row, int col)
        {
            double sumL1 = 0;
            // Even neighbors
            if (col % 2 == 0)
            {
                if (Exist(row - 1, col))
                {
                    if (grid[row - 1, col].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row, col + 1))
                {
                    if (grid[row, col + 1].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row + 1, col + 1))
                {
                    if (grid[row + 1, col + 1].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row + 1, col))
                {
                    if (grid[row + 1, col].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row + 1, col - 1))
                {
                    if (grid[row + 1, col - 1].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row, col - 1))
                {
                    if (grid[row, col - 1].IsAlive)
                    {
                        sumL1++;
                    }
                }
            }
            else // Odd neighbors
            {
                if (Exist(row - 1, col))
                {
                    if (grid[row - 1, col].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row - 1, col + 1))
                {
                    if (grid[row - 1, col + 1].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row, col + 1))
                {
                    if (grid[row, col + 1].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row + 1, col))
                {
                    if (grid[row + 1, col].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row, col - 1))
                {
                    if (grid[row, col - 1].IsAlive)
                    {
                        sumL1++;
                    }
                }
                if (Exist(row - 1, col - 1))
                {
                    if (grid[row - 1, col - 1].IsAlive)
                    {
                        sumL1++;
                    }
                }
            }
            return sumL1;
        }

        private double GetL2NeighborsSum(int row, int col)
        {
            double sumL2 = 0;
            if (Exist(row - 2, col))
            {
                if (grid[row - 2, col].IsAlive)
                {
                    sumL2++;
                }
            }
            if (Exist(row - 1, col + 2))
            {
                if (grid[row - 1, col + 2].IsAlive)
                {
                    sumL2++;
                }
            }
            if (Exist(row + 1, col + 2))
            {
                if (grid[row + 1, col + 2].IsAlive)
                {
                    sumL2++;
                }
            }
            if (Exist(row + 2, col))
            {
                if (grid[row + 2, col].IsAlive)
                {
                    sumL2++;
                }
            }
            if (Exist(row + 1, col - 2))
            {
                if (grid[row + 1, col - 2].IsAlive)
                {
                    sumL2++;
                }
            }
            if (Exist(row - 1, col - 2))
            {
                if (grid[row - 1, col - 2].IsAlive)
                {
                    sumL2++;
                }
            }
            return sumL2;
        }

        private HexagonBoard GetHexBoardL1Rules()
        {
            HexagonBoard nextGenBoard = new HexagonBoard();
            for (int row = 0; row < ROW; row++)
            {
                for (int col = 0; col < COL; col++)
                {
                    if (grid[row, col].Sum == 2)
                        nextGenBoard.At(row, col).IsAlive = true;
                    else
                        nextGenBoard.At(row, col).IsAlive = false;
                }
            }
            return nextGenBoard;
        }

        private HexagonBoard GetHexBoardL2Rules()
        {
            HexagonBoard nextGenBoard = new HexagonBoard();
            for (int row = 0; row < ROW; row++)
            {
                for (int col = 0; col < COL; col++)
                {
                    if (grid[row, col].IsAlive)
                    {
                        if (2.0 <= grid[row, col].Sum && grid[row, col].Sum <= 3.3)
                        {
                            nextGenBoard.At(row, col).IsAlive = true;
                        }
                        else
                        {
                            nextGenBoard.At(row, col).IsAlive = false;
                        }
                    }
                    else
                    {
                        if (2.3 <= grid[row, col].Sum && grid[row, col].Sum <= 2.9)
                        {
                            nextGenBoard.At(row, col).IsAlive = true;
                        }
                        else
                        {
                            nextGenBoard.At(row, col).IsAlive = false;
                        }
                    }
                }
            }
            return nextGenBoard;
        }

        private bool Exist(int row, int col)
        {
            return row >= 0 && row < ROW && col >= 0 && col < COL;
        }

        public Hexagon At(int row, int col)
        {
            return grid[row, col];
        }
    }
}
