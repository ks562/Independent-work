﻿using Microsoft.Win32;
using System.ComponentModel;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace HexLife
{
    public partial class MainWindow : Window
    {
        private HelpWindow helpWindow;
        private AboutWindow aboutWindow;

        private HexagonBoard currentLifeBoard = new HexagonBoard();
        private HexagonBoard nextLifeBoard = new HexagonBoard();
        private BackgroundWorker worker = new BackgroundWorker();
        private delegate void SetImageSourceCallBack(ImageSource src);
        private delegate void SetLabelCallBack(string text);
        private delegate void EnableStartButtonCallBack(bool value);
        private int latency = 500;


        public MainWindow()
        {
            InitializeComponent();
            speedComboBox.SelectionChanged += (sender, e) =>
            {
                var speedItemListBox = (System.Windows.Controls.ListBoxItem)speedComboBox.SelectedItem;
                latency = int.Parse(speedItemListBox.Content.ToString());
            };
            worker.DoWork += new DoWorkEventHandler(StartLife);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(WorkCompleted);
            worker.ProgressChanged += new ProgressChangedEventHandler(Progress);

            worker.WorkerReportsProgress = true;
            DrawGrid();
        }

        private void DrawGrid()
        {
            //Create a "visual" to draw on.
            DrawingVisual vis = new DrawingVisual();
            //Create a drawing context for this visual
            var dc = vis.RenderOpen();

            currentLifeBoard.Draw(dc);

            dc.Close();

            var bmp = new RenderTargetBitmap((int)Constants.imageWidth, (int)Constants.imageHeight, 96, 96, PixelFormats.Pbgra32);

            //Render the visual to the bitmap
            bmp.Render(vis);
            //Make the image source the bitmap
            image.Source = bmp;
        }

        private void image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point clickPoint = e.GetPosition(image);
            Hexagon clickedHexagon = currentLifeBoard.GetHexagonFrom(clickPoint);
            if (clickedHexagon != null)
            {
                clickedHexagon.ToggleLife();
                DrawingVisual vis = new DrawingVisual();
                var dc = vis.RenderOpen();
                currentLifeBoard.Draw(dc);
                dc.Close();
                var bitmap = new RenderTargetBitmap((int)Constants.imageWidth, (int)Constants.imageHeight, 96, 96, PixelFormats.Pbgra32);

                bitmap.Render(vis);

                image.Source = bitmap;
            }
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            DrawNextGeneration(L1RadioBttn.IsChecked.Value);
        }

        private void DrawNextGeneration(bool isL1Rule)
        {
            if (isL1Rule)
                nextLifeBoard = currentLifeBoard.GetNextGenerationL1();
            else
                nextLifeBoard = currentLifeBoard.GetNextGenerationL2();

            DrawingVisual vis = new DrawingVisual();
            var dc = vis.RenderOpen();

            nextLifeBoard.Draw(dc);
            dc.Close();

            var bitmap = new RenderTargetBitmap((int)Constants.imageWidth, (int)Constants.imageHeight, 96, 96, PixelFormats.Pbgra32);

            bitmap.Render(vis);
            bitmap.Freeze();
            SetImageSourceSafely(bitmap);

            currentLifeBoard = nextLifeBoard;
        }

        private class ThreadArguments
        {
            public int Generations { get; set; }
            public bool IsL1Rule { get; set; }
        }

        private void startBttn_Click(object sender, RoutedEventArgs e)
        {
            int.TryParse(numberOfGenerationsTextBox.Text, out int generations);
            var args = new ThreadArguments { Generations = generations, IsL1Rule = L1RadioBttn.IsChecked.Value };
            numberOfGenerationsTextBox.IsEnabled = false;
            nextBttn.IsEnabled = false;
            worker.RunWorkerAsync(args);
        }

        private void StartLife(object sender, DoWorkEventArgs e)
        {
            EnableStartButtonSafely(false); //disable
            var args = (ThreadArguments)e.Argument;
            for (int i = 0; i < args.Generations; i++)
            {
                DrawNextGeneration(args.IsL1Rule);
                SetLabelSafely((i + 1).ToString());
                worker.ReportProgress((i + 1) * 100 / args.Generations);
                Thread.Sleep(latency);
            }
        }

        private void Progress(object sender, ProgressChangedEventArgs e)
        {
            progressBar.Value = e.ProgressPercentage;
        }

        private void WorkCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            progressBar.Value = 0;
            currentIternationLabel.Content = '0';
            startBttn.IsEnabled = true;
            numberOfGenerationsTextBox.IsEnabled = true;
            nextBttn.IsEnabled = true;
        }

        private void SetImageSourceSafely(ImageSource source)
        {
            if (image.Dispatcher.CheckAccess())
                image.Source = source;
            else
                image.Dispatcher.BeginInvoke(new SetImageSourceCallBack(SetImageSourceSafely), source);
        }

        private void SetLabelSafely(string text)
        {
            if (currentIternationLabel.Dispatcher.CheckAccess())
                currentIternationLabel.Content = text;
            else
                currentIternationLabel.Dispatcher.BeginInvoke(new SetLabelCallBack(SetLabelSafely), text);
        }

        private void EnableStartButtonSafely(bool value)
        {
            if (startBttn.Dispatcher.CheckAccess())
                startBttn.IsEnabled = value;
            else
                startBttn.Dispatcher.BeginInvoke(new EnableStartButtonCallBack(EnableStartButtonSafely), value);
        }

        private void numberOfGenerationsTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (numberOfGenerationsTextBox.Text == string.Empty)
            {
                startBttn.IsEnabled = false;
                return;
            }
            int.TryParse(numberOfGenerationsTextBox.Text, out int generations);
            if (generations > 0)
            {
                startBttn.IsEnabled = true;
            }
        }

        private void saveBttn_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog
            {
                DefaultExt = ".txt",
                Filter = "All Files (*.*)|*.*"
            };

            if (dlg.ShowDialog().Value)
            {
                string filePath = dlg.FileName;
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    for (int row = 0; row < Constants.ROW; row++)
                    {
                        for (int col = 0; col < Constants.COL; col++)
                        {
                            if (currentLifeBoard.At(row, col).IsAlive)
                            {
                                fileStream.WriteByte((byte)Constants.aliveCellRep);
                            }
                            else
                            {
                                fileStream.WriteByte((byte)Constants.deadCellRep);
                            }
                        }
                        fileStream.WriteByte((byte)'\n');
                    }
                }
            }
        }

        private void loadBttn_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog
            {
                DefaultExt = ".txt",
                Filter = "All Files (*.*)|*.*"
            };

            if (dlg.ShowDialog().Value)
            {
                string selectedFileName = dlg.FileName;
                using (var fileStream = new FileStream(selectedFileName, FileMode.Open))
                {
                    for (int row = 0; row < Constants.ROW; row++)
                    {
                        for (int col = 0; col < Constants.COL; col++)
                        {
                            var cellRep = (char)fileStream.ReadByte();

                            if (cellRep == Constants.aliveCellRep)
                            {
                                currentLifeBoard.At(row, col).IsAlive = true;
                            }
                            else
                            {
                                currentLifeBoard.At(row, col).IsAlive = false;
                            }
                        }
                        fileStream.ReadByte();
                    }
                }
            }
            DrawGrid();
        }

        private void Grid_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text);
        }

        private readonly Regex regex = new Regex("^[0-9]*$");
        private bool IsTextAllowed(string text)
        {
            bool isTextNumeric = regex.IsMatch(text);
            return isTextNumeric;
        }

        private void About_Button_Click(object sender, RoutedEventArgs e)
        {
            aboutWindow = new AboutWindow(aboutBttn);
            aboutWindow.Show();
            aboutBttn.IsEnabled = false;
        }

        private void Help_Button_Click(object sender, RoutedEventArgs e)
        {
            helpWindow = new HelpWindow(helpBttn);
            helpWindow.Show();
            helpBttn.IsEnabled = false;
        }

      //  You can shade/unshade a Hexagaon by left-clicking on it's center (clicking on it's right/left side won't execute). You can also choose the number of Generations aka how many "turns" the game is going to run to by using the "Start" button, which will automatically play the game for you, you can also use the "Next" button to go through the generations as many times as you want. The current iteration label shows you at which given generations you are at. You have the option to create different patterns on how the game will play out. The L1 Neighbors option indicates that only the adjacent hexagons are taken into account when creating the patterns. The L2 Neighbors option indicates that the Level 1 Neighbors and the level 2 Neighbots are taken into account. Each is going to create a different pattern or scenario on how the game progresses. You can also control the speed/latency of the current iteration and the transition to the next generation. Finally, you can save the image representing the current iteration to your computer and you can load the same or another saved image of an iteration of your choosing. At the bottom of the window, a progress bar is installed to indicate your progress from the current iteration to the specified generation number
    }
}
