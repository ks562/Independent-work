﻿using System.Windows;
using System.Windows.Media;

namespace HexLife
{
    class Hexagon
    {
        public Point[] Points { get; }
        private readonly double radius;
        public int Row { get; }
        public int Col { get; }
        public Rect Rectangle { get; }
        public bool IsAlive { get; set; }
        public double Sum { get; set; }


        public Hexagon(double xOffset, double yOffset, int row, int col)
        {
            Row = row;
            Col = col;
            radius = Constants.hexagonRadius;
            IsAlive = false;
            Sum = 0;

            Points = new Point[7];
            Points[0] = new Point(radius + Constants.shiftInsideScreenValue + xOffset, 0 + Constants.shiftInsideScreenValue + yOffset);
            Points[1] = new Point(Constants.rCos60 + Constants.shiftInsideScreenValue + xOffset, -1 * Constants.rSin60 + Constants.shiftInsideScreenValue + yOffset);
            Points[2] = new Point(-1 * Constants.rCos60 + Constants.shiftInsideScreenValue + xOffset, -1 * Constants.rSin60 + Constants.shiftInsideScreenValue + yOffset);
            Points[3] = new Point(-1 * radius + Constants.shiftInsideScreenValue + xOffset, 0 + Constants.shiftInsideScreenValue + yOffset);
            Points[4] = new Point(-1 * Constants.rCos60 + Constants.shiftInsideScreenValue + xOffset, Constants.rSin60 + Constants.shiftInsideScreenValue + yOffset);
            Points[5] = new Point(Constants.rCos60 + Constants.shiftInsideScreenValue + xOffset, Constants.rSin60 + Constants.shiftInsideScreenValue + yOffset);
            Points[6] = new Point(Points[0].X - Constants.hexagonRadius, Points[0].Y);
            Rectangle = new Rect(Points[2].X, Points[2].Y, radius, 2 * Constants.rSin60);
        }

        public void Draw(DrawingContext drawingContext)
        {
            Pen blackPen = new Pen(Brushes.Black, 1);

            drawingContext.DrawLine(blackPen, Points[0], Points[1]);
            drawingContext.DrawLine(blackPen, Points[1], Points[2]);
            drawingContext.DrawLine(blackPen, Points[2], Points[3]);
            drawingContext.DrawLine(blackPen, Points[3], Points[4]);
            drawingContext.DrawLine(blackPen, Points[4], Points[5]);
            drawingContext.DrawLine(blackPen, Points[5], Points[0]);
            Shade(drawingContext);
        }

        private void Shade(DrawingContext drawingContext)
        {
            if (IsAlive)
            {
                drawingContext.DrawEllipse(Brushes.DarkBlue, new Pen(Brushes.DarkBlue, 1), Points[6], Constants.hexagonRadius - 5, Constants.hexagonRadius - 5);
            }
            else
            {
                drawingContext.DrawEllipse(Brushes.White, new Pen(Brushes.White, 1), Points[6], Constants.hexagonRadius - 4, Constants.hexagonRadius - 4);
            }
        }

        public void ToggleLife()
        {
            IsAlive = !IsAlive;
        }

        public bool Contains(Point point)
        {
            return Rectangle.Contains(point);
        }
    }
}
