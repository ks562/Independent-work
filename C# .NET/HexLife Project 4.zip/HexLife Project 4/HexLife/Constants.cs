﻿using System;

namespace HexLife
{
    class Constants
    {
        public const double hexagonRadius = 10;
        public static readonly double rCos60 = hexagonRadius * Math.Cos(Math.PI / 3);
        public static readonly double rSin60 = hexagonRadius * Math.Sin(Math.PI / 3);
        public const double shiftInsideScreenValue = 10;
        public const double imageHeight = 575;
        public const double imageWidth = 490;
        public const int ROW = 32, COL = 32;
        public const char aliveCellRep = '*', deadCellRep = '#';
    }
}
