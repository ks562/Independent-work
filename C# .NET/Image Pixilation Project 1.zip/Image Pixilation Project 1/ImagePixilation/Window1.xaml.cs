﻿using System.Windows;
using System.Windows.Controls;

namespace ImagePixilation
{
    public partial class Window1 : Window
    {
        private readonly Button helpBttn;
        public Window1(Button helpBttn)
        {
            InitializeComponent();
            this.helpBttn = helpBttn;
            // when the window closes, enable the help button
            Closing += (sender, e) =>
            {
                helpBttn.IsEnabled = true;
            };
        }
    }
}
