﻿using System.Windows;
using System.Windows.Controls;

namespace ImagePixilation
{

    public partial class AboutWindow : Window
    {
        private Button aboutBttn;
        public AboutWindow(Button aboutBttn)
        {
            InitializeComponent();
            this.aboutBttn = aboutBttn;
            // when the window closes, enable the help button
            Closing += (sender, e) =>
            {
                aboutBttn.IsEnabled = true;
            };
        }
    }
}
