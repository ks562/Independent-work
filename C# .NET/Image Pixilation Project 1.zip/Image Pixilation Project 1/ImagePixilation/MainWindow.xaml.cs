﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ImagePixilation
{
    public partial class MainWindow : Window
    {
        // instances of the help and about windows
        private Window1 helpWindow;
        private AboutWindow aboutWindow;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Browse_Button_Click(object sender, RoutedEventArgs e)
        {
            // opening the file dialog
            OpenFileDialog dlg = new OpenFileDialog
            {
                // sets the default to bmp and accepts all types of image files
                DefaultExt = ".bmp",
                Filter = "All Files (*.*)|*.*"
            };

            //check if the dialog has a value
            if (dlg.ShowDialog().Value)
            {
                string selectedFileName = dlg.FileName;
                FileNameLabel.Content = selectedFileName;
                // creating a new bitmap for the image
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(selectedFileName);
                bitmap.EndInit();
                ImageViewer1.Source = bitmap;
                // enables the text box
                PixelSizeTextBox.IsEnabled = true;
            }
        }

        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // checking if the text is an integer
            e.Handled = !IsTextAllowed(e.Text);

            if (!e.Handled)
                PixilateButton.IsEnabled = true;
        }

        // restricting the text to a set of specified characters
        private readonly Regex regex = new Regex("^[0-9]*$");
        private bool IsTextAllowed(string text)
        {
            // checking if the text is numeric
            bool isTextNumeric = regex.IsMatch(text);
            if (!isTextNumeric)
                return false;

            // converting to integer
            int numericText = Convert.ToInt32(PixelSizeTextBox.Text + text);
            // restricting the size form 1 to width / 2
            return (numericText >= 1 && numericText <= ((BitmapSource)ImageViewer1.Source).PixelWidth / 2);
        }

        private void PixilateButton_Click(object sender, RoutedEventArgs e)
        {
            // coverting to integer
            int pixelSize = Convert.ToInt32(PixelSizeTextBox.Text);
            BitmapSource bms = (BitmapSource)ImageViewer1.Source;
            int width = bms.PixelWidth, height = bms.PixelHeight;

            double newWidth = Math.Ceiling((double)width / pixelSize), newHeight = Math.Ceiling((double)height / pixelSize);

            WriteableBitmap originalImage = new WriteableBitmap((BitmapSource)ImageViewer1.Source);

            WriteableBitmap pixilatedImage = new WriteableBitmap(width, height,
                    originalImage.DpiX, originalImage.DpiY, PixelFormats.Bgr32, null);

            // declaring the section color and bounds
            Color color;
            int beginningX = 0;
            int endX = 0;
            int endY = 0;
            int beginningY = 0;

            for (int x = 0; x < newWidth; x++)
            {
                for (int y = 0; y < newHeight; y++)
                {
                    // setting the borders of the iamge
                    beginningX = x * pixelSize;
                    beginningY = y * pixelSize;
                    endX = Math.Min(beginningX + pixelSize, width);
                    endY = Math.Min(beginningY + pixelSize, height);
                    // getting the color section
                    color = GetAverageColorForSection(originalImage, beginningX, endX, beginningY, endY);
                    SetSectionPixels(pixilatedImage, beginningX, endX, beginningY, endY, color);
                }
            }

            ImageViewer1.Source = pixilatedImage;
            SaveButton.IsEnabled = true;
        }

        private void SetSectionPixels(WriteableBitmap pixilatedImage, int beginningX, int endX, int beginningY, int endY, Color color)
        {
            // setting the pixels for a section of the image
            for (int x = beginningX; x < endX; x++)
            {
                for (int y = beginningY; y < endY; y++)
                {
                    SetPixel(pixilatedImage, x, y, color);
                }
            }
        }

        private Color GetAverageColorForSection(WriteableBitmap originalImage, int beginningX, int endX, int beginningY, int endY)
        {
            Color averageColor, pixelColor;
            long[] totals = new long[] { 0, 0, 0 };
            for (int x = beginningX; x < endX; x++)
            {
                for (int y = beginningY; y < endY; y++)
                {
                    // getting the pixels and setting the colors to an array
                    pixelColor = GetPixel(originalImage, x, y);
                    totals[0] += pixelColor.R;
                    totals[1] += pixelColor.G;
                    totals[2] += pixelColor.B;
                }
            }
            // calculating the avrg color for of the image
            int area = (endY - beginningY) * (endX - beginningX);
            byte avgR = (byte)(totals[0] / area);
            byte avgG = (byte)(totals[1] / area);
            byte avgB = (byte)(totals[2] / area);

            averageColor = Color.FromRgb(avgR, avgG, avgB);

            return averageColor;
        }

        // Dr. Blandford's function
        public void SetPixel(WriteableBitmap wbm, int x, int y, Color c)
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            wbm.Lock();
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            wbm.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            wbm.Unlock();
        }

        // Dr. Blandford's function
        public Color GetPixel(WriteableBitmap wbm, int x, int y)
        {
            if (y > wbm.PixelHeight - 1 || x > wbm.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            IntPtr buff = wbm.BackBuffer;
            int Stride = wbm.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // creating a new file dialog
            SaveFileDialog dlg = new SaveFileDialog();
            if (dlg.ShowDialog().Value)
            {
                // getting the file path
                string filePath = dlg.FileName;
                var image = ImageViewer1.Source;
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    BitmapEncoder encoder = new PngBitmapEncoder();
                    // adding the image to the encoder
                    encoder.Frames.Add(BitmapFrame.Create((BitmapSource)image));
                    // saving the file stream
                    encoder.Save(fileStream);
                }
            }
        }

        private void About_Button_Click(object sender, RoutedEventArgs e)
        {
            // creating a new about window, displaying it, and disabling the About button
            aboutWindow = new AboutWindow(aboutBttn);
            aboutWindow.Show();
            aboutBttn.IsEnabled = false;
        }

        private void Help_Button_Click(object sender, RoutedEventArgs e)
        {
            // creating a new about window, displaying it, and disabling the About button
            helpWindow = new Window1(helpBttn);
            helpWindow.Show();
            helpBttn.IsEnabled = false;
        }
    }
}
