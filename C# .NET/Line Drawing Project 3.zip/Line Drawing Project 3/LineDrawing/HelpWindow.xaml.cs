﻿using System.Windows;
using System.Windows.Controls;

namespace LineDrawing
{
    public partial class HelpWindow : Window
    {
        private Button helpBttn;
        public HelpWindow(Button helpBttn)
        {
            InitializeComponent();
            this.helpBttn = helpBttn;
            Closing += (sender, e) =>
            {
                helpBttn.IsEnabled = true;
            };
        }
    }
}
