﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace LineDrawing
{
    public partial class MainWindow : Window
    {
        private HelpWindow helpWindow;
        private AboutWindow aboutWindow;

        private int imageHeight = 0, imageWidth = 0;

        const int blackAndWhiteSeperator = 127;
        WriteableBitmap wbm;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog
            {
                DefaultExt = ".bmp",
                Filter = "All Files (*.*)|*.*"
            };

            if (dlg.ShowDialog().Value)
            {
                string selectedFileName = dlg.FileName;
                FileNameLabel.Content = selectedFileName;
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(selectedFileName);
                bitmap.EndInit();
                imageWidth = bitmap.PixelWidth;
                imageHeight = bitmap.PixelHeight;
                originalImage.Source = bitmap;
                wbm = new WriteableBitmap((BitmapSource)originalImage.Source);
                drawLines.IsEnabled = true;
                drawBlackWhiteBttn.IsEnabled = true;
                drawGrayScaleBttn.IsEnabled = true;
                secondDerivativeRadioBttn.IsEnabled = true;
                sixthDerivativeRadioBttn.IsEnabled = true;
                tenthDerivativeRadioBttn.IsEnabled = true;
                drawSobelBttn.IsEnabled = true;
            }
        }

        private void SaveDerivativeImageBttn_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            if (dlg.ShowDialog().Value)
            {
                string filePath = dlg.FileName;
                var image = derivativeImage.Source;
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    BitmapEncoder encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create((BitmapSource)image));
                    encoder.Save(fileStream);
                }
            }
        }

        private void DrawGrayScale_Click(object sender, RoutedEventArgs e)
        {
            Color[,] grayPixels = GetGrayScaleImage(wbm);
            WriteableBitmap grayScaleWbm = GetWriteableBitmapFromPixels(grayPixels);
            derivativeImage.Source = grayScaleWbm;
            saveDerivativeImageBttn.IsEnabled = true;
        }

        private void DrawBlackAndWhite_Click(object sender, RoutedEventArgs e)
        {
            Color[,] grayPixels = GetGrayScaleImage(wbm);
            WriteableBitmap grayScaleWbm = GetWriteableBitmapFromPixels(grayPixels);
            Color[,] bwPixels = GetBlackAndWhiteImage(grayScaleWbm, grayPixels);
            WriteableBitmap blackAndWhiteWbm = GetWriteableBitmapFromPixels(bwPixels);
            derivativeImage.Source = blackAndWhiteWbm;
            saveDerivativeImageBttn.IsEnabled = true;
        }

        private void DrawLines_Click(object sender, RoutedEventArgs e)
        {
            double[,] digitalFilter = new double[0,0];
            if (secondDerivativeRadioBttn.IsChecked == true)
            {
                digitalFilter = new double[,]
                {{-0.050660591821169, -0.101321183642338, -0.050660591821169},
                {-0.101321183642338, 0.702642367284675, -0.101321183642338},
                {-0.050660591821169, -0.101321183642338, -0.050660591821169}
                };
            }
            if (sixthDerivativeRadioBttn.IsChecked == true)
            {
                digitalFilter = new double[,]
            {{ -0.0003518096, -0.0021108579, -0.0052771449, -0.0070361933, -0.0052771449, -
                0.0021108579, -0.0003518096},
                {-0.0021108579, -0.0042217159, 0.0021108579, 0.0084434319, 0.0021108579, -0.0042217159,
                -0.0021108579},
                {-0.0052771449, 0.0021108579, -0.0453834468, -0.1055428996, -0.0453834468, 0.0021108579,
                -0.0052771449},
                {-0.0070361933, 0.0084434319, -0.1055428996, 0.7082713219, -0.1055428996, 0.0084434319,
                -0.0070361933},
                {-0.0052771449, 0.0021108579, -0.0453834468, -0.1055428996, -0.0453834468, 0.0021108579,
                -0.0052771449},
                {-0.0021108579, -0.0042217159, 0.0021108579, 0.0084434319, 0.0021108579, -0.0042217159,
                -0.0021108579},
                {-0.0003518096, -0.0021108579, -0.0052771449, -0.0070361933, -0.0052771449, -
                0.0021108579, -0.0003518096}
                };
            }
            if (tenthDerivativeRadioBttn.IsChecked == true)
            {
                digitalFilter = new double[,]
                {{-0.0000079157, -0.0000791571, -0.0003562072, -0.0009498860, -0.0016623006,
                 -0.0019947608, -0.0016623006, -0.0009498860, -0.0003562072, -0.0000791571, -0.0000079157},
                {-0.0000791571, -0.0004749430, -0.0010290432, -0.0006332573, 0.0011082004,
                 0.0022164008, 0.0011082004, -0.0006332573, -0.0010290432, -0.0004749430, -0.0000791571},
                {-0.0003562072, -0.0010290432, -0.0005497026, -0.0005277144, -0.0047230447,
                 -0.0081443937, -0.0047230447, -0.0005277144, -0.0005497026, -0.0010290432, -0.0003562072},
                {-0.0009498860, -0.0006332573, -0.0005277144, -0.0042217159, 0.0014776005,
                 0.0097099467, 0.0014776005, -0.0042217159, -0.0005277144, -0.0006332573, -0.0009498860},
                {-0.0016623006, 0.0011082004, -0.0047230447, 0.0014776005, -0.0442752463,
                 -0.1064927857, -0.0442752463, 0.0014776005, -0.0047230447, 0.0011082004, -0.0016623006},
                {-0.0019947608, 0.0022164008, -0.0081443937, 0.0097099467, -0.1064927857,
                 0.7094111852, -0.1064927857, 0.0097099467, -0.0081443937, 0.0022164008, -0.0019947608},
                {-0.0016623006, 0.0011082004, -0.0047230447, 0.0014776005, -0.0442752463,
                 -0.1064927857, -0.0442752463, 0.0014776005, -0.0047230447, 0.0011082004, -0.0016623006},
                {-0.0009498860, -0.0006332573, -0.0005277144, -0.0042217159, 0.0014776005,
                 0.0097099467, 0.0014776005, -0.0042217159, -0.0005277144, -0.0006332573, -0.0009498860},
                {-0.0003562072, -0.0010290432, -0.0005497026, -0.0005277144, -0.0047230447,
                 -0.0081443937, -0.0047230447, -0.0005277144, -0.0005497026, -0.0010290432, -0.0003562072},
                {-0.0000791571, -0.0004749430, -0.0010290432, -0.0006332573, 0.0011082004,
                 0.0022164008, 0.0011082004, -0.0006332573, -0.0010290432, -0.0004749430, -0.0000791571},
                {-0.0000079157, -0.0000791571, -0.0003562072, -0.0009498860, -0.0016623006,
                 -0.0019947608, -0.0016623006, -0.0009498860, -0.0003562072, -0.0000791571, -0.0000079157},
                };
            }

            Color[,] pixels = GetImagePixels(wbm);
            Color[,] filteredPixels = GetFilteredImage(digitalFilter, pixels);
            WriteableBitmap filteredWbm = GetWriteableBitmapFromPixels(filteredPixels);
            derivativeImage.Source = filteredWbm;
            saveDerivativeImageBttn.IsEnabled = true;
        }

        private Color[,] GetFilteredImage(double[,] digitalFilter, Color[,] pixels)
        {
            Color[,] filteredPixels = new Color[imageWidth, imageHeight];
            for (int row = 0; row < imageWidth; row++)
            {
                for (int col = 0; col < imageHeight; col++)
                {
                    var color = GetFilteredPixel(digitalFilter, pixels, row, col);
                    filteredPixels[row, col] = color;
                }
            }
            return filteredPixels;
        }

        private Color GetFilteredPixel(double[,] digitalFilter, Color[,] pixels, int row, int col)
        {
            int filterSideLength = (int)Math.Sqrt(digitalFilter.Length);
            int centerIndex = (filterSideLength - 1) / 2;
            double redFilterationValue = 0, greenFilterationValue = 0, blueFilterationValue = 0;
            for (int filterRow = 0, pixelsRow = row - centerIndex; filterRow < filterSideLength; filterRow++, pixelsRow++)
            {
                for (int filterCol = 0, pixelsCol = col - centerIndex; filterCol < filterSideLength; filterCol++, pixelsCol++)
                {
                    if (pixelsRow >= 0 && pixelsCol >= 0 && pixelsRow < imageWidth && pixelsCol < imageHeight)
                    {
                        redFilterationValue += pixels[pixelsRow, pixelsCol].R * digitalFilter[filterRow, filterCol];
                        greenFilterationValue += pixels[pixelsRow, pixelsCol].G * digitalFilter[filterRow, filterCol];
                        blueFilterationValue += pixels[pixelsRow, pixelsCol].B * digitalFilter[filterRow, filterCol];
                    }
                }
            }

            return new Color
            {
                R = (byte)redFilterationValue,
                G = (byte)greenFilterationValue,
                B = (byte)blueFilterationValue,
                A = 255
            };
        }

        private void DrawSobelButton_Click(object sender, RoutedEventArgs e)
        {
            Color[,] pixels = GetImagePixels(wbm);
            var filteredPixels = GetSobelDrawing(pixels);
            WriteableBitmap filteredWbm = GetWriteableBitmapFromPixels(filteredPixels);
            derivativeImage.Source = filteredWbm;
            saveDerivativeImageBttn.IsEnabled = true;
        }

        private Color[,] GetSobelDrawing(Color[,] pixels)
        {     
            Color[,] sobelFilteredPixels = new Color[imageWidth, imageHeight];
            for (int row = 0; row < imageWidth; row++)
            {
                for (int col = 0; col < imageHeight; col++)
                {
                    sobelFilteredPixels[row, col] = GetSobelFilteredPixel(pixels, row, col);
                }
            }

            return sobelFilteredPixels;
        }

        private Color GetSobelFilteredPixel(Color[,] pixels, int row, int col)
        {
            double[,] dfx = { { -1, 0, 1 }, { -2, 0, 2 }, { -1, 0, 1 } };
            double[,] dfy = { { -1, -2, -1 }, { 0, 0, 0 }, { 1, 2, 1 } };

            int filterSideLength = 3; 
            int centerIndex = 1;
            double redFilterationValueX = 0, greenFilterationValueX = 0, blueFilterationValueX = 0;
            double redFilterationValueY = 0, greenFilterationValueY = 0, blueFilterationValueY = 0;

            for (int filterRow = 0, pixelsRow = row - centerIndex; filterRow < filterSideLength; filterRow++, pixelsRow++)
            {
                for (int filterCol = 0, pixelsCol = col - centerIndex; filterCol < filterSideLength; filterCol++, pixelsCol++)
                {
                    if (pixelsRow >= 0 && pixelsCol >= 0 && pixelsRow < imageWidth && pixelsCol < imageHeight)
                    {
                        redFilterationValueX += pixels[pixelsRow, pixelsCol].R * dfx[filterRow, filterCol];
                        greenFilterationValueX += pixels[pixelsRow, pixelsCol].G * dfx[filterRow, filterCol];
                        blueFilterationValueX += pixels[pixelsRow, pixelsCol].B * dfx[filterRow, filterCol];

                        redFilterationValueY += pixels[pixelsRow, pixelsCol].R * dfy[filterRow, filterCol];
                        greenFilterationValueY += pixels[pixelsRow, pixelsCol].G * dfy[filterRow, filterCol];
                        blueFilterationValueY += pixels[pixelsRow, pixelsCol].B * dfy[filterRow, filterCol];

                    }
                }
            }

            return new Color
            {
                R = (byte)Math.Sqrt(Math.Pow(redFilterationValueX, 2) + Math.Pow(redFilterationValueY, 2)),
                G = (byte)Math.Sqrt(Math.Pow(greenFilterationValueX, 2) + Math.Pow(greenFilterationValueY, 2)),
                B = (byte)Math.Sqrt(Math.Pow(blueFilterationValueX, 2) + Math.Pow(blueFilterationValueY, 2)),
                A = 255
            };
        }

        private WriteableBitmap GetWriteableBitmapFromPixels(Color[,] pixels)
        {
            WriteableBitmap writableBM = new WriteableBitmap(imageWidth, imageHeight, wbm.DpiX, wbm.DpiY, PixelFormats.Bgr32, null);
            for (int row = 0; row < imageWidth; row++)
            {
                for (int col = 0; col < imageHeight; col++)
                {
                    SetPixel(writableBM, row, col, pixels[row, col]);
                }
            }
            return writableBM;
        }

        private Color[,] GetImagePixels(WriteableBitmap writableBM)
        {
            Color[,] pixels = new Color[imageWidth, imageHeight];
            for (int row = 0; row < imageWidth; row++)
            {
                for (int col = 0; col < imageHeight; col++)
                {
                    pixels[row, col] = GetPixel(writableBM, row, col);
                }
            }
            return pixels;
        }

        private Color[,] GetGrayScaleImage(WriteableBitmap writableBM)
        {
            Color[,] pixels = new Color[imageWidth, imageHeight];
            for (int row = 0; row < imageWidth; row++)
            {
                for (int col = 0; col < imageHeight; col++)
                {
                    pixels[row, col] = GetGrayScalePixel(GetPixel(writableBM, row, col));
                }
            }
            return pixels;
        }

        private Color GetGrayScalePixel(Color c)
        {
            Color cNew = new Color
            {
                R = (byte)(0.21 * c.R + 0.71 * c.G + 0.08 * c.B)
            };
            cNew.G = cNew.R;
            cNew.B = cNew.R;
            cNew.A = 255;
            return cNew;
        }

        private bool IsPixelGrayScale(Color pixel)
        {
            return (pixel.B == pixel.R && pixel.B == pixel.G);
        }

        private bool IsImageGrayScale(WriteableBitmap writableBM)
        {
            for (int row = 0; row < imageWidth; row++)
            {
                for (int col = 0; col < imageHeight; col++)
                {
                    if (!IsPixelGrayScale(GetPixel(writableBM, row, col)))
                        return false;
                }
            }
            return true;
        }

        private Color[,] GetBlackAndWhiteImage(WriteableBitmap writableBM, Color[,] grayPixels)
        {
            if (!IsImageGrayScale(writableBM))
            {
                throw new Exception("The image is not gray scale, cannot create a black and white image!");
            }

            Color[,] pixels = new Color[imageWidth, imageHeight];
            for (int row = 0; row < imageWidth; row++)
            {
                for (int col = 0; col < imageHeight; col++)
                {
                    if (grayPixels[row, col].B > blackAndWhiteSeperator)
                    {
                        pixels[row, col].G = 255; pixels[row, col].R = 255; pixels[row, col].B = 255;
                    }
                    else
                    {
                        pixels[row, col].G = 0; pixels[row, col].R = 0; pixels[row, col].B = 0;
                    }
                }
            }
            return pixels;
        }

        public void SetPixel(WriteableBitmap writableBM, int x, int y, Color c)
        {
            if (y > writableBM.PixelHeight - 1 || x > writableBM.PixelWidth - 1) return;
            if (y < 0 || x < 0) return;
            writableBM.Lock();
            IntPtr buff = writableBM.BackBuffer;
            int Stride = writableBM.BackBufferStride;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                pbuff[loc] = c.B;
                pbuff[loc + 1] = c.G;
                pbuff[loc + 2] = c.R;
                pbuff[loc + 3] = c.A;
            }
            writableBM.AddDirtyRect(new Int32Rect(x, y, 1, 1));
            writableBM.Unlock();
        }

        public Color GetPixel(WriteableBitmap writableBM, int x, int y)
        {
            if (y > writableBM.PixelHeight - 1 || x > writableBM.PixelWidth - 1)
                return Color.FromArgb(0, 0, 0, 0);
            if (y < 0 || x < 0)
                return Color.FromArgb(0, 0, 0, 0);
            IntPtr buff = writableBM.BackBuffer;
            int Stride = writableBM.BackBufferStride;
            Color c;
            unsafe
            {
                byte* pbuff = (byte*)buff.ToPointer();
                int loc = y * Stride + x * 4;
                c = Color.FromArgb(pbuff[loc + 3], pbuff[loc + 2],
                                       pbuff[loc + 1], pbuff[loc]);
            }
            return c;
        }

        private void About_Button_Click(object sender, RoutedEventArgs e)
        {
            aboutWindow = new AboutWindow(aboutBttn);
            aboutWindow.Show();
            aboutBttn.IsEnabled = false;
        }

        private void Help_Button_Click(object sender, RoutedEventArgs e)
        {
            helpWindow = new HelpWindow(helpBttn);
            helpWindow.Show();
            helpBttn.IsEnabled = false;
        }
    }
}
