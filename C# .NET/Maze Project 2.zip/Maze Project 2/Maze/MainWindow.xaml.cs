﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Maze
{
    public partial class MainWindow : Window
    {
        private HelpWindow helpWindow;
        private AboutWindow aboutWindow;

        const int MROW = 30;
        const int MCOL = 30;
        private Cell[][] maze = new Cell[MROW][];

        private Pen wallsColor = new Pen(Brushes.Black, 1);
        private Pen playerLineColor = new Pen(Brushes.DarkBlue, 5);
        readonly System.Random random = new System.Random();

        const int startingRow = 0;
        private int startingCol = 0;
        const int endingRow = MROW - 1;
        private int endingCol = 0;

        private int currentRow;
        private int currentCol;

        private DrawingContext dc;
        private List<DrawingVisual> visuals = new List<DrawingVisual>();

        private Cell currentCell = null;

        private RenderTargetBitmap bmp;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            startingCol = random.Next(0, MCOL - 1);
            endingCol = random.Next(0, MCOL - 1);
            visuals.Clear();
            currentRow = startingRow; currentCol = startingCol;
            GeneratePerfectMaze();
            DrawMaze();
            currentCell = maze[startingRow][startingCol];
            imgPlot.IsEnabled = true;
        }

        private void GeneratePerfectMaze()
        {
            InitializeGrid();
            bool done = false;
            while (!done)
            {
                if (maze[currentRow][currentCol].WasVisited())
                    done = true;
                else
                {
                    maze[currentRow][currentCol].SetVisited(true);
                    var cells = GetNonVisitedAdjoiningCells(currentRow, currentCol);
                    if (cells.Count == 0)
                        done = true;
                    else
                    {
                        int targetIndex = random.Next(cells.Count);
                        int targetRow = cells[targetIndex].GetRow(), targetCol = cells[targetIndex].GetCol();
                        Cell targetCell = maze[targetRow][targetCol];
                        targetCell.SetFrom(currentRow, currentCol);

                        if (targetCol == currentCol + 1)
                        {
                            maze[currentRow][currentCol].SetRWall(false);
                            currentCol++;
                        }
                        else if (targetRow == currentRow + 1)
                        {
                            maze[currentRow][currentCol].SetBWall(false);
                            currentRow++;
                        }
                        else if (targetCol == currentCol - 1)
                        {
                            targetCell.SetRWall(false);
                            currentCol--;
                        }
                        else if (targetRow == currentRow - 1)
                        {
                            targetCell.SetBWall(false);
                            currentRow--;
                        }
                    }
                }
            }
        }

        private void InitializeGrid()
        {
            maze = new Cell[MROW][];

            for (int row = 0; row < MROW; row++)
            {
                maze[row] = new Cell[MCOL];
                for (int col = 0; col < MCOL; col++)
                {
                    maze[row][col] = new Cell(row, col);
                }
            }
        }

        private List<Cell> GetNonVisitedAdjoiningCells(int row, int col)
        {
            var nonVisitedAdjoinedCells = new List<Cell>();
            if (col + 1 < MCOL && !maze[row][col + 1].WasVisited())
            {
                nonVisitedAdjoinedCells.Add(maze[row][col + 1]);
            }

            if (row + 1 < MROW && !maze[row + 1][col].WasVisited())
            {
                nonVisitedAdjoinedCells.Add(maze[row + 1][col]);
            }

            if (col - 1 >= 0 && !maze[row][col - 1].WasVisited())
            {
                nonVisitedAdjoinedCells.Add(maze[row][col - 1]);
            }

            if (row - 1 >= 0 && !maze[row - 1][col].WasVisited())
            {
                nonVisitedAdjoinedCells.Add(maze[row - 1][col]);
            }

            if (nonVisitedAdjoinedCells.Count != 0)
                return nonVisitedAdjoinedCells;

            int fromR = 0, fromC = 0;
            maze[row][col].GetFrom(ref fromR, ref fromC);
            if (fromR == startingRow && fromC == startingCol)
                return nonVisitedAdjoinedCells;

            currentRow = fromR;
            currentCol = fromC;
            return GetNonVisitedAdjoiningCells(fromR, fromC);
        }

        private void DrawMaze()
        {
            int r, c;
            double x, y, x1, y1;
            double cellSize = imgPlot.Height / MROW;
            Brush bluBrush = Brushes.AliceBlue;
            //Create a "visual" to draw on.
            DrawingVisual vis = new DrawingVisual();
            //Create a drawing contest for this visual
            dc = vis.RenderOpen();
            for (r = 0; r < MROW; r++)
            {
                for (c = 0; c < MCOL; c++)
                {
                    x = c * cellSize; y = r * cellSize;
                    x1 = x + cellSize; y1 = y + cellSize;

                    if (maze[r][c].HasBWall())
                        dc.DrawLine(wallsColor, new Point(x, y1), new Point(x1, y1)); // draws the BWall
                    if (maze[r][c].HasRWall())
                        dc.DrawLine(wallsColor, new Point(x1, y), new Point(x1, y1)); // draws the RWall
                }
            }
            dc.DrawLine(new Pen(Brushes.Black, 1), new Point(0, 0), new Point(0, 500));
            dc.DrawLine(new Pen(Brushes.Black, 1), new Point(0, 0), new Point(500, 0));

            ColorCell(maze[startingRow][startingCol], cellSize, new Pen(Brushes.Green, 1), bluBrush);
            ColorCell(maze[endingRow][endingCol], cellSize, new Pen(Brushes.Red, 1), bluBrush);

            dc.Close();
            //Create a bit map 

            bmp = new RenderTargetBitmap(500, 500, 96, 96, PixelFormats.Pbgra32);

            //Render the visual to the bitmap
            bmp.Render(vis);
            //Make the image source the bitmap
            imgPlot.Source = bmp;
            visuals.Add(vis);
        }

        private void ColorCell(Cell cell, double cellSize, Pen coloredPen, Brush brush)
        {
            Rect rectangle = new Rect(new Point((cell.GetCol() * cellSize) + 3, cell.GetRow() * cellSize + 3),
                                        new Size(cellSize - 6, cellSize - 6));
            dc.DrawRectangle(brush, coloredPen, rectangle);
        }

        private void imgPlot_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Point clickPoint = e.GetPosition(imgPlot);
            Cell targetCell = GetCellFrom(clickPoint);

            if(!IsDrawingValid(targetCell))
                return;

            DrawLineTo(targetCell);

            IsMazeSolved();
        }

        private bool IsDrawingValid(Cell targetCell)
        {
            if (targetCell.GetDrawn())
            {
                return false;
            }

            if (targetCell.GetRow() == currentCell.GetRow() && targetCell.GetCol() == currentCell.GetCol())
            {
                return false;
            }

            if (!IsTargetCellAdjoining(targetCell))
            {
                if (IsTargetCellOnSameRow(targetCell))
                {
                    if (targetCell.GetCol() > currentCell.GetCol())
                    {

                        for (int i = currentCell.GetCol(); i < targetCell.GetCol(); i++)
                        {
                            if (maze[currentCell.GetRow()][i].HasRWall() || (i != currentCell.GetCol() && maze[currentCell.GetRow()][i].GetDrawn()))
                            {
                                return false;
                            }
                        }
                    }
                    else
                    {
                        for (int i = targetCell.GetCol(); i < currentCell.GetCol(); i++)
                        {
                            if (maze[currentCell.GetRow()][i].HasRWall() || maze[currentCell.GetRow()][i].GetDrawn())
                            {
                                return false;
                            }
                        }
                    }
                }

                else if (IsTargetCellOnSameCol(targetCell))
                {
                    if (targetCell.GetRow() > currentCell.GetRow())
                    {
                        for (int i = currentCell.GetRow(); i < targetCell.GetRow(); i++)
                        {
                            if (maze[i][currentCell.GetCol()].HasBWall() || (i != currentCell.GetRow() && maze[i][currentCell.GetCol()].GetDrawn()))
                            {
                                return false;
                            }
                        }
                    }
                    else
                    {
                        for (int i = targetCell.GetRow(); i < currentCell.GetRow(); i++)
                        {
                            if (maze[i][currentCell.GetCol()].HasBWall() || maze[i][currentCell.GetCol()].GetDrawn())
                            {
                                return false;
                            }
                        }
                    }
                }
                else
                    return false;
            }
            else
            {
                if (currentCell.HasRWall() && targetCell.GetCol() > currentCell.GetCol())
                {
                    return false;
                }

                if (currentCell.HasBWall() && targetCell.GetRow() > currentCell.GetRow())
                {
                    return false;
                }

                if (targetCell.HasRWall() && targetCell.GetCol() < currentCell.GetCol())
                {
                    return false;
                }

                if (targetCell.HasBWall() && targetCell.GetRow() < currentCell.GetRow())
                {
                    return false;
                }
            }

            return true;
        }

        private bool IsTargetCellAdjoining(Cell targetCell)
        {
            if ((targetCell.GetRow() == currentCell.GetRow() + 1 || targetCell.GetRow() == currentCell.GetRow() - 1)
                && targetCell.GetCol() == currentCell.GetCol())
            {
                return true;
            }

            if ((targetCell.GetCol() == currentCell.GetCol() + 1 || targetCell.GetCol() == currentCell.GetCol() - 1)
                && targetCell.GetRow() == currentCell.GetRow())
            {
                return true;
            }

            return false;
        }

        private void DrawLineTo(Cell targetCell)
        {
            DrawingVisual vis = new DrawingVisual();
            dc = vis.RenderOpen();

            Point sourcePoint = GetCellCenterPoint(currentCell);
            Point targetPoint = GetCellCenterPoint(targetCell);

            dc.DrawLine(playerLineColor, sourcePoint, targetPoint);
            dc.Close();
            bmp.Render(vis);
            imgPlot.Source = bmp;
            targetCell.SetDrawn(true);
            if (IsTargetCellOnSameRow(targetCell))
            {
                if (targetCell.GetCol() > currentCell.GetCol())
                {
                    for (int i = currentCell.GetCol(); i < targetCell.GetCol(); i++)
                    {
                        maze[currentCell.GetRow()][i].SetDrawn(true);
                    }
                }
                else
                {
                    for (int i = targetCell.GetCol(); i < currentCell.GetCol(); i++)
                    {
                        maze[currentCell.GetRow()][i].SetDrawn(true);
                    }
                }
            }

            else if (IsTargetCellOnSameCol(targetCell))
            {
                if (targetCell.GetRow() > currentCell.GetRow())
                {
                    for (int i = currentCell.GetRow(); i < targetCell.GetRow(); i++)
                    {
                        maze[i][currentCell.GetCol()].SetDrawn(true);
                    }
                }
                else
                {
                    for (int i = targetCell.GetRow(); i < currentCell.GetRow(); i++)
                    {
                        maze[i][currentCell.GetCol()].SetDrawn(true);
                    }
                }
            }
            targetCell.SetFrom(currentCell.GetRow(), currentCell.GetCol());
            visuals.Add(vis);
            currentCell = targetCell;
        }

        private bool IsMazeSolved()
        {
            if (currentCell.GetRow() == endingRow && currentCell.GetCol() == endingCol)
            {
                MessageBox.Show("You reached the end!");
                imgPlot.IsEnabled = false;
                return true;
            }
            return false;
        }

        private bool IsTargetCellOnSameRow(Cell cell)
        {
            return (cell.GetRow() == currentCell.GetRow());
        }

        private bool IsTargetCellOnSameCol(Cell cell)
        {
            return (cell.GetCol() == currentCell.GetCol());
        }

        private Point GetCellCenterPoint(Cell cell)
        {
            double cellSize = imgPlot.Height / MROW;
            int row = cell.GetRow();
            int col = cell.GetCol();
            row = (int)(row * cellSize) + (int)(cellSize / 2);
            col = (int)(col * cellSize) + (int)(cellSize / 2);
            return new Point(col, row);
        }

        private Cell GetCellFrom(Point clickPoint)
        {
            double cellSize = imgPlot.Height / MROW;
            int row = (int)(clickPoint.Y / cellSize);
            int col = (int)(clickPoint.X / cellSize);
            row = row >= MROW ? MROW - 1 : row < 0 ? 0 : row;
            col = col >= MCOL ? MCOL - 1 : col < 0 ? 0 : col;
            return maze[row][col];
        }

        private void imgPlot_MouseRightButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if(visuals.Count == 1)
            {
                return;
            }

            Point clickPoint = e.GetPosition(imgPlot);
            Cell targetCell = GetCellFrom(clickPoint);

            if(targetCell != currentCell)
            {
                return;
            }
            
            targetCell.SetDrawn(false);
            int row = 0, col = 0;
            currentCell.GetFrom(ref row, ref col);
            currentCell = maze[row][col];
            Cell previousCell = maze[row][col];
            if (targetCell.GetRow() == previousCell.GetRow())
            {
                if (targetCell.GetCol() > previousCell.GetCol())
                {
                    for (int i = previousCell.GetCol(); i < targetCell.GetCol(); i++)
                    {
                        maze[previousCell.GetRow()][i].SetDrawn(false);
                    }
                }
                else
                {
                    for (int i = targetCell.GetCol(); i < previousCell.GetCol(); i++)
                    {
                        maze[previousCell.GetRow()][i].SetDrawn(false);
                    }
                }
            }

            else if (targetCell.GetCol() == previousCell.GetCol())
            {
                if (targetCell.GetRow() > previousCell.GetRow())
                {
                    for (int i = previousCell.GetRow(); i < targetCell.GetRow(); i++)
                    {
                        maze[i][previousCell.GetCol()].SetDrawn(false);
                    }
                }
                else
                {
                    for (int i = targetCell.GetRow(); i < previousCell.GetRow(); i++)
                    {
                        maze[i][previousCell.GetCol()].SetDrawn(false);
                    }
                }
            }

            visuals.RemoveAt(visuals.Count - 1);
            bmp = new RenderTargetBitmap(500, 500, 96, 96, PixelFormats.Pbgra32);
            visuals.ForEach((visual) =>
            {
                bmp.Render(visual);
                imgPlot.Source = bmp;
            });
        }

        private void GreenRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            wallsColor = new Pen(Brushes.Green, 1);
        }

        private void SkyBlueRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            wallsColor = new Pen(Brushes.SkyBlue, 1);
        }

        private void RedRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            wallsColor = new Pen(Brushes.Red, 1);
        }

        private void BlackRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            wallsColor = new Pen(Brushes.Black, 1);
        }

        private void DarkBlueRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            playerLineColor = new Pen(Brushes.DarkBlue, 5);
        }

        private void BrownRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            playerLineColor = new Pen(Brushes.Brown, 5);
        }

        private void PinkRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            playerLineColor = new Pen(Brushes.Pink, 5);
        }

        private void DarkGreenRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            playerLineColor = new Pen(Brushes.DarkGreen, 5);
        }

        private void About_Button_Click(object sender, RoutedEventArgs e)
        {
            aboutWindow = new AboutWindow(aboutBttn);
            aboutWindow.Show();
            aboutBttn.IsEnabled = false;
        }

        private void Help_Button_Click(object sender, RoutedEventArgs e)
        {
            helpWindow = new HelpWindow(helpBttn);
            helpWindow.Show();
            helpBttn.IsEnabled = false;
        }
    }
}