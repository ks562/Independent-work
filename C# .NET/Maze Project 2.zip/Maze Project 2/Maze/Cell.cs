﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maze
{
    class Cell
    {
        private Cell()
        {
            visited = false;
            rWall = true;
            bWall = true;
            fromR = -1;
            fromC = -1;
        }

        public Cell(int row, int col) : this()
        {
            this.row = row;
            this.col = col;
        }

        public bool WasVisited()
        {
            return visited;
        }
        public void SetVisited(bool b)
        {
            visited = b;
        }
        public bool HasRWall()
        {
            return rWall;
        }
        public void SetRWall(bool b)
        {
            rWall = b;
        }
        public bool HasBWall()
        {
            return bWall;
        }
        public void SetBWall(bool b)
        {
            bWall = b;
        }
        public void SetFrom(int fRow, int fCol)
        {
            fromR = fRow;
            fromC = fCol;
        }
        public void GetFrom(ref int fRow, ref int fCol)
        {
            fRow = fromR;
            fCol = fromC;
        }

        public int GetRow()
        {
            return row;
        }

        public int GetCol()
        {
            return col;
        }

        public void SetDrawn(bool b)
        {
            drawn = b;
        }

        public bool GetDrawn()
        {
            return drawn;
        }

        private bool visited;
        private bool rWall; //right wall
        private bool bWall; //bottom wall
                            //fromR and fromC are the coordinates of the previous cell
        private int fromR; //from row
        private int fromC; //from col
        private int row;
        private int col;
        private bool drawn;

    }
}
