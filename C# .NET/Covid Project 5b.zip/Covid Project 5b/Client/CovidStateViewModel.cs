﻿using System;

namespace Client
{
    class CovidStateViewModel
    {
        public string State { get; set; }
        public DateTime Date { get; set; }
        public int ConfirmedDeaths { get; set; }
        public int NumberOfCases { get; set; }
        public int TotalNumberOfHospitalization { get; set; }
        public int CurrentNumberOfHospitalization { get; set; }
        public int TotalNumberOfTests { get; set; }
        public int NumberOfNegativeTests { get; set; }
        public int NumberOfPositiveTests { get; set; }
        public int NumberOfPendingTests { get; set; }
    }
}
