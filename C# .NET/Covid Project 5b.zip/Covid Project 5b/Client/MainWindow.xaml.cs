﻿using System;
using System.Windows;
using System.ComponentModel;
using System.Net.Sockets;   //include sockets class
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Forms.Integration;

namespace Client
{
    public partial class MainWindow : Window
    {
        private Help helpWindow;
        private About aboutWindow;

        NetworkStream ns;
        StreamReader sr;
        StreamWriter sw;
        delegate void SetLabelCallback(string text, Label label);
        delegate void AddAreaToChartCallBack(Chart chart, ChartArea area);
        delegate void AddSeriesToChartCallBack(Chart chart, Series series);

        delegate void ClearSeriesCallBack(Chart chart);
        delegate void ClearAreasCallBack(Chart chart);



        BackgroundWorker backgroundWorker1 = new BackgroundWorker();

        int clientNumber = 0;
        enum Protocol
        {
            clientId, disconnect, state, dateRangeForState, specificDate
        };
        Chart chart = new Chart();
        string chartCategory = "";

        List<CovidStateViewModel> deserializedViewModelList = new List<CovidStateViewModel>();

        public MainWindow()
        {
            InitializeComponent();


            calender1.BlackoutDates.Add(new CalendarDateRange(new DateTime(1000, 1, 1), new DateTime(2020, 3, 31)));
            calender1.BlackoutDates.Add(new CalendarDateRange(DateTime.Today, new DateTime(3000, 1, 1)));

            backgroundWorker1.DoWork += new DoWorkEventHandler(backgroundWorker1_DoWork);

            stateComboBox.ItemsSource = Constants.states;
            stateComboBox.SelectedItem = Constants.states[0];

             AutoConnect();
        }

        private void AutoConnect()
        {
            TcpClient newcon = new TcpClient();
            while (true)
            {
                try
                {
                    newcon.Connect("127.0.0.1", 9090);
                    ns = newcon.GetStream();
                    sr = new StreamReader(ns);
                    sw = new StreamWriter(ns);
                    backgroundWorker1.RunWorkerAsync("Message to Worker");
                    break;
                }
                catch
                {
                    var result = MessageBox.Show("No server to connect to, click yes after you run the server, no to exit", "no connection", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);
                    if (result == MessageBoxResult.No)
                        Close();

                }
            }
        }

        private void btn_Send_Click(object sender, RoutedEventArgs e)
        {
            string startDateStr, endDateStr;
            if (calender1.SelectedDates.Count > 1)
            {
                var lastDateSelected = calender1.SelectedDates[calender1.SelectedDates.Count - 1];
                var firstDateSelected = calender1.SelectedDates[0];
                if (lastDateSelected < firstDateSelected)
                {
                    startDateStr = lastDateSelected.ToString("yyyyMMdd");
                    endDateStr = firstDateSelected.ToString("yyyyMMdd");
                }
                else
                {
                    startDateStr = firstDateSelected.ToString("yyyyMMdd");
                    endDateStr = lastDateSelected.ToString("yyyyMMdd");
                }
                var datedRequest = Protocol.dateRangeForState.ToString() + ":" + stateComboBox.SelectedItem.ToString() + ":" + startDateStr + ":" + endDateStr;

                sw.WriteLine(datedRequest);

                sw.Flush();
            }
            else if (calender1.SelectedDates.Count == 1)
            {
                var specifiedDate = calender1.SelectedDate.Value.ToString("yyyyMMdd");
                var datedRequest = Protocol.specificDate.ToString() + ":" + stateComboBox.SelectedItem.ToString() + ":" + specifiedDate;
                sw.WriteLine(datedRequest);
                sw.Flush();

            }
            else
            {

                sw.WriteLine(Protocol.state.ToString() + ":" + stateComboBox.SelectedItem.ToString());

                sw.Flush();

            }

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                try
                {
                    string inputStream = sr.ReadLine();
                    if (string.IsNullOrWhiteSpace(inputStream))
                        continue;
                    if (inputStream.StartsWith(Protocol.clientId.ToString()))
                    {
                        string[] splitMessage = inputStream.Split('#');
                        clientNumber = int.Parse(splitMessage[1]);
                        continue;
                    }
                    if (inputStream == Protocol.disconnect.ToString())
                    {
                        KillProject();

                        break;
                    }
                    if (inputStream.StartsWith(Protocol.state.ToString()))
                    {
                        var response = inputStream.Substring(6);
                        CovidStateViewModel deserializedViewModel = JsonConvert.DeserializeObject<CovidStateViewModel>(response);
                        DisplayData(deserializedViewModel);
                        SetLabelText("Current data for " + deserializedViewModel.State + ":", stateDataLabel);

                    }
                    if (inputStream.StartsWith(Protocol.dateRangeForState.ToString()))
                    {
                        var response = inputStream.Substring(18);
                        deserializedViewModelList = JsonConvert.DeserializeObject<List<CovidStateViewModel>>(response);
                        DrawChart(deserializedViewModelList);
                    }
                    if(inputStream.StartsWith(Protocol.specificDate.ToString()))
                    {
                        var response = inputStream.Substring(13);
                        CovidStateViewModel deserializedViewModel = JsonConvert.DeserializeObject<CovidStateViewModel>(response);
                        DisplayData(deserializedViewModel);
                        SetLabelText("Data for " + deserializedViewModel.State + " on " + deserializedViewModel.Date.ToString("MM/dd/yyyy") + ":", stateDataLabel);

                    }
                }
                catch
                {
                    ns.Close();
                    Environment.Exit(Environment.ExitCode); //close all 
                }
            }
        }

        private void DisplayData(CovidStateViewModel deserializedViewModel)
        {
            SetLabelText(deserializedViewModel.ConfirmedDeaths.ToString(), confirmedDeathsNum);
            SetLabelText(deserializedViewModel.NumberOfCases.ToString(), numOfCasesNum);
            SetLabelText(deserializedViewModel.TotalNumberOfHospitalization.ToString(), totalHospitalizationNum);
            SetLabelText(deserializedViewModel.CurrentNumberOfHospitalization.ToString(), currentHospitalizationNum);
            SetLabelText(deserializedViewModel.TotalNumberOfTests.ToString(), totalTestsNum);
            SetLabelText(deserializedViewModel.NumberOfPositiveTests.ToString(), positiveTestsNum);
            SetLabelText(deserializedViewModel.NumberOfNegativeTests.ToString(), negativeTestsNum);
            SetLabelText(deserializedViewModel.NumberOfPendingTests.ToString(), pendingTestsNum);
            SetLabelText(deserializedViewModel.Date.ToString("MM/dd/yyyy"), dateLabel);

        }

        private void SetLabelText(string text, Label label)
        {

            if (label.Dispatcher.CheckAccess())
            {
                label.Content = text;

            }
            else
            {
                label.Dispatcher.BeginInvoke(new SetLabelCallback(SetLabelText), text, label);
            }
        }

        private void AddAreaToChart(Chart chart, ChartArea area)
        {
            if (chart.InvokeRequired)
            {
                chart.Invoke(new AddAreaToChartCallBack(AddAreaToChart), chart, area);
                return;
            }
            chart.ChartAreas.Add(area);
        }

        private void ClearChartSeries(Chart chart)
        {
            if (chart.InvokeRequired)
            {
                chart.Invoke(new ClearSeriesCallBack(ClearChartSeries), chart);
                return;
            }
            chart.Series.Clear();
        }

        private void ClearChartAreas(Chart chart)
        {
            if (chart.InvokeRequired)
            {
                chart.Invoke(new ClearAreasCallBack(ClearChartAreas), chart);
                return;
            }
            chart.ChartAreas.Clear();
        }
        private void AddSeriesToChart(Chart chart, Series series)
        {
            if (chart.InvokeRequired)
            {
                chart.Invoke(new AddSeriesToChartCallBack(AddSeriesToChart), chart, series);
                return;
            }
            chart.Series.Add(series);
        }





        private void DrawChart(List<CovidStateViewModel> data)
        {

            Chart chart = MyWinformChart as Chart;
            ClearChartSeries(chart);
            ClearChartAreas(chart);
            ChartArea chartArea = new ChartArea("Covid Statistics");
            chartArea.AxisX.Title = "Date";
            chartArea.AxisX.IntervalType = DateTimeIntervalType.Days;

            chartArea.AxisX.Minimum = data[0].Date.AddDays(-1).ToOADate();
            chartArea.AxisX.Maximum = data[data.Count - 1].Date.AddDays(1).ToOADate();
         
            chartArea.AxisY.Title = chartCategory;
          

            AddAreaToChart(chart, chartArea);
            Series chartSeries = new Series
            {
                ChartType = SeriesChartType.Column
            };

            data.ForEach(viewModal =>
            {
                if (chartCategory == "Number of Confirmed Deaths")
                    chartSeries.Points.AddXY(viewModal.Date.ToOADate(), viewModal.ConfirmedDeaths);
                if (chartCategory == "Number of Cases")
                    chartSeries.Points.AddXY(viewModal.Date.ToOADate(), viewModal.NumberOfCases);
                if (chartCategory == "Total Number of Hospitalization")
                    chartSeries.Points.AddXY(viewModal.Date.ToOADate(), viewModal.TotalNumberOfHospitalization);
                if (chartCategory == "Current Number of Hospitalization")
                    chartSeries.Points.AddXY(viewModal.Date.ToOADate(), viewModal.CurrentNumberOfHospitalization);
                if (chartCategory == "Total Number of Tests")
                    chartSeries.Points.AddXY(viewModal.Date.ToOADate(), viewModal.TotalNumberOfTests);
                if (chartCategory == "Number of Positive Tests")
                    chartSeries.Points.AddXY(viewModal.Date.ToOADate(), viewModal.NumberOfPositiveTests);
                if (chartCategory == "Number of Negative Tests")
                    chartSeries.Points.AddXY(viewModal.Date.ToOADate(), viewModal.NumberOfNegativeTests);
                if (chartCategory == "Number of Pending Tests")
                    chartSeries.Points.AddXY(viewModal.Date.ToOADate(), viewModal.NumberOfPendingTests);


            });

            AddSeriesToChart(chart, chartSeries);
        }


        private void Window_Closing_1(object sender, CancelEventArgs e)
        {
            KillProject();
        }

        private void KillProject()
        {
            if (ns != null)
            {
                sw.WriteLine(Protocol.disconnect.ToString());
                sw.Flush();
                sr.Close();
                sw.Close();
                ns.Close();
            }
            Environment.Exit(Environment.ExitCode); //close all
        }

        private void NumOfConfirmedDeathsRadioBttn_Checked(object sender, RoutedEventArgs e)
        {
            chartCategory = "Number of Confirmed Deaths";
            if(deserializedViewModelList.Count > 1)
                DrawChart(deserializedViewModelList);

        }

        private void NumOfCasesRadioBttn_Checked(object sender, RoutedEventArgs e)
        {
            chartCategory = "Number of Cases";
            if (deserializedViewModelList.Count > 1)
                DrawChart(deserializedViewModelList);
        }

        private void TotalNumOfHospitalizationRadioBttn_Checked(object sender, RoutedEventArgs e)
        {
            chartCategory = "Total Number of Hospitalization";
            if (deserializedViewModelList.Count > 1)
                DrawChart(deserializedViewModelList);

        }

        private void CurrNumOfHospitalizationRadioBttn_Checked(object sender, RoutedEventArgs e)
        {
            chartCategory = "Current Number of Hospitalization";
            if (deserializedViewModelList.Count > 1)
                DrawChart(deserializedViewModelList);

        }

        private void TotalNumOfTestsRadioBttn_Checked(object sender, RoutedEventArgs e)
        {
            chartCategory = "Total Number of Tests";
            if (deserializedViewModelList.Count > 1)
                DrawChart(deserializedViewModelList);
        }

        private void NumOfPositiveTestsRadioBttn_Checked(object sender, RoutedEventArgs e)
        {
            chartCategory = "Number of Positive Tests";
            if (deserializedViewModelList.Count > 1)
                DrawChart(deserializedViewModelList);
        }

        private void NumOfNegativeTestsRadioBttn_Checked(object sender, RoutedEventArgs e)
        {
            chartCategory = "Number of Negative Tests";
            if (deserializedViewModelList.Count > 1)
                DrawChart(deserializedViewModelList);
        }

        private void NumOfPendingTestsRadioBttn_Checked(object sender, RoutedEventArgs e)
        {
            chartCategory = "Number of Pending Tests";
            if (deserializedViewModelList.Count > 1)
                DrawChart(deserializedViewModelList);
        }

        private void stateComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }

        private void calender1_MouseRightButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            calender1.SelectedDates.Clear();
        }

        private void About_Button_Click(object sender, RoutedEventArgs e)
        {
            aboutWindow = new About(aboutBttn);
            aboutWindow.Show();
            aboutBttn.IsEnabled = false;
        }

        private void Help_Button_Click(object sender, RoutedEventArgs e)
        {
            helpWindow = new Help(helpBttn);
            helpWindow.Show();
            helpBttn.IsEnabled = false;
        }
    }
}
