﻿using System.Windows;
using System.Windows.Controls;

namespace Server
{
    public partial class About : Window
    {
        private Button aboutBttn;
        public About(Button aboutBttn)
        {
            InitializeComponent();
            this.aboutBttn = aboutBttn;
            Closing += (sender, e) =>
            {
                aboutBttn.IsEnabled = true;
            };
        }
    }
}
