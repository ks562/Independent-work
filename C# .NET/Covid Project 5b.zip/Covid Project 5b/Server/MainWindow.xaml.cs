﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.ComponentModel;
using Newtonsoft.Json;

namespace Server
{
    public partial class MainWindow : Window
    {
        private Help helpWindow;
        private About aboutWindow;

        delegate void SetTextCallback(String text);
        delegate void SetIntCallbCk(int theadnum);

        BackgroundWorker backgroundWorker1 = new BackgroundWorker();

        enum Protocol
        {
            clientId, disconnect, state, dateRangeForState, specificDate
        };

        public MainWindow()
        {
            InitializeComponent();
            backgroundWorker1.DoWork += new DoWorkEventHandler(backgroundWorker1_DoWork);

            backgroundWorker1.RunWorkerAsync("Message to Worker");
        }

        BackgroundWorker[] bkw1 = new BackgroundWorker[100];
        Socket client;
        NetworkStream[] ns = new NetworkStream[100];
        StreamReader[] sr = new StreamReader[100];
        StreamWriter[] sw = new StreamWriter[100];
        List<int> AvailableClientNumbers = new List<int>(100);
        List<int> UsedClientNumbers = new List<int>(100);

        int clientcount = 0;

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            String printtext;
            TcpListener newsocket = new TcpListener(IPAddress.Any, 9090);  //Create TCP Listener on server
            newsocket.Start();
            for (int i = 0; i < 100; i++)
            {
                AvailableClientNumbers.Add(i);
            }
            while (AvailableClientNumbers.Count > 0)
            {
                InsertText("waiting for client");                   //wait for connection
                printtext = "Available Clients = " + AvailableClientNumbers.Count;
                InsertText(printtext);                   //wait for connection
                client = newsocket.AcceptSocket();     //Accept Connection
                clientcount = AvailableClientNumbers.First();
                AvailableClientNumbers.Remove(clientcount);
                ns[clientcount] = new NetworkStream(client);                            //Create Network stream
                sr[clientcount] = new StreamReader(ns[clientcount]);
                sw[clientcount] = new StreamWriter(ns[clientcount]);
                string welcome = "Welcome";
                InsertText("client connected");
                sw[clientcount].WriteLine(welcome);     //Stream Reader and Writer take away some of the overhead of keeping track of Message size.  By Default WriteLine and ReadLine use Line Feed to delimit the messages
                sw[clientcount].Flush();
                string clientIdMessage = Protocol.clientId.ToString() + "#" + clientcount;
                sw[clientcount].WriteLine(clientIdMessage);
                sw[clientcount].Flush();
                bkw1[clientcount] = new BackgroundWorker { WorkerSupportsCancellation = true };
                bkw1[clientcount].DoWork += new DoWorkEventHandler(client_DoWork);
                bkw1[clientcount].RunWorkerAsync(clientcount);
                UsedClientNumbers.Add(clientcount);
            }
        }

        private void client_DoWork(object sender, DoWorkEventArgs e)
        {
            int clientnum = (int)e.Argument;
            bkw1[clientnum].WorkerSupportsCancellation = true;

            while (true)
            {
                string inputStream;
                try
                {
                    inputStream = sr[clientnum].ReadLine();
                    InsertText(inputStream);
                    if (inputStream == Protocol.disconnect.ToString())
                    {
                        sr[clientnum].Close();
                        sw[clientnum].Close();
                        ns[clientnum].Close();
                        InsertText("Client " + clientnum + " has disconnected");
                        KillMe(clientnum);
                        break;
                    }
                    if (inputStream.StartsWith(Protocol.state.ToString()))
                    {
                        var state = inputStream.Split(':')[1];
                        CovidStateViewModel response;
                        if (state == "US")
                        {
                            var currentUSUrl = "https://api.covidtracking.com/v1/us/current.json";
                            response = CallAPI(currentUSUrl, state);

                        }
                        else
                        {
                            var currentStateUrl = $"https://api.covidtracking.com/v1/states/{state.ToLower()}/current.json";
                            response = CallAPI(currentStateUrl, state);
                        }
                        string serializedViewModel = JsonConvert.SerializeObject(response);

                        sw[clientnum].WriteLine(Protocol.state.ToString() + ":" + serializedViewModel);
                        sw[clientnum].Flush();

                    }
                    if (inputStream.StartsWith(Protocol.dateRangeForState.ToString()))
                    {
                        var splitedResponse = inputStream.Split(':');
                        var state = splitedResponse[1];
                        var beginDateStr = splitedResponse[2];
                        var endDateStr = splitedResponse[3];
                        var beginDate = StringToDateTime(beginDateStr);
                        var endDate = StringToDateTime(endDateStr);

                        List<CovidStateViewModel> covidList = new List<CovidStateViewModel>();


                        string stateSpecificDate1Url, specificDateUSUrl;
                        CovidStateViewModel response;
                        
                        for (var date = beginDate; date.CompareTo(endDate.AddDays(1)) != 0; date = date.AddDays(1))
                        {
                            var stringDate = date.ToString("yyyyMMdd");

                            if (state == "US")
                            {
                                specificDateUSUrl = $"https://api.covidtracking.com/v1/us/{stringDate}.json";
                                response = CallAPI(specificDateUSUrl, state);

                            }
                            else
                            {
                                stateSpecificDate1Url = $"https://api.covidtracking.com/v1/states/{state.ToLower()}/{stringDate}.json";
                                response = CallAPI(stateSpecificDate1Url, state);
                            }

                            

                            covidList.Add(response);
                        }

                        string serializedCovidList = JsonConvert.SerializeObject(covidList);
                        sw[clientnum].WriteLine(Protocol.dateRangeForState.ToString() + ":" + serializedCovidList);
                        sw[clientnum].Flush();

                    }
                    if (inputStream.StartsWith(Protocol.specificDate.ToString()))
                    {
                        var splitedResponse = inputStream.Split(':');
                        var state = splitedResponse[1];
                        var date = splitedResponse[2];

                        CovidStateViewModel response;
                        if (state == "US")
                        {
                            var currentUSUrl = $"https://api.covidtracking.com/v1/us/{date}.json";
                            response = CallAPI(currentUSUrl, state);

                        }
                        else
                        {
                            var stateSpecificDateUrl = $"https://api.covidtracking.com/v1/states/{state.ToLower()}/{date}.json";
                            response = CallAPI(stateSpecificDateUrl, state);
                        }


                       
                        string serializedViewModel = JsonConvert.SerializeObject(response);

                        sw[clientnum].WriteLine(Protocol.specificDate.ToString() + ":" + serializedViewModel);
                        sw[clientnum].Flush();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                    sr[clientnum].Close();
                    sw[clientnum].Close();
                    ns[clientnum].Close();
                    InsertText("Client " + clientnum + " has disconnected");
                    KillMe(clientnum);
                }
            }
        }

        private DateTime StringToDateTime(string dateStr)
        {
            int year = int.Parse(dateStr.Substring(0, 4));
            int month = int.Parse(dateStr.Substring(4, 2));
            int day = int.Parse(dateStr.Substring(6));

            return new DateTime(year, month, day);
        }

        
        private void InsertText(string text)
        {
            if (this.listBox1.Dispatcher.CheckAccess())
            {
                this.listBox1.Items.Insert(0, text);
            }
            else
            {
                listBox1.Dispatcher.BeginInvoke(new SetTextCallback(InsertText), text);
            }
        }

        private void KillMe(int threadnum)
        {
            if (this.listBox1.Dispatcher.CheckAccess())
            {
                UsedClientNumbers.Remove(threadnum);
                AvailableClientNumbers.Add(threadnum);
                bkw1[threadnum].CancelAsync();
                bkw1[threadnum].Dispose();
                bkw1[threadnum] = null;
                GC.Collect();

            }
            else
            {
                listBox1.Dispatcher.BeginInvoke(new SetIntCallbCk(KillMe), threadnum);
            }

        }

        public CovidStateViewModel CallAPI(string url, string state)
        {


            HttpWebRequest apiRequest = WebRequest.Create(url) as HttpWebRequest;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3
                            | SecurityProtocolType.Tls
                            | SecurityProtocolType.Tls11
                            | SecurityProtocolType.Tls12;
            CovidStateViewModel covidStateViewModelJson;
            using (HttpWebResponse response = apiRequest.GetResponse() as HttpWebResponse)
            {
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string apiResponse = reader.ReadToEnd();

                if (state == "US")
                {
                    CovidUSData covidUSDataModelJson;
                    if (url.Contains("current"))
                    {

                        covidUSDataModelJson = JsonConvert.DeserializeObject<CovidUSData[]>(apiResponse)[0];
                       
                    }
                    else
                    {
                        covidUSDataModelJson = JsonConvert.DeserializeObject<CovidUSData>(apiResponse);

                    }
                    covidStateViewModelJson = new CovidStateViewModel
                    {
                        State = state,
                        Date = StringToDateTime(covidUSDataModelJson.date.ToString()),
                        ConfirmedDeaths = covidUSDataModelJson.death,
                        NumberOfCases = covidUSDataModelJson.positiveIncrease,
                        TotalNumberOfHospitalization = covidUSDataModelJson.hospitalizedCumulative ?? 0,
                        CurrentNumberOfHospitalization = covidUSDataModelJson.hospitalizedCurrently ?? 0,
                        TotalNumberOfTests = covidUSDataModelJson.totalTestResults,
                        NumberOfNegativeTests = covidUSDataModelJson.negative,
                        NumberOfPositiveTests = covidUSDataModelJson.positive,
                        NumberOfPendingTests = covidUSDataModelJson.pending ?? 0
                    };
                }
                else
                {
                    CovidStateData covidStateDataModelJson = JsonConvert.DeserializeObject<CovidStateData>(apiResponse);
                    covidStateViewModelJson = new CovidStateViewModel
                    {
                        State = covidStateDataModelJson.state,
                        Date = StringToDateTime(covidStateDataModelJson.date.ToString()),
                        ConfirmedDeaths = covidStateDataModelJson.death ?? 0,
                        NumberOfCases = covidStateDataModelJson.probableCases ?? 0,
                        TotalNumberOfHospitalization = covidStateDataModelJson.hospitalizedCumulative ?? 0,
                        CurrentNumberOfHospitalization = covidStateDataModelJson.hospitalizedCurrently ?? 0,
                        TotalNumberOfTests = covidStateDataModelJson.totalTestsPeopleViral ?? 0,
                        NumberOfNegativeTests = covidStateDataModelJson.negative ?? 0,
                        NumberOfPositiveTests = covidStateDataModelJson.positive ?? 0,
                        NumberOfPendingTests = covidStateDataModelJson.pending ?? 0
                    };
                }

                response.Close();
            }
            return covidStateViewModelJson;
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            foreach (int index in UsedClientNumbers)
            {
                sw[index].WriteLine(Protocol.disconnect.ToString());
                sw[index].Flush();
            }
        }

        private void About_Button_Click(object sender, RoutedEventArgs e)
        {
            aboutWindow = new About(aboutBttn);
            aboutWindow.Show();
            aboutBttn.IsEnabled = false;
        }

        private void Help_Button_Click(object sender, RoutedEventArgs e)
        {
            helpWindow = new Help(helpBttn);
            helpWindow.Show();
            helpBttn.IsEnabled = false;
        }
    }
}
