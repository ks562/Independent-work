﻿using System.Windows;
using System.Windows.Controls;

namespace Server
{
    public partial class Help : Window
    {
        private Button helpBttn;
        public Help(Button helpBttn)
        {
            InitializeComponent();
            this.helpBttn = helpBttn;
            Closing += (sender, e) =>
            {
                helpBttn.IsEnabled = true;
            };
        }
    }
}
