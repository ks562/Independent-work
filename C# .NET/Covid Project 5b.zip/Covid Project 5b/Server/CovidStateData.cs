﻿namespace Server
{
    public class CovidStateData
    {
        public string checkTimeEt { get; set; } // Deprecated
        public int? commercialScore { get; set; } // Deprecated
        public string dataQualityGrade { get; set; }
        public int date { get; set; }
        public string dateChecked { get; set; } // Deprecated, changed from DateTime to string
        public string dateModified { get; set; } // Deprecated, changed from DateTime to string, advised to use lastUpdateEt instead
        public int? death { get; set; }
        public int? deathConfirmed { get; set; }
        public int? deathIncrease { get; set; }
        public int? deathProbable { get; set; }
        public string fips { get; set; }
        public string grade { get; set; } // Deprecated
        public string hash { get; set; } // Deprecated
        public int? hospitalized { get; set; } // Deprecated
        public int? hospitalizedCumulative { get; set; }
        public int? hospitalizedCurrently { get; set; }
        public int? hospitalizedIncrease { get; set; }
        public int? inIcuCumulative { get; set; }
        public int? inIcuCurrently { get; set; }
        public string lastUpdateEt { get; set; }
        public int? negative { get; set; }
        public int? negativeIncrease { get; set; } // Deprecated
        public int? negativeRegularScore { get; set; } // Deprecated
        public int? negativeScore { get; set; } // Deprecated
        public int? negativeTestsAntibody { get; set; }
        public int? negativeTestsPeopleAntibody { get; set; }
        public int? negativeTestsViral { get; set; }
        public int? onVentilatorCumulative { get; set; }
        public int? onVentilatorCurrently { get; set; }
        public int? pending { get; set; }
        public int? posNeg { get; set; } // Deprecated
        public int? positive { get; set; }
        public int? positiveCasesViral { get; set; }
        public int? positiveIncrease { get; set; }
        public int? positiveScore { get; set; } // Deprecated
        public int? positiveTestsAntibody { get; set; }
        public int? positiveTestsAntigen { get; set; }
        public int? positiveTestsPeopleAntibody { get; set; }
        public int? positiveTestsPeopleAntigen { get; set; }
        public int? positiveTestsViral { get; set; }
        public int? probableCases { get; set; }
        public int? recovered { get; set; }
        public int? score { get; set; } // Deprecated
        public string state { get; set; }
        public int? total { get; set; } // Deprecated
        public string totalTestResultsSource { get; set; }
        public int? totalTestResults { get; set; }
        public int? totalTestsViral { get; set; }
        public int? totalTestEncountersViral { get; set; }
        public int? totalTestsPeopleViral { get; set; }
        public int? totalTestsAntibody { get; set; }
        public int? totalTestsPeopleAntibody { get; set; }
        public int? totalTestsPeopleAntigen { get; set; }
        public int? totalTestsAntigen { get; set; }
        public int? totalTestResultsIncrease { get; set; }
    }
}
