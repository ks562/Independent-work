﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class CovidUSData
    {
        public int death { get; set; }
        public int totalTestResults { get; set; }
        public int date { get; set; }
        public int states { get; set; }
        public int positive { get; set; }
        public int negative { get; set; }
        public int? pending { get; set; }
        public int positiveIncrease { get; set; }
        public int? hospitalizedCurrently { get; set; }
        public int? hospitalizedCumulative { get; set; }




        public object inIcuCurrently { get; set; }
        public object inIcuCumulative { get; set; }
        public object onVentilatorCurrently { get; set; }
        public object onVentilatorCumulative { get; set; }
        public object recovered { get; set; }
        public DateTime dateChecked { get; set; }
        public object hospitalized { get; set; }
        public DateTime lastModified { get; set; }
        public int total { get; set; }
        public int posNeg { get; set; }
        public int deathIncrease { get; set; }
        public int hospitalizedIncrease { get; set; }
        public int negativeIncrease { get; set; }
        public int totalTestResultsIncrease { get; set; }
        public string hash { get; set; }

    }
}
